import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/common/Sidebar';
import { Header } from './components/common/Header';
import { ToastContainer } from './components/common/ToastContainer';
import { TrackingModal } from './components/common/TrackingModal';
import { AccessDeniedView } from './components/common/AccessDeniedView';
import { LoginScreen } from './components/auth/LoginScreen';
import { DashboardScreen } from './components/dashboard/DashboardScreen';
import { OnboardingScreen } from './components/onboarding/OnboardingScreen';
import { OffboardingScreen } from './components/offboarding/OffboardingScreen';
import { ResourcesScreen } from './components/resources/ResourcesScreen';
import { ReportsScreen } from './components/reports/ReportsScreen';
import { AdministrationScreen } from './components/admin/AdministrationScreen';

const MainLayout: React.FC = () => {
  const { activeScreen, canAccessScreen } = useApp();

  const isAllowed = canAccessScreen(activeScreen);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-900 antialiased selection:bg-blue-600 selection:text-white">
      {/* Persistent Left Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header />

        {/* Dynamic Screen View */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-100/90">
          <div className="max-w-7xl mx-auto">
            {!isAllowed ? (
              <AccessDeniedView screenName={activeScreen.charAt(0).toUpperCase() + activeScreen.slice(1)} />
            ) : (
              <>
                {activeScreen === 'dashboard' && <DashboardScreen />}
                {activeScreen === 'onboarding' && <OnboardingScreen />}
                {activeScreen === 'offboarding' && <OffboardingScreen />}
                {activeScreen === 'resources' && <ResourcesScreen />}
                {activeScreen === 'reports' && <ReportsScreen />}
                {activeScreen === 'administration' && <AdministrationScreen />}
              </>
            )}
          </div>
        </main>
      </div>

      {/* Global Interactive Overlays */}
      <TrackingModal />
      <ToastContainer />
    </div>
  );
};

const AppContent: React.FC = () => {
  const { currentUser } = useApp();

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100">
        <LoginScreen />
        <ToastContainer />
      </div>
    );
  }

  return <MainLayout />;
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

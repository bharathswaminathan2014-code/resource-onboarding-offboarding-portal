export type ScreenType = 
  | 'dashboard'
  | 'onboarding'
  | 'offboarding'
  | 'resources'
  | 'reports'
  | 'administration';

export type UserRole = 
  | 'Executive'
  | 'Senior Leader'
  | 'Senior Manager'
  | 'Manager'
  | 'PMO'
  | 'Operational User'
  | 'Admin';

export type OnboardingStatus = 
  | 'Draft'
  | 'Submitted'
  | 'In Progress'
  | 'Pending'
  | 'Completed'
  | 'Delayed'
  | 'Cancelled';

export type OffboardingStatus = 
  | 'Draft'
  | 'Submitted'
  | 'In Progress'
  | 'Pending'
  | 'Completed'
  | 'Delayed'
  | 'Cancelled';

export type LifecycleStatus = 'Onboarding' | 'Active' | 'Offboarding' | 'Completed';

export type HardwareDeliveryStatus = 
  | 'Configured'
  | 'Dispatched'
  | 'Pending Build'
  | 'Delivered'
  | 'Delayed';

export type AssetReturnStatus = 
  | 'PENDING BOX DELIVERY'
  | 'RETURN KIT IN TRANSIT'
  | 'LAPTOP RETURNED'
  | 'BOX DISPATCH PENDING'
  | 'DROP-OFF DELAY'
  | 'LAPTOP PICKUP SCHEDULED'
  | 'UNASSIGNED';

export interface MilestoneItem {
  id: string;
  title: string;
  date: string;
  details: string;
  status: 'completed' | 'in_progress' | 'pending' | 'delayed';
}

export interface Resource {
  id: string; // Associate ID, e.g. '2049182'
  name: string;
  title: string;
  phone: string;
  cognizantEmail: string;
  clientEmail: string;
  address: string;
  city: string;
  state: string;
  location: string;
  accountId: string;
  accountName: string;
  programId: string;
  programName: string;
  projectId: string;
  projectName: string;
  manager: string;
  effectiveDate: string;
  lifecycleStatus: LifecycleStatus;
  assetTag: string;
  serialNumber: string;
  assetModel: string;
  assetHandoverDate: string;
  soc2Compliant: boolean;
  lastAuditDate: string;
  milestones: MilestoneItem[];
}

export interface OnboardingRecord {
  id: string;
  associateId: string;
  associateName: string;
  role: string;
  phone: string;
  cognizantEmail: string;
  clientEmail: string;
  address: string;
  city: string;
  state: string;
  location: string;
  account: string;
  program: string;
  projectId: string;
  projectName: string;
  manager: string;
  effectiveDate: string;
  status: OnboardingStatus;
  currentLifecycleStep: number; // 1 to 5
  aribaRequestId: string;
  amount: number;
  invoiceNumber: string;
  assetModel: string;
  assetSerialNumber: string;
  dispatchMethod: string;
  trackingNumber: string;
  deliveryStatus: HardwareDeliveryStatus;
  deliveryDate: string;
  receiptSignature: string;
  blocker?: string | null;
  blockerAction?: string | null;
  riskLevel?: 'High' | 'Medium' | 'Low';
}

export interface OffboardingRecord {
  id: string;
  associateId: string;
  associateName: string;
  role: string;
  phone: string;
  email: string;
  account: string;
  program: string;
  projectId: string;
  projectName: string;
  manager: string;
  location: string;
  lastWorkingDate: string;
  status: OffboardingStatus;
  completionDate: string | null;
  assetStatus: AssetReturnStatus;
  carrier: string;
  trackingNumber: string;
  receivedDate: string | null;
  systemRevocation: string;
  daysOverdue?: number;
  blocker?: string | null;
  blockerAction?: string | null;
  riskLevel?: 'High' | 'Medium' | 'Low';
}

export interface Account {
  id: string;
  name: string;
  code: string;
  description?: string;
  status: 'Active' | 'Inactive';
  programs: Program[];
}

export interface Program {
  id: string;
  name: string;
  code: string;
  accountId: string;
  status: 'Active' | 'Inactive';
  projects: Project[];
}

export interface Project {
  id: string;
  code: string;
  name: string;
  programId: string;
  manager: string;
  location?: string;
  activeCount: number;
  status: 'Active' | 'Inactive';
}

export interface ManagerItem {
  id: string;
  name: string;
  email: string;
  status: 'Active' | 'Inactive';
}

export interface LocationItem {
  id: string;
  name: string;
  city: string;
  state: string;
  country: string;
  status: 'Active' | 'Inactive';
}

export interface ReferenceItem {
  id: string;
  name: string;
  category: 'delivery_method' | 'return_carrier' | 'hardware_model';
  status: 'Active' | 'Inactive';
  description?: string;
}

export interface PortalUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  accountScope: string;
  programScope?: string;
  projectScope?: string;
  status: 'Active' | 'Inactive';
  lastActive: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  type: 'onboarding_submitted' | 'status_changed' | 'offboarding_submitted' | 'pending_action' | 'delayed_onboarding' | 'delayed_offboarding';
  read: boolean;
  targetScreen?: ScreenType;
  targetId?: string;
}

export interface GlobalFilterState {
  account: string;
  program: string;
  project: string;
  location: string;
  manager: string;
  status: string;
  dateRange: string;
  searchQuery: string;
}

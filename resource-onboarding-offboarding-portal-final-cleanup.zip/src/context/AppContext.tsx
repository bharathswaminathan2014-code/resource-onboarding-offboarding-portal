import React, { createContext, useContext, useState, useMemo, useEffect, ReactNode } from 'react';
import {
  ScreenType,
  UserRole,
  OnboardingRecord,
  OffboardingRecord,
  Resource,
  Account,
  Program,
  Project,
  ManagerItem,
  LocationItem,
  ReferenceItem,
  PortalUser,
  NotificationItem,
  GlobalFilterState,
  OnboardingStatus,
  OffboardingStatus
} from '../types';
import {
  INITIAL_ACCOUNTS,
  INITIAL_MANAGERS,
  INITIAL_LOCATIONS,
  INITIAL_DELIVERY_METHODS,
  INITIAL_RETURN_CARRIERS,
  INITIAL_HARDWARE_MODELS,
  INITIAL_ONBOARDING_RECORDS,
  INITIAL_OFFBOARDING_RECORDS,
  INITIAL_RESOURCES,
  INITIAL_USERS,
  INITIAL_NOTIFICATIONS
} from '../data/mockData';
import {
  canAccessScreen as checkScreenAccess,
  canCreateOnboarding as checkCreateOnb,
  canEditOnboarding as checkEditOnb,
  canInitiateOffboarding as checkInitiateOffb,
  canEditOffboarding as checkEditOffb,
  canPerformOperationalActions as checkOpActions,
  canManageUsers as checkManageUsers,
  canManageMasterData as checkManageMasterData,
  isReadOnlyRole as checkReadOnly,
  isRecordInScope,
  getScopedAccounts
} from '../utils/permissions';

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

const STORAGE_KEYS = {
  accounts: 'cognizant_pmo_accounts',
  managers: 'cognizant_pmo_managers',
  locations: 'cognizant_pmo_locations',
  deliveryMethods: 'cognizant_pmo_delivery_methods',
  returnCarriers: 'cognizant_pmo_return_carriers',
  hardwareModels: 'cognizant_pmo_hardware_models',
  onboarding: 'cognizant_pmo_onboarding',
  offboarding: 'cognizant_pmo_offboarding',
  resources: 'cognizant_pmo_resources',
  users: 'cognizant_pmo_users',
  currentUser: 'cognizant_pmo_current_user'
};

function loadStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length === 0) return defaultValue;
    return parsed;
  } catch (err) {
    console.warn(`Error reading localStorage key "${key}":`, err);
    return defaultValue;
  }
}

interface AppContextType {
  activeScreen: ScreenType;
  setActiveScreen: (screen: ScreenType) => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  selectedAccount: string;
  setSelectedAccount: (acc: string) => void;
  filters: GlobalFilterState;
  setFilter: (key: keyof GlobalFilterState, value: string) => void;
  resetFilters: () => void;

  // Authentication & RBAC User State
  currentUser: PortalUser | null;
  isAuthenticated: boolean;
  login: (email: string, password?: string) => { success: boolean; error?: string };
  logout: () => void;
  userAccessibleAccounts: Account[];
  canAccessScreen: (screen: ScreenType) => boolean;
  canCreateOnboarding: boolean;
  canEditOnboarding: boolean;
  canInitiateOffboarding: boolean;
  canEditOffboarding: boolean;
  canPerformOperationalActions: boolean;
  canManageUsers: boolean;
  canManageMasterData: boolean;
  isReadOnlyRole: boolean;
  
  // Data lists & Master Data
  onboardingRecords: OnboardingRecord[];
  offboardingRecords: OffboardingRecord[];
  resources: Resource[];
  accounts: Account[];
  allPrograms: Program[];
  allProjects: Project[];
  managers: ManagerItem[];
  locations: LocationItem[];
  deliveryMethods: ReferenceItem[];
  returnCarriers: ReferenceItem[];
  hardwareModels: ReferenceItem[];
  users: PortalUser[];
  notifications: NotificationItem[];
  toasts: ToastMessage[];

  // Cascading helpers and retention helpers
  getProgramsForAccount: (accountIdOrName?: string, onlyActive?: boolean, currentProgramName?: string) => Program[];
  getProjectsForProgram: (programIdOrName?: string, accountIdOrName?: string, onlyActive?: boolean, currentProjectName?: string) => Project[];
  getProjectByNameOrId: (projectIdOrName: string) => Project | undefined;
  getAvailableItems: <T extends { id: string; name: string; status: 'Active' | 'Inactive' }>(items: T[], currentValue?: string) => T[];
  checkItemInUse: (
    type: 'account' | 'program' | 'project' | 'manager' | 'location' | 'delivery_method' | 'return_carrier' | 'hardware_model',
    id: string,
    name?: string
  ) => { inUse: boolean; count: number; details: string };
  resetMasterData: () => void;
  
  // Selected detail drawers
  selectedOnboardingId: string | null;
  setSelectedOnboardingId: (id: string | null) => void;
  selectedOffboardingId: string | null;
  setSelectedOffboardingId: (id: string | null) => void;
  selectedResourceId: string | null;
  setSelectedResourceId: (id: string | null) => void;

  // Modals
  isOnboardingModalOpen: boolean;
  setIsOnboardingModalOpen: (open: boolean) => void;
  isOffboardingModalOpen: boolean;
  setIsOffboardingModalOpen: (open: boolean) => void;
  trackingModalData: {
    isOpen: boolean;
    trackingNumber: string;
    carrier: string;
  };
  openTrackingModal: (trackingNumber: string, carrier?: string) => void;
  closeTrackingModal: () => void;
  
  // Computed KPIs
  onboardingKpis: {
    totalActive: number;
    upcoming: number;
    inProgress: number;
    pending: number;
    completed: number;
    delayed: number;
    submitted: number;
    draft: number;
    cancelled: number;
    hardwareTransit: number;
    awaitingAccess: number;
    slaComplianceRate: number;
  };
  
  offboardingKpis: {
    totalActive: number;
    upcoming: number;
    inProgress: number;
    pending: number;
    completed: number;
    delayed: number;
    submitted: number;
    draft: number;
    cancelled: number;
    hardwareRecoveryAwaiting: number;
    logisticsInTransit: number;
    auditClosed: number;
    complianceBreachOverdue: number;
  };

  resourceKpis: {
    totalAssigned: number;
    activeWorking: number;
    activePercentage: number;
    currentlyOnboarding: number;
    currentlyOffboarding: number;
  };

  // Actions
  addOnboardingRecord: (record: Omit<OnboardingRecord, 'id'>) => void;
  updateOnboardingRecord: (record: OnboardingRecord) => void;
  updateOnboardingStatus: (id: string, status: OnboardingStatus) => void;
  
  addOffboardingRecord: (record: Omit<OffboardingRecord, 'id'>) => void;
  updateOffboardingRecord: (record: OffboardingRecord) => void;
  updateOffboardingStatus: (id: string, status: OffboardingStatus) => void;

  // PMO Attention Actions
  remindApprover: (recordId: string) => void;
  checkCarrier: (trackingNumber: string) => void;
  escalateRecord: (recordId: string) => void;
  triggerPickup: (recordId: string) => void;

  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  unreadNotificationCount: number;

  // Master Data Admin Actions
  addAccount: (nameOrData: string | { name: string; code: string; description?: string }, code?: string) => void;
  updateAccount: (id: string, data: Partial<Account>) => void;
  toggleAccountStatus: (id: string) => void;
  deleteAccount: (id: string) => { success: boolean; inUse?: boolean; message?: string };

  addProgram: (accountIdOrData: string | { accountId: string; name: string; code: string }, name?: string, code?: string) => void;
  updateProgram: (id: string, data: Partial<Program>) => void;
  toggleProgramStatus: (id: string) => void;
  deleteProgram: (id: string) => { success: boolean; inUse?: boolean; message?: string };

  addProject: (
    programIdOrData: string | { programId: string; name: string; code: string; manager: string; location?: string },
    name?: string,
    code?: string,
    manager?: string,
    location?: string
  ) => void;
  updateProject: (id: string, data: Partial<Project>) => void;
  toggleProjectStatus: (idOrAccId: string, progId?: string, prjId?: string) => void;
  deleteProject: (idOrAccId: string, progId?: string, prjId?: string) => { success: boolean; inUse?: boolean; message?: string };

  addManager: (data: { name: string; email: string }) => void;
  updateManager: (id: string, data: Partial<ManagerItem>) => void;
  toggleManagerStatus: (id: string) => void;
  deleteManager: (id: string) => { success: boolean; inUse?: boolean; message?: string };

  addLocation: (data: { name: string; city: string; state: string; country: string }) => void;
  updateLocation: (id: string, data: Partial<LocationItem>) => void;
  toggleLocationStatus: (id: string) => void;
  deleteLocation: (id: string) => { success: boolean; inUse?: boolean; message?: string };

  addReferenceItem: (data: { name: string; category: 'delivery_method' | 'return_carrier' | 'hardware_model'; description?: string }) => void;
  updateReferenceItem: (id: string, data: Partial<ReferenceItem>) => void;
  toggleReferenceItemStatus: (id: string) => void;
  deleteReferenceItem: (id: string) => { success: boolean; inUse?: boolean; message?: string };

  addUser: (user: Omit<PortalUser, 'id' | 'lastActive'>) => void;
  updateUser: (id: string, data: Partial<PortalUser>) => void;
  toggleUserStatus: (id: string) => void;
  deleteUser: (id: string) => { success: boolean; message: string };

  // Toasts
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const initialFilters: GlobalFilterState = {
  account: 'all',
  program: 'all',
  project: 'all',
  location: 'all',
  manager: 'all',
  status: 'all',
  dateRange: 'current_month',
  searchQuery: ''
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeScreen, setActiveScreen] = useState<ScreenType>('dashboard');
  const [selectedAccount, setSelectedAccountState] = useState<string>('all');
  const [filters, setFilters] = useState<GlobalFilterState>(initialFilters);

  // Raw Underlying Databases
  const [rawOnboardingRecords, setRawOnboardingRecords] = useState<OnboardingRecord[]>(() =>
    loadStorage(STORAGE_KEYS.onboarding, INITIAL_ONBOARDING_RECORDS)
  );
  const [rawOffboardingRecords, setRawOffboardingRecords] = useState<OffboardingRecord[]>(() =>
    loadStorage(STORAGE_KEYS.offboarding, INITIAL_OFFBOARDING_RECORDS)
  );
  const [rawResources, setRawResources] = useState<Resource[]>(() =>
    loadStorage(STORAGE_KEYS.resources, INITIAL_RESOURCES)
  );
  const [accounts, setAccounts] = useState<Account[]>(() =>
    loadStorage(STORAGE_KEYS.accounts, INITIAL_ACCOUNTS)
  );
  const [managers, setManagers] = useState<ManagerItem[]>(() =>
    loadStorage(STORAGE_KEYS.managers, INITIAL_MANAGERS)
  );
  const [locations, setLocations] = useState<LocationItem[]>(() =>
    loadStorage(STORAGE_KEYS.locations, INITIAL_LOCATIONS)
  );
  const [deliveryMethods, setDeliveryMethods] = useState<ReferenceItem[]>(() =>
    loadStorage(STORAGE_KEYS.deliveryMethods, INITIAL_DELIVERY_METHODS)
  );
  const [returnCarriers, setReturnCarriers] = useState<ReferenceItem[]>(() =>
    loadStorage(STORAGE_KEYS.returnCarriers, INITIAL_RETURN_CARRIERS)
  );
  const [hardwareModels, setHardwareModels] = useState<ReferenceItem[]>(() =>
    loadStorage(STORAGE_KEYS.hardwareModels, INITIAL_HARDWARE_MODELS)
  );
  const [users, setUsers] = useState<PortalUser[]>(() => {
    const storedUsers = loadStorage<PortalUser[]>(STORAGE_KEYS.users, []);
    const storedById = new Map(storedUsers.map(user => [user.id, user]));

    // Seeded demo personas are canonical test identities. Preserve mutable
    // state such as Active/Inactive and lastActive, but never allow stale
    // persisted email/name/role/scope values to replace the demo persona.
    const mergedUsers = INITIAL_USERS.map(seedUser => {
      const storedUser = storedById.get(seedUser.id);
      if (!storedUser) return seedUser;
      return {
        ...seedUser,
        status: storedUser.status,
        lastActive: storedUser.lastActive
      };
    });
    const seededIds = new Set(INITIAL_USERS.map(user => user.id));
    const customUsers = storedUsers.filter(user => !seededIds.has(user.id));

    return [...mergedUsers, ...customUsers];
  });
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Authenticated Portal User State
  const [currentUser, setCurrentUser] = useState<PortalUser | null>(() => {
    try {
      const savedUserJson = localStorage.getItem(STORAGE_KEYS.currentUser);
      if (savedUserJson) {
        const saved = JSON.parse(savedUserJson) as PortalUser;
        const storedUsers = loadStorage<PortalUser[]>(STORAGE_KEYS.users, []);
        const storedById = new Map(storedUsers.map(user => [user.id, user]));
        const allUsers = INITIAL_USERS.map(seedUser => {
          const storedUser = storedById.get(seedUser.id);
          return storedUser
            ? { ...seedUser, status: storedUser.status, lastActive: storedUser.lastActive }
            : seedUser;
        }).concat(storedUsers.filter(user => !INITIAL_USERS.some(seed => seed.id === user.id)));
        const match = allUsers.find(u =>
          u.id === saved.id || u.email.toLowerCase() === saved.email.toLowerCase()
        );
        if (match && match.status === 'Active') {
          return match;
        }
      }
    } catch (e) {
      console.warn('Error reading saved user session:', e);
    }
    // Start unauthenticated so the Login screen is shown and users can select a demo persona.
    return null;
  });

  // Current Role is strictly derived from the authenticated user
  const currentRole: UserRole = currentUser?.role || 'PMO';
  const setCurrentRole = (newRole: UserRole) => {
    if (currentUser) {
      updateUser(currentUser.id, { role: newRole });
    }
  };

  // Persistent localStorage synchronizers
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.accounts, JSON.stringify(accounts)); } catch (e) {}
  }, [accounts]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.managers, JSON.stringify(managers)); } catch (e) {}
  }, [managers]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.locations, JSON.stringify(locations)); } catch (e) {}
  }, [locations]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.deliveryMethods, JSON.stringify(deliveryMethods)); } catch (e) {}
  }, [deliveryMethods]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.returnCarriers, JSON.stringify(returnCarriers)); } catch (e) {}
  }, [returnCarriers]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.hardwareModels, JSON.stringify(hardwareModels)); } catch (e) {}
  }, [hardwareModels]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.onboarding, JSON.stringify(rawOnboardingRecords)); } catch (e) {}
  }, [rawOnboardingRecords]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.offboarding, JSON.stringify(rawOffboardingRecords)); } catch (e) {}
  }, [rawOffboardingRecords]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.resources, JSON.stringify(rawResources)); } catch (e) {}
  }, [rawResources]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users)); } catch (e) {}
  }, [users]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_KEYS.currentUser, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_KEYS.currentUser);
      }
    } catch (e) {}
  }, [currentUser]);

  // Organizational Scoping: Filter records to what the current user is authorized to access
  const onboardingRecords = useMemo(() => {
    if (!currentUser) return [];
    return rawOnboardingRecords.filter(r => isRecordInScope(r, currentUser, accounts));
  }, [rawOnboardingRecords, currentUser, accounts]);

  const offboardingRecords = useMemo(() => {
    if (!currentUser) return [];
    return rawOffboardingRecords.filter(r => isRecordInScope(r, currentUser, accounts));
  }, [rawOffboardingRecords, currentUser, accounts]);

  const resources = useMemo(() => {
    if (!currentUser) return [];
    return rawResources.filter(r => isRecordInScope(r, currentUser, accounts));
  }, [rawResources, currentUser, accounts]);

  // Permitted Accounts based on user scope
  const userAccessibleAccounts = useMemo(() => {
    return getScopedAccounts(accounts, currentUser);
  }, [accounts, currentUser]);

  // When current user changes, ensure selectedAccount is valid for their scope
  useEffect(() => {
    if (currentUser && currentUser.accountScope && currentUser.accountScope !== 'All') {
      const matchAcc = accounts.find(
        a => a.name.toLowerCase() === currentUser.accountScope?.toLowerCase() || a.id === currentUser.accountScope
      );
      if (matchAcc) {
        setSelectedAccountState(matchAcc.id);
      }
    }
  }, [currentUser, accounts]);

  // RBAC Permission checks
  const canAccessScreen = (screen: ScreenType) => checkScreenAccess(currentUser?.role, screen);
  const canCreateOnboarding = checkCreateOnb(currentUser?.role);
  const canEditOnboarding = checkEditOnb(currentUser?.role);
  const canInitiateOffboarding = checkInitiateOffb(currentUser?.role);
  const canEditOffboarding = checkEditOffb(currentUser?.role);
  const canPerformOperationalActions = checkOpActions(currentUser?.role);
  const canManageUsers = checkManageUsers(currentUser?.role);
  const canManageMasterData = checkManageMasterData(currentUser?.role);
  const isReadOnlyRole = checkReadOnly(currentUser?.role);

  // Authentication Handlers
  const login = (email: string, password?: string): { success: boolean; error?: string } => {
    const trimmed = email.trim().toLowerCase();
    const user = users.find(u => u.email.toLowerCase() === trimmed);
    if (!user) {
      return { success: false, error: 'User not found with this email address.' };
    }
    if (password !== undefined && password !== 'demo123') {
      return { success: false, error: 'Invalid demo password. Use demo123.' };
    }
    if (user.status === 'Inactive') {
      return {
        success: false,
        error: 'Account Inactive: This portal account has been deactivated. Access is denied.'
      };
    }

    setCurrentUser(user);

    // Sync account scope
    if (user.accountScope && user.accountScope !== 'All') {
      const acc = accounts.find(
        a => a.name.toLowerCase() === user.accountScope?.toLowerCase() || a.id === user.accountScope
      );
      if (acc) {
        setSelectedAccountState(acc.id);
      }
    } else {
      setSelectedAccountState('all');
    }

    // Check if activeScreen is allowed; if not, go to dashboard
    if (!checkScreenAccess(user.role, activeScreen)) {
      setActiveScreen('dashboard');
    }

    showToast('Welcome Back', `Logged in as ${user.name} (${user.role}).`, 'success');
    return { success: true };
  };

  const logout = () => {
    const prevName = currentUser?.name;
    setCurrentUser(null);
    setActiveScreen('dashboard');
    showToast('Signed Out', prevName ? `${prevName} has been signed out.` : 'You have been signed out.');
  };

  const [selectedOnboardingId, setSelectedOnboardingId] = useState<string | null>(null);
  const [selectedOffboardingId, setSelectedOffboardingId] = useState<string | null>(null);
  const [selectedResourceId, setSelectedResourceId] = useState<string | null>('2049182');

  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState(false);
  const [isOffboardingModalOpen, setIsOffboardingModalOpen] = useState(false);

  const [trackingModalData, setTrackingModalData] = useState<{
    isOpen: boolean;
    trackingNumber: string;
    carrier: string;
  }>({
    isOpen: false,
    trackingNumber: '',
    carrier: 'FedEx'
  });

  const openTrackingModal = (trackingNumber: string, carrier?: string) => {
    const carrierName = carrier || (trackingNumber.startsWith('1Z') ? 'UPS' : trackingNumber.startsWith('DHL') ? 'DHL' : 'FedEx');
    setTrackingModalData({
      isOpen: true,
      trackingNumber,
      carrier: carrierName
    });
  };

  const closeTrackingModal = () => {
    setTrackingModalData(prev => ({ ...prev, isOpen: false }));
  };

  const setSelectedAccount = (acc: string) => {
    setSelectedAccountState(acc);
    setFilters(prev => ({
      ...prev,
      account: acc,
      program: 'all',
      project: 'all'
    }));
  };

  const setFilter = (key: keyof GlobalFilterState, value: string) => {
    setFilters(prev => {
      const next = { ...prev, [key]: value };
      if (key === 'account') {
        next.program = 'all';
        next.project = 'all';
        setSelectedAccountState(value);
      } else if (key === 'program') {
        next.project = 'all';
      }
      return next;
    });
  };

  const resetFilters = () => {
    setFilters(initialFilters);
    setSelectedAccountState('all');
  };

  // Master Data flat caches and cascading helpers
  const allPrograms = useMemo(() => accounts.flatMap(a => a.programs), [accounts]);
  const allProjects = useMemo(() => accounts.flatMap(a => a.programs.flatMap(p => p.projects)), [accounts]);

  const getProgramsForAccount = (accountIdOrName?: string, onlyActive?: boolean, currentProgramName?: string) => {
    let list = allPrograms;
    if (accountIdOrName && accountIdOrName !== 'all') {
      const acc = accounts.find(a => a.id === accountIdOrName || a.name.toLowerCase() === accountIdOrName.toLowerCase());
      list = acc ? acc.programs : allPrograms;
    }
    if (!onlyActive) return list;
    return list.filter(p => p.status === 'Active' || (currentProgramName && (p.name === currentProgramName || p.id === currentProgramName)));
  };

  const getProjectsForProgram = (programIdOrName?: string, accountIdOrName?: string, onlyActive?: boolean, currentProjectName?: string) => {
    let list: Project[] = [];
    if (programIdOrName && programIdOrName !== 'all') {
      const prog = allPrograms.find(p => p.id === programIdOrName || p.name.toLowerCase() === programIdOrName.toLowerCase());
      list = prog ? prog.projects : [];
    } else if (accountIdOrName && accountIdOrName !== 'all') {
      const acc = accounts.find(a => a.id === accountIdOrName || a.name.toLowerCase() === accountIdOrName.toLowerCase());
      list = acc ? acc.programs.flatMap(p => p.projects) : allProjects;
    } else {
      list = allProjects;
    }
    if (!onlyActive) return list;
    return list.filter(p => p.status === 'Active' || (currentProjectName && (p.name === currentProjectName || p.id === currentProjectName || p.code === currentProjectName)));
  };

  const getAvailableItems = <T extends { id: string; name: string; status: 'Active' | 'Inactive' }>(
    items: T[],
    currentValue?: string
  ): T[] => {
    return items.filter(item => 
      item.status === 'Active' || (currentValue && (item.name === currentValue || item.id === currentValue))
    );
  };

  const resetMasterData = () => {
    setAccounts(INITIAL_ACCOUNTS);
    setManagers(INITIAL_MANAGERS);
    setLocations(INITIAL_LOCATIONS);
    setDeliveryMethods(INITIAL_DELIVERY_METHODS);
    setReturnCarriers(INITIAL_RETURN_CARRIERS);
    setHardwareModels(INITIAL_HARDWARE_MODELS);
    try {
      localStorage.removeItem(STORAGE_KEYS.accounts);
      localStorage.removeItem(STORAGE_KEYS.managers);
      localStorage.removeItem(STORAGE_KEYS.locations);
      localStorage.removeItem(STORAGE_KEYS.deliveryMethods);
      localStorage.removeItem(STORAGE_KEYS.returnCarriers);
      localStorage.removeItem(STORAGE_KEYS.hardwareModels);
    } catch (e) {}
    showToast('Master Data Reset', 'All enterprise master reference datasets have been restored to initial system seed defaults.', 'success');
  };

  const getProjectByNameOrId = (projectIdOrName: string) => {
    return allProjects.find(p => 
      p.id === projectIdOrName || 
      p.name.toLowerCase() === projectIdOrName.toLowerCase() || 
      p.code.toLowerCase() === projectIdOrName.toLowerCase()
    );
  };

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Filter records based on selectedAccount and filters
  const filterAccountScope = <T extends { account: string }>(items: T[]): T[] => {
    if (selectedAccount === 'all') return items;
    return items.filter(item => {
      const acc = accounts.find(a => a.id === selectedAccount);
      return acc ? item.account.toLowerCase() === acc.name.toLowerCase() : true;
    });
  };

  // KPI Calculations dynamically computed from underlying state
  const onboardingKpis = useMemo(() => {
    const scoped = filterAccountScope<OnboardingRecord>(onboardingRecords);
    const inProgress = scoped.filter(r => r.status === 'In Progress').length;
    const pending = scoped.filter(r => r.status === 'Pending').length;
    const delayed = scoped.filter(r => r.status === 'Delayed').length;
    const submitted = scoped.filter(r => r.status === 'Submitted').length;
    const draft = scoped.filter(r => r.status === 'Draft').length;
    const completed = scoped.filter(r => r.status === 'Completed').length;
    const cancelled = scoped.filter(r => r.status === 'Cancelled').length;
    
    // Active pipeline includes In Progress, Pending, Delayed, Submitted
    const totalActive = inProgress + pending + delayed + submitted;
    const upcoming = scoped.filter(r => {
      const eff = new Date(r.effectiveDate);
      const now = new Date('2024-10-25');
      const diffDays = (eff.getTime() - now.getTime()) / (1000 * 3600 * 24);
      return diffDays >= 0 && diffDays <= 14;
    }).length;

    const hardwareTransit = scoped.filter(r => r.deliveryStatus === 'Dispatched' || r.deliveryStatus === 'Pending Build').length;
    const awaitingAccess = pending + (scoped.filter(r => r.currentLifecycleStep === 4).length);
    const nonDelayed = Math.max(0, totalActive + completed - delayed);
    const totalConsidered = totalActive + completed;
    const slaComplianceRate = totalConsidered > 0 ? Number(((nonDelayed / totalConsidered) * 100).toFixed(1)) : 100.0;

    return {
      totalActive,
      upcoming,
      inProgress,
      pending,
      completed,
      delayed,
      submitted,
      draft,
      cancelled,
      hardwareTransit,
      awaitingAccess,
      slaComplianceRate
    };
  }, [onboardingRecords, selectedAccount, accounts]);

  const offboardingKpis = useMemo(() => {
    const scoped = filterAccountScope<OffboardingRecord>(offboardingRecords);
    const inProgress = scoped.filter(r => r.status === 'In Progress').length;
    const pending = scoped.filter(r => r.status === 'Pending').length;
    const delayed = scoped.filter(r => r.status === 'Delayed').length;
    const submitted = scoped.filter(r => r.status === 'Submitted').length;
    const draft = scoped.filter(r => r.status === 'Draft').length;
    const completed = scoped.filter(r => r.status === 'Completed').length;
    const cancelled = scoped.filter(r => r.status === 'Cancelled').length;

    const totalActive = inProgress + pending + delayed + submitted;
    const upcoming = scoped.filter(r => {
      const lwd = new Date(r.lastWorkingDate);
      const now = new Date('2024-10-25');
      const diffDays = (lwd.getTime() - now.getTime()) / (1000 * 3600 * 24);
      return diffDays >= 0 && diffDays <= 14;
    }).length;

    const hardwareRecoveryAwaiting = scoped.filter(r => r.assetStatus !== 'LAPTOP RETURNED').length;
    const logisticsInTransit = scoped.filter(r => r.assetStatus === 'RETURN KIT IN TRANSIT' || r.assetStatus === 'BOX DISPATCH PENDING').length;
    const auditClosed = completed;
    const complianceBreachOverdue = delayed;

    return {
      totalActive,
      upcoming,
      inProgress,
      pending,
      completed,
      delayed,
      submitted,
      draft,
      cancelled,
      hardwareRecoveryAwaiting,
      logisticsInTransit,
      auditClosed,
      complianceBreachOverdue
    };
  }, [offboardingRecords, selectedAccount, accounts]);

  const resourceKpis = useMemo(() => {
    const scoped = filterAccountScope<Resource>(resources);
    const totalAssigned = scoped.length;
    const activeWorking = scoped.filter(r => r.lifecycleStatus === 'Active').length;
    const activePercentage = totalAssigned > 0 ? Number(((activeWorking / totalAssigned) * 100).toFixed(1)) : 0;
    const currentlyOnboarding = onboardingKpis.totalActive;
    const currentlyOffboarding = offboardingKpis.totalActive;

    return {
      totalAssigned,
      activeWorking,
      activePercentage,
      currentlyOnboarding,
      currentlyOffboarding
    };
  }, [resources, selectedAccount, accounts, onboardingKpis, offboardingKpis]);

  // Actions
  const addOnboardingRecord = (record: Omit<OnboardingRecord, 'id'>) => {
    if (!canCreateOnboarding) {
      showToast('Permission Denied', 'Your portal role is not permitted to initiate onboarding records.', 'warning');
      return;
    }
    const baseId = `ONB-${record.associateId || Date.now().toString().slice(-6)}`;
    let newId = baseId;
    let counter = 1;
    while (rawOnboardingRecords.some(r => r.id === newId)) {
      newId = `${baseId}-${counter}`;
      counter++;
    }
    const newRecord: OnboardingRecord = {
      ...record,
      id: newId
    };
    setRawOnboardingRecords(prev => [newRecord, ...prev]);

    // Also register in resources if not exists
    const existing = rawResources.find(r => r.id === record.associateId);
    if (!existing) {
      const newResource: Resource = {
        id: record.associateId,
        name: record.associateName,
        title: record.role,
        phone: record.phone,
        cognizantEmail: record.cognizantEmail,
        clientEmail: record.clientEmail,
        address: record.address,
        city: record.city,
        state: record.state,
        location: record.location,
        accountId: 'acc-apex',
        accountName: record.account,
        programId: 'prog-banking',
        programName: record.program,
        projectId: record.projectId,
        projectName: record.projectName,
        manager: record.manager,
        effectiveDate: record.effectiveDate,
        lifecycleStatus: 'Onboarding',
        assetTag: `COG-LAP-${Math.floor(1000 + Math.random() * 9000)}`,
        serialNumber: record.assetSerialNumber || 'SN-PENDING',
        assetModel: record.assetModel || 'Standard Developer Laptop',
        assetHandoverDate: 'In Transit',
        soc2Compliant: true,
        lastAuditDate: 'Pending Clearance',
        milestones: [
          {
            id: 'm1',
            title: 'PMO Onboarding Created',
            date: record.effectiveDate,
            details: `Ariba Request: ${record.aribaRequestId}`,
            status: 'completed'
          }
        ]
      };
      setRawResources(prev => [newResource, ...prev]);
    }

    // Add in-app notification
    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'New Onboarding Record Created',
      description: `${record.associateName} added to ${record.projectName} (${record.program}).`,
      timestamp: 'Just now',
      type: 'onboarding_submitted',
      read: false,
      targetScreen: 'onboarding',
      targetId: newId
    };
    setNotifications(prev => [notif, ...prev]);
    showToast('Record Created', `Successfully initiated onboarding for ${record.associateName}.`);
  };

  const updateOnboardingRecord = (record: OnboardingRecord) => {
    if (!canEditOnboarding) {
      showToast('Permission Denied', 'Your portal role does not permit editing onboarding records.', 'warning');
      return;
    }
    setRawOnboardingRecords(prev => prev.map(r => r.id === record.id ? record : r));
    showToast('Record Updated', `Onboarding record for ${record.associateName} has been saved.`);
  };

  const updateOnboardingStatus = (id: string, status: OnboardingStatus) => {
    if (!canEditOnboarding) {
      showToast('Permission Denied', 'Your portal role does not permit editing onboarding status.', 'warning');
      return;
    }
    let associateName = '';
    setRawOnboardingRecords(prev => prev.map(r => {
      if (r.id === id) {
        associateName = r.associateName;
        let step = r.currentLifecycleStep;
        if (status === 'Draft') step = 1;
        else if (status === 'Submitted') step = 2;
        else if (status === 'In Progress') step = 3;
        else if (status === 'Pending') step = 4;
        else if (status === 'Completed') step = 5;
        return { ...r, status, currentLifecycleStep: step };
      }
      return r;
    }));

    // If marked completed, update resource status
    if (status === 'Completed') {
      setRawResources(prev => prev.map(res => {
        const matching = rawOnboardingRecords.find(r => r.id === id);
        if (matching && (res.id === matching.associateId || res.name === matching.associateName)) {
          return { ...res, lifecycleStatus: 'Active' };
        }
        return res;
      }));
    }

    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Onboarding Status Updated',
      description: `${associateName || 'Record'} marked as ${status}.`,
      timestamp: 'Just now',
      type: 'status_changed',
      read: false,
      targetScreen: 'onboarding',
      targetId: id
    };
    setNotifications(prev => [notif, ...prev]);
    showToast('Status Updated', `Status updated to ${status} for ${associateName || 'record'}.`);
  };

  const addOffboardingRecord = (record: Omit<OffboardingRecord, 'id'>) => {
    if (!canInitiateOffboarding) {
      showToast('Permission Denied', 'Your portal role is not permitted to initiate offboarding records.', 'warning');
      return;
    }
    const baseId = `OFF-${record.associateId || Date.now().toString().slice(-6)}`;
    let newId = baseId;
    let counter = 1;
    while (rawOffboardingRecords.some(r => r.id === newId)) {
      newId = `${baseId}-${counter}`;
      counter++;
    }
    const newRecord: OffboardingRecord = {
      ...record,
      id: newId
    };
    setRawOffboardingRecords(prev => [newRecord, ...prev]);

    // Update resource lifecycleStatus to 'Offboarding'
    setRawResources(prev => prev.map(res => {
      if (res.id === record.associateId || res.name === record.associateName) {
        return {
          ...res,
          lifecycleStatus: 'Offboarding',
          milestones: [
            ...res.milestones,
            {
              id: `m-${Date.now()}`,
              title: 'Offboarding Scheduled',
              date: record.lastWorkingDate,
              details: `Roll-off scheduled. Return asset: ${record.assetStatus}`,
              status: 'in_progress'
            }
          ]
        };
      }
      return res;
    }));

    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Offboarding Initiated',
      description: `Roll-off sequence started for ${record.associateName} (LWD: ${record.lastWorkingDate}).`,
      timestamp: 'Just now',
      type: 'offboarding_submitted',
      read: false,
      targetScreen: 'offboarding',
      targetId: newId
    };
    setNotifications(prev => [notif, ...prev]);
    showToast('Offboarding Initiated', `Offboarding process started for ${record.associateName}.`);
  };

  const updateOffboardingRecord = (record: OffboardingRecord) => {
    if (!canEditOffboarding) {
      showToast('Permission Denied', 'Your portal role does not permit editing offboarding records.', 'warning');
      return;
    }
    setRawOffboardingRecords(prev => prev.map(r => r.id === record.id ? record : r));
    showToast('Record Updated', `Offboarding record for ${record.associateName} updated.`);
  };

  const updateOffboardingStatus = (id: string, status: OffboardingStatus) => {
    if (!canEditOffboarding) {
      showToast('Permission Denied', 'Your portal role does not permit editing offboarding status.', 'warning');
      return;
    }
    let associateName = '';
    setRawOffboardingRecords(prev => prev.map(r => {
      if (r.id === id) {
        associateName = r.associateName;
        return { ...r, status, completionDate: status === 'Completed' ? new Date().toISOString().split('T')[0] : r.completionDate };
      }
      return r;
    }));

    if (status === 'Completed') {
      setRawResources(prev => prev.map(res => {
        const matching = rawOffboardingRecords.find(r => r.id === id);
        if (matching && (res.id === matching.associateId || res.name === matching.associateName)) {
          return { ...res, lifecycleStatus: 'Completed' };
        }
        return res;
      }));
    }

    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Offboarding Status Updated',
      description: `${associateName || 'Record'} marked as ${status}.`,
      timestamp: 'Just now',
      type: 'status_changed',
      read: false,
      targetScreen: 'offboarding',
      targetId: id
    };
    setNotifications(prev => [notif, ...prev]);
    showToast('Status Updated', `Offboarding status changed to ${status}.`);
  };

  // PMO Action Items Handlers
  const remindApprover = (recordId: string) => {
    if (!canPerformOperationalActions) {
      showToast('Permission Denied', 'Your portal role cannot trigger operational actions.', 'warning');
      return;
    }
    const record = onboardingRecords.find(r => r.id === recordId);
    showToast(
      'Approver Reminded',
      `Sent high-priority governance reminder to budget approver for Ariba Request #${record?.aribaRequestId || 'ARB-88319'}.`,
      'info'
    );
  };

  const checkCarrier = (trackingNumber: string, carrier?: string) => {
    openTrackingModal(trackingNumber, carrier);
    showToast(
      'Carrier Synced',
      `Live status for tracking #${trackingNumber}: Package scanned at regional distribution center. Telemetry checkpoint active.`,
      'info'
    );
  };

  const escalateRecord = (recordId: string) => {
    if (!canPerformOperationalActions) {
      showToast('Permission Denied', 'Your portal role cannot trigger escalations.', 'warning');
      return;
    }
    const record = onboardingRecords.find(r => r.id === recordId);
    showToast(
      'Ticket Escalated',
      `Escalated InfoSec ticket for ${record?.associateName || 'Elena Rostova'} to Tier-2 Security Lead Marcus Chen.`,
      'warning'
    );
  };

  const triggerPickup = (recordId: string) => {
    if (!canPerformOperationalActions) {
      showToast('Permission Denied', 'Your portal role cannot dispatch courier pickups.', 'warning');
      return;
    }
    const record = offboardingRecords.find(r => r.id === recordId);
    setRawOffboardingRecords(prev => prev.map(r => {
      if (r.id === recordId) {
        return {
          ...r,
          assetStatus: 'LAPTOP PICKUP SCHEDULED',
          blocker: null,
          blockerAction: null,
          status: 'In Progress'
        };
      }
      return r;
    }));
    showToast(
      'Pickup Scheduled',
      `Automated courier pickup dispatched for ${record?.associateName || 'Michael Chang'}. Return kit #UPS88219 confirmed.`,
      'success'
    );
  };

  // Notification actions
  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('Notifications Cleared', 'All alerts marked as read.');
  };

  const unreadNotificationCount = useMemo(() => {
    return notifications.filter(n => !n.read).length;
  }, [notifications]);

  // Master Data Admin Actions
  const addUser = (userData: Omit<PortalUser, 'id' | 'lastActive'>) => {
    const newUser: PortalUser = {
      ...userData,
      id: `usr-${Date.now()}`,
      lastActive: 'Just registered'
    };
    setUsers(prev => [...prev, newUser]);
    showToast('User Added', `Created portal account for ${userData.name} with role ${userData.role}.`);
  };

  const updateUser = (id: string, data: Partial<PortalUser>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...data } : u));
    showToast('User Updated', 'Portal user details saved.');
  };

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const nextStatus = u.status === 'Active' ? 'Inactive' : 'Active';
        return { ...u, status: nextStatus };
      }
      return u;
    }));
    showToast('User Status Updated', 'Updated user access status.');
  };

  const deleteUser = (id: string) => {
    const target = users.find(u => u.id === id);
    if (!target) return { success: false, message: 'User not found.' };

    // Seeded demo personas are part of the portal's role-testing foundation and
    // must never be destructively deleted. They can still be deactivated.
    if (INITIAL_USERS.some(u => u.id === id)) {
      return { success: false, message: 'Seeded demo users cannot be deleted. Deactivate the user instead.' };
    }

    const referencedAsManager = rawOnboardingRecords.some(r => r.manager === target.name) ||
      rawOffboardingRecords.some(r => r.manager === target.name);
    if (referencedAsManager) {
      return { success: false, message: 'This user is referenced by lifecycle records. Deactivate the user instead to preserve history.' };
    }

    setUsers(prev => prev.filter(u => u.id !== id));
    showToast('User Deleted', `${target.name} was removed from portal users.`);
    return { success: true, message: 'User deleted.' };
  };

  const addAccount = (nameOrData: string | { name: string; code: string; description?: string }, codeStr?: string) => {
    const name = typeof nameOrData === 'string' ? nameOrData : nameOrData.name;
    const code = typeof nameOrData === 'string' ? (codeStr || 'NEW') : nameOrData.code;
    const description = typeof nameOrData === 'object' ? nameOrData.description : undefined;
    const newAcc: Account = {
      id: `acc-${Date.now()}`,
      name,
      code,
      description,
      status: 'Active',
      programs: []
    };
    setAccounts(prev => [...prev, newAcc]);
    showToast('Account Added', `Added ${name} to organizational hierarchy.`);
  };

  const updateAccount = (id: string, data: Partial<Account>) => {
    setAccounts(prev => prev.map(a => a.id === id ? { ...a, ...data } : a));
    showToast('Account Updated', 'Account details have been saved.');
  };

  const toggleAccountStatus = (id: string) => {
    setAccounts(prev => prev.map(a => {
      if (a.id === id) {
        return { ...a, status: a.status === 'Active' ? 'Inactive' : 'Active' };
      }
      return a;
    }));
    showToast('Status Updated', 'Account active status changed.');
  };

  const addProgram = (accountIdOrData: string | { accountId: string; name: string; code: string }, nameStr?: string, codeStr?: string) => {
    const accountId = typeof accountIdOrData === 'string' ? accountIdOrData : accountIdOrData.accountId;
    const name = typeof accountIdOrData === 'string' ? (nameStr || '') : accountIdOrData.name;
    const code = typeof accountIdOrData === 'string' ? (codeStr || name.slice(0, 3).toUpperCase()) : accountIdOrData.code;

    setAccounts(prev => prev.map(a => {
      if (a.id === accountId) {
        const newProg: Program = {
          id: `prog-${Date.now()}`,
          name,
          code,
          accountId,
          status: 'Active',
          projects: []
        };
        return { ...a, programs: [...a.programs, newProg] };
      }
      return a;
    }));
    showToast('Program Added', `Program ${name} created under account.`);
  };

  const updateProgram = (id: string, data: Partial<Program>) => {
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.map(p => p.id === id ? { ...p, ...data } : p)
    })));
    showToast('Program Updated', 'Program details have been saved.');
  };

  const toggleProgramStatus = (id: string) => {
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.map(p => {
        if (p.id === id) {
          return { ...p, status: p.status === 'Active' ? 'Inactive' : 'Active' };
        }
        return p;
      })
    })));
    showToast('Status Updated', 'Program active status changed.');
  };

  const addProject = (
    programIdOrData: string | { programId: string; name: string; code: string; manager: string; location?: string },
    nameStr?: string,
    codeStr?: string,
    managerStr?: string,
    locationStr?: string
  ) => {
    const programId = typeof programIdOrData === 'string' ? programIdOrData : programIdOrData.programId;
    const name = typeof programIdOrData === 'string' ? (nameStr || '') : programIdOrData.name;
    const code = typeof programIdOrData === 'string' ? (codeStr || '') : programIdOrData.code;
    const manager = typeof programIdOrData === 'string' ? (managerStr || 'Lead Manager') : programIdOrData.manager;
    const location = typeof programIdOrData === 'string' ? locationStr : programIdOrData.location;

    setAccounts(prev => prev.map(a => {
      const hasProg = a.programs.some(p => p.id === programId);
      if (!hasProg) return a;
      return {
        ...a,
        programs: a.programs.map(p => {
          if (p.id === programId) {
            const newPrj: Project = {
              id: `prj-${Date.now()}`,
              code,
              name,
              programId,
              manager,
              location: location || 'Mountain View, CA',
              activeCount: 1,
              status: 'Active'
            };
            return { ...p, projects: [...p.projects, newPrj] };
          }
          return p;
        })
      };
    }));
    showToast('Project Added', `Project ${name} created.`);
  };

  const updateProject = (id: string, data: Partial<Project>) => {
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.map(p => ({
        ...p,
        projects: p.projects.map(prj => prj.id === id ? { ...prj, ...data } : prj)
      }))
    })));
    showToast('Project Updated', 'Project details have been saved.');
  };

  const toggleProjectStatus = (id: string) => {
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.map(p => ({
        ...p,
        projects: p.projects.map(prj => {
          if (prj.id === id) {
            return { ...prj, status: prj.status === 'Active' ? 'Inactive' : 'Active' };
          }
          return prj;
        })
      }))
    })));
    showToast('Status Updated', 'Project active status changed.');
  };

  const addManager = (data: { name: string; email: string }) => {
    const newMgr: ManagerItem = {
      id: `mgr-${Date.now()}`,
      name: data.name,
      email: data.email,
      status: 'Active'
    };
    setManagers(prev => [...prev, newMgr]);
    showToast('Manager Added', `Added ${data.name} to managers.`);
  };

  const updateManager = (id: string, data: Partial<ManagerItem>) => {
    setManagers(prev => prev.map(m => m.id === id ? { ...m, ...data } : m));
    showToast('Manager Updated', 'Manager details saved.');
  };

  const toggleManagerStatus = (id: string) => {
    setManagers(prev => prev.map(m => {
      if (m.id === id) {
        return { ...m, status: m.status === 'Active' ? 'Inactive' : 'Active' };
      }
      return m;
    }));
    showToast('Status Updated', 'Manager active status changed.');
  };

  const addLocation = (data: { name: string; city: string; state: string; country: string }) => {
    const newLoc: LocationItem = {
      id: `loc-${Date.now()}`,
      name: data.name,
      city: data.city,
      state: data.state,
      country: data.country,
      status: 'Active'
    };
    setLocations(prev => [...prev, newLoc]);
    showToast('Location Added', `Added ${data.name} to locations.`);
  };

  const updateLocation = (id: string, data: Partial<LocationItem>) => {
    setLocations(prev => prev.map(l => l.id === id ? { ...l, ...data } : l));
    showToast('Location Updated', 'Location details saved.');
  };

  const toggleLocationStatus = (id: string) => {
    setLocations(prev => prev.map(l => {
      if (l.id === id) {
        return { ...l, status: l.status === 'Active' ? 'Inactive' : 'Active' };
      }
      return l;
    }));
    showToast('Status Updated', 'Location active status changed.');
  };

  const addReferenceItem = (data: { name: string; category: 'delivery_method' | 'return_carrier' | 'hardware_model'; description?: string }) => {
    const newItem: ReferenceItem = {
      id: `ref-${Date.now()}`,
      name: data.name,
      category: data.category,
      description: data.description,
      status: 'Active'
    };
    if (data.category === 'delivery_method') {
      setDeliveryMethods(prev => [...prev, newItem]);
      showToast('Delivery Method Added', `Added ${data.name}.`);
    } else if (data.category === 'return_carrier') {
      setReturnCarriers(prev => [...prev, newItem]);
      showToast('Return Carrier Added', `Added ${data.name}.`);
    } else {
      setHardwareModels(prev => [...prev, newItem]);
      showToast('Hardware Model Added', `Added ${data.name}.`);
    }
  };

  const updateReferenceItem = (id: string, data: Partial<ReferenceItem>) => {
    setDeliveryMethods(prev => prev.map(item => item.id === id ? { ...item, ...data } : item));
    setReturnCarriers(prev => prev.map(item => item.id === id ? { ...item, ...data } : item));
    setHardwareModels(prev => prev.map(item => item.id === id ? { ...item, ...data } : item));
    showToast('Reference Item Updated', 'Saved changes.');
  };

  const toggleReferenceItemStatus = (id: string) => {
    setDeliveryMethods(prev => prev.map(item => item.id === id ? { ...item, status: item.status === 'Active' ? 'Inactive' : 'Active' } : item));
    setReturnCarriers(prev => prev.map(item => item.id === id ? { ...item, status: item.status === 'Active' ? 'Inactive' : 'Active' } : item));
    setHardwareModels(prev => prev.map(item => item.id === id ? { ...item, status: item.status === 'Active' ? 'Inactive' : 'Active' } : item));
    showToast('Status Updated', 'Reference item status changed.');
  };

  const checkItemInUse = (
    type: 'account' | 'program' | 'project' | 'manager' | 'location' | 'delivery_method' | 'return_carrier' | 'hardware_model',
    id: string,
    name?: string
  ): { inUse: boolean; count: number; details: string } => {
    const normName = (name || '').toLowerCase();

    switch (type) {
      case 'account': {
        const acc = accounts.find(a => a.id === id);
        const accName = (acc?.name || name || '').toLowerCase();
        const onbCount = onboardingRecords.filter(r => r.account.toLowerCase() === accName).length;
        const offbCount = offboardingRecords.filter(r => r.account.toLowerCase() === accName).length;
        const resCount = resources.filter(r => r.accountName.toLowerCase() === accName || r.accountId === id).length;
        const total = onbCount + offbCount + resCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Referenced by ${onbCount} onboarding records, ${offbCount} offboarding records, and ${resCount} active resources.`
          };
        }
        if (acc && acc.programs.length > 0) {
          return {
            inUse: true,
            count: acc.programs.length,
            details: `Contains ${acc.programs.length} active program streams. Remove programs or deactivate this account.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'program': {
        let progName = normName;
        let progProjectsCount = 0;
        for (const a of accounts) {
          const found = a.programs.find(p => p.id === id);
          if (found) {
            progName = found.name.toLowerCase();
            progProjectsCount = found.projects.length;
            break;
          }
        }
        const onbCount = onboardingRecords.filter(r => r.program.toLowerCase() === progName).length;
        const offbCount = offboardingRecords.filter(r => r.program.toLowerCase() === progName).length;
        const resCount = resources.filter(r => r.programName.toLowerCase() === progName || r.programId === id).length;
        const total = onbCount + offbCount + resCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Referenced by ${onbCount} onboarding records, ${offbCount} offboarding records, and ${resCount} resources.`
          };
        }
        if (progProjectsCount > 0) {
          return {
            inUse: true,
            count: progProjectsCount,
            details: `Contains ${progProjectsCount} project work orders. Delete projects first or deactivate this program.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'project': {
        let prjCode = '';
        let prjName = normName;
        for (const a of accounts) {
          for (const p of a.programs) {
            const found = p.projects.find(prj => prj.id === id);
            if (found) {
              prjCode = found.code.toLowerCase();
              prjName = found.name.toLowerCase();
              break;
            }
          }
        }
        const onbCount = onboardingRecords.filter(r => 
          r.projectId.toLowerCase() === id.toLowerCase() || 
          (prjCode && r.projectId.toLowerCase() === prjCode) || 
          r.projectName.toLowerCase() === prjName
        ).length;
        const offbCount = offboardingRecords.filter(r => 
          r.projectId.toLowerCase() === id.toLowerCase() || 
          (prjCode && r.projectId.toLowerCase() === prjCode) || 
          r.projectName.toLowerCase() === prjName
        ).length;
        const resCount = resources.filter(r => 
          r.projectId.toLowerCase() === id.toLowerCase() || 
          (prjCode && r.projectId.toLowerCase() === prjCode) || 
          r.projectName.toLowerCase() === prjName
        ).length;
        const total = onbCount + offbCount + resCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Referenced by ${onbCount} onboarding records, ${offbCount} offboarding records, and ${resCount} active resources.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'manager': {
        const mgr = managers.find(m => m.id === id);
        const mgrName = (mgr?.name || name || '').toLowerCase();
        const onbCount = onboardingRecords.filter(r => r.manager.toLowerCase().includes(mgrName)).length;
        const offbCount = offboardingRecords.filter(r => r.manager.toLowerCase().includes(mgrName)).length;
        const resCount = resources.filter(r => r.manager.toLowerCase().includes(mgrName)).length;
        const prjCount = allProjects.filter(p => p.manager.toLowerCase().includes(mgrName)).length;
        const total = onbCount + offbCount + resCount + prjCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Assigned to ${prjCount} projects, ${resCount} resources, and ${onbCount + offbCount} lifecycle workflows.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'location': {
        const loc = locations.find(l => l.id === id);
        const locName = (loc?.name || name || '').toLowerCase();
        const onbCount = onboardingRecords.filter(r => r.location.toLowerCase().includes(locName)).length;
        const offbCount = offboardingRecords.filter(r => r.location.toLowerCase().includes(locName)).length;
        const resCount = resources.filter(r => r.location.toLowerCase().includes(locName)).length;
        const total = onbCount + offbCount + resCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Referenced by ${resCount} resources, ${onbCount} onboarding records, and ${offbCount} offboarding records.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'delivery_method': {
        const dm = deliveryMethods.find(d => d.id === id);
        const dmName = (dm?.name || name || '').toLowerCase();
        const onbCount = onboardingRecords.filter(r => r.dispatchMethod.toLowerCase().includes(dmName)).length;
        if (onbCount > 0) {
          return {
            inUse: true,
            count: onbCount,
            details: `Configured on ${onbCount} hardware dispatch records.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'return_carrier': {
        const rc = returnCarriers.find(c => c.id === id);
        const rcName = (rc?.name || name || '').toLowerCase();
        const offbCount = offboardingRecords.filter(r => r.carrier.toLowerCase().includes(rcName)).length;
        if (offbCount > 0) {
          return {
            inUse: true,
            count: offbCount,
            details: `Configured on ${offbCount} asset return records.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      case 'hardware_model': {
        const hm = hardwareModels.find(h => h.id === id);
        const hmName = (hm?.name || name || '').toLowerCase();
        const onbCount = onboardingRecords.filter(r => (r.assetModel || '').toLowerCase().includes(hmName)).length;
        const resCount = resources.filter(r => (r.assetModel || '').toLowerCase().includes(hmName)).length;
        const total = onbCount + resCount;
        if (total > 0) {
          return {
            inUse: true,
            count: total,
            details: `Assigned to ${onbCount} onboarding records and ${resCount} provisioned resource devices.`
          };
        }
        return { inUse: false, count: 0, details: '' };
      }

      default:
        return { inUse: false, count: 0, details: '' };
    }
  };

  const deleteAccount = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const inUseCheck = checkItemInUse('account', id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Account', `Account is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setAccounts(prev => prev.filter(a => a.id !== id));
    showToast('Account Deleted', 'Unused account was permanently deleted.', 'info');
    return { success: true };
  };

  const deleteProgram = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const inUseCheck = checkItemInUse('program', id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Program', `Program is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.filter(p => p.id !== id)
    })));
    showToast('Program Deleted', 'Unused program was permanently deleted.', 'info');
    return { success: true };
  };

  const deleteProject = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const inUseCheck = checkItemInUse('project', id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Project', `Project is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setAccounts(prev => prev.map(a => ({
      ...a,
      programs: a.programs.map(p => ({
        ...p,
        projects: p.projects.filter(prj => prj.id !== id)
      }))
    })));
    showToast('Project Deleted', 'Unused project was permanently deleted.', 'info');
    return { success: true };
  };

  const deleteManager = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const inUseCheck = checkItemInUse('manager', id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Manager', `Manager is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setManagers(prev => prev.filter(m => m.id !== id));
    showToast('Manager Deleted', 'Unused manager removed.', 'info');
    return { success: true };
  };

  const deleteLocation = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const inUseCheck = checkItemInUse('location', id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Location', `Location is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setLocations(prev => prev.filter(l => l.id !== id));
    showToast('Location Deleted', 'Unused location removed.', 'info');
    return { success: true };
  };

  const deleteReferenceItem = (id: string): { success: boolean; inUse?: boolean; message?: string } => {
    const item = deliveryMethods.find(d => d.id === id) || returnCarriers.find(r => r.id === id) || hardwareModels.find(h => h.id === id);
    const type = item?.category === 'return_carrier' ? 'return_carrier' : item?.category === 'hardware_model' ? 'hardware_model' : 'delivery_method';
    const inUseCheck = checkItemInUse(type, id);
    if (inUseCheck.inUse) {
      showToast('Cannot Delete Item', `Reference item is currently in use: ${inUseCheck.details}`, 'warning');
      return { success: false, inUse: true, message: inUseCheck.details };
    }
    setDeliveryMethods(prev => prev.filter(d => d.id !== id));
    setReturnCarriers(prev => prev.filter(r => r.id !== id));
    setHardwareModels(prev => prev.filter(h => h.id !== id));
    showToast('Item Deleted', 'Unused reference item removed.', 'info');
    return { success: true };
  };

  return (
    <AppContext.Provider
      value={{
        activeScreen,
        setActiveScreen,
        currentRole,
        setCurrentRole,
        selectedAccount,
        setSelectedAccount,
        filters,
        setFilter,
        resetFilters,

        currentUser,
        isAuthenticated: !!currentUser,
        login,
        logout,
        userAccessibleAccounts,
        canAccessScreen,
        canCreateOnboarding,
        canEditOnboarding,
        canInitiateOffboarding,
        canEditOffboarding,
        canPerformOperationalActions,
        canManageUsers,
        canManageMasterData,
        isReadOnlyRole,

        onboardingRecords,
        offboardingRecords,
        resources,
        accounts,
        allPrograms,
        allProjects,
        managers,
        locations,
        deliveryMethods,
        returnCarriers,
        hardwareModels,
        users,
        notifications,
        toasts,

        getProgramsForAccount,
        getProjectsForProgram,
        getProjectByNameOrId,
        getAvailableItems,
        checkItemInUse,
        resetMasterData,

        selectedOnboardingId,
        setSelectedOnboardingId,
        selectedOffboardingId,
        setSelectedOffboardingId,
        selectedResourceId,
        setSelectedResourceId,

        isOnboardingModalOpen,
        setIsOnboardingModalOpen,
        isOffboardingModalOpen,
        setIsOffboardingModalOpen,

        trackingModalData,
        openTrackingModal,
        closeTrackingModal,

        onboardingKpis,
        offboardingKpis,
        resourceKpis,

        addOnboardingRecord,
        updateOnboardingRecord,
        updateOnboardingStatus,

        addOffboardingRecord,
        updateOffboardingRecord,
        updateOffboardingStatus,

        remindApprover,
        checkCarrier,
        escalateRecord,
        triggerPickup,

        markNotificationRead,
        markAllNotificationsRead,
        unreadNotificationCount,

        addUser,
        updateUser,
        toggleUserStatus,
        deleteUser,

        addAccount,
        updateAccount,
        toggleAccountStatus,
        deleteAccount,

        addProgram,
        updateProgram,
        toggleProgramStatus,
        deleteProgram,

        addProject,
        updateProject,
        toggleProjectStatus,
        deleteProject,

        addManager,
        updateManager,
        toggleManagerStatus,
        deleteManager,

        addLocation,
        updateLocation,
        toggleLocationStatus,
        deleteLocation,

        addReferenceItem,
        updateReferenceItem,
        toggleReferenceItemStatus,
        deleteReferenceItem,

        showToast,
        dismissToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

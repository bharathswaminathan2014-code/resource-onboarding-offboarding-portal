import { UserRole, ScreenType, Account, Program, Project, PortalUser } from '../types';

export interface RolePermissions {
  screens: ScreenType[];
  canCreateOnboarding: boolean;
  canEditOnboarding: boolean;
  canInitiateOffboarding: boolean;
  canEditOffboarding: boolean;
  canPerformOperationalActions: boolean;
  canManageUsers: boolean;
  canManageMasterData: boolean;
  isReadOnly: boolean;
  description: string;
}

export const ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
  Executive: {
    screens: ['dashboard', 'resources', 'reports'],
    canCreateOnboarding: false,
    canEditOnboarding: false,
    canInitiateOffboarding: false,
    canEditOffboarding: false,
    canPerformOperationalActions: false,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: true,
    description: 'Executive leadership read-only visibility across metrics and portfolio reports.'
  },
  'Senior Leader': {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports'],
    canCreateOnboarding: false,
    canEditOnboarding: false,
    canInitiateOffboarding: false,
    canEditOffboarding: false,
    canPerformOperationalActions: false,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: true,
    description: 'Senior leadership oversight across resource assignments, lifecycles, and governance.'
  },
  'Senior Manager': {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports'],
    canCreateOnboarding: true,
    canEditOnboarding: true,
    canInitiateOffboarding: true,
    canEditOffboarding: true,
    canPerformOperationalActions: true,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: false,
    description: 'Operational delivery and program management within assigned organizational scope.'
  },
  Manager: {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports'],
    canCreateOnboarding: false,
    canEditOnboarding: true,
    canInitiateOffboarding: true,
    canEditOffboarding: true,
    canPerformOperationalActions: true,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: false,
    description: 'Project-level management for team members, onboarding reviews, and offboarding initiation.'
  },
  PMO: {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports'],
    canCreateOnboarding: true,
    canEditOnboarding: true,
    canInitiateOffboarding: true,
    canEditOffboarding: true,
    canPerformOperationalActions: true,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: false,
    description: 'Primary operational lifecycle authority for requisitions, courier dispatches, and compliance.'
  },
  'Operational User': {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports'],
    canCreateOnboarding: false,
    canEditOnboarding: false,
    canInitiateOffboarding: false,
    canEditOffboarding: false,
    canPerformOperationalActions: false,
    canManageUsers: false,
    canManageMasterData: false,
    isReadOnly: true,
    description: 'Standard operational viewing and track-and-trace access within assigned scope.'
  },
  Admin: {
    screens: ['dashboard', 'resources', 'onboarding', 'offboarding', 'reports', 'administration'],
    canCreateOnboarding: true,
    canEditOnboarding: true,
    canInitiateOffboarding: true,
    canEditOffboarding: true,
    canPerformOperationalActions: true,
    canManageUsers: true,
    canManageMasterData: true,
    isReadOnly: false,
    description: 'Enterprise super-administrator with full access to user directory, scopes, and master data.'
  }
};

export function canAccessScreen(role: UserRole | undefined, screen: ScreenType): boolean {
  if (!role) return false;
  const permissions = ROLE_PERMISSIONS[role];
  if (!permissions) return false;
  return permissions.screens.includes(screen);
}

export function canCreateOnboarding(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canCreateOnboarding ?? false;
}

export function canEditOnboarding(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canEditOnboarding ?? false;
}

export function canInitiateOffboarding(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canInitiateOffboarding ?? false;
}

export function canEditOffboarding(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canEditOffboarding ?? false;
}

export function canPerformOperationalActions(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canPerformOperationalActions ?? false;
}

export function canManageUsers(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canManageUsers ?? false;
}

export function canManageMasterData(role: UserRole | undefined): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.canManageMasterData ?? false;
}

export function isReadOnlyRole(role: UserRole | undefined): boolean {
  if (!role) return true;
  return ROLE_PERMISSIONS[role]?.isReadOnly ?? true;
}

/**
 * Validates whether a record (resource, onboarding, offboarding) belongs
 * to the authenticated user's organizational scope (Account -> Program -> Project).
 */
export function isRecordInScope(
  record: {
    account?: string;
    accountId?: string;
    accountName?: string;
    program?: string;
    programId?: string;
    programName?: string;
    project?: string;
    projectId?: string;
    projectName?: string;
  },
  user: PortalUser | null,
  accounts: Account[]
): boolean {
  if (!user) return false;

  // 1. Account Scope Check
  const userAccountScope = user.accountScope || 'All';
  const isAllAccounts =
    userAccountScope === 'All' ||
    userAccountScope === 'all' ||
    userAccountScope.includes('All Accounts') ||
    userAccountScope.includes('All Systems') ||
    userAccountScope.includes('Global Portfolio') ||
    userAccountScope.includes('Executive Leadership Scope');

  if (!isAllAccounts) {
    const targetAcc = accounts.find(
      a =>
        a.id.toLowerCase() === userAccountScope.toLowerCase() ||
        a.name.toLowerCase() === userAccountScope.toLowerCase() ||
        a.code.toLowerCase() === userAccountScope.toLowerCase()
    );

    const validAccountIdentifiers = [
      userAccountScope.toLowerCase(),
      ...(targetAcc
        ? [targetAcc.id.toLowerCase(), targetAcc.name.toLowerCase(), targetAcc.code.toLowerCase()]
        : [])
    ];

    const recordAccName = (record.account || record.accountName || '').toLowerCase();
    const recordAccId = (record.accountId || '').toLowerCase();

    const matchesAccount =
      validAccountIdentifiers.includes(recordAccName) ||
      (recordAccId && validAccountIdentifiers.includes(recordAccId));

    if (!matchesAccount) return false;
  }

  // 2. Program Scope Check
  const userProgScope = user.programScope || 'All';
  const isAllPrograms = !userProgScope || userProgScope === 'All' || userProgScope === 'all';

  if (!isAllPrograms) {
    const recordProgName = (record.program || record.programName || '').toLowerCase();
    const recordProgId = (record.programId || '').toLowerCase();
    const targetProgLower = userProgScope.toLowerCase();

    const matchesProgram =
      recordProgName === targetProgLower ||
      recordProgId === targetProgLower;

    if (!matchesProgram) return false;
  }

  // 3. Project Scope Check
  const userPrjScope = user.projectScope || 'All';
  const isAllProjects = !userPrjScope || userPrjScope === 'All' || userPrjScope === 'all';

  if (!isAllProjects) {
    const recordPrjName = (record.project || record.projectName || '').toLowerCase();
    const recordPrjId = (record.projectId || '').toLowerCase();
    const targetPrjLower = userPrjScope.toLowerCase();

    const matchesProject =
      recordPrjName === targetPrjLower ||
      recordPrjId === targetPrjLower;

    if (!matchesProject) return false;
  }

  return true;
}

/**
 * Returns the accounts visible to this user for dropdowns and navigation.
 */
export function getScopedAccounts(accounts: Account[], user: PortalUser | null): Account[] {
  if (!user) return [];
  const userAccountScope = user.accountScope || 'All';
  const isAllAccounts =
    userAccountScope === 'All' ||
    userAccountScope === 'all' ||
    userAccountScope.includes('All Accounts') ||
    userAccountScope.includes('All Systems') ||
    userAccountScope.includes('Global Portfolio') ||
    userAccountScope.includes('Executive Leadership Scope');

  if (isAllAccounts) return accounts;

  return accounts.filter(
    a =>
      a.id.toLowerCase() === userAccountScope.toLowerCase() ||
      a.name.toLowerCase() === userAccountScope.toLowerCase() ||
      a.code.toLowerCase() === userAccountScope.toLowerCase()
  );
}

/**
 * Returns the programs visible to this user within their scope.
 */
export function getScopedPrograms(
  programs: Program[],
  user: PortalUser | null,
  selectedAccountId?: string
): Program[] {
  if (!user) return [];

  let list = programs;
  if (selectedAccountId && selectedAccountId !== 'all') {
    list = list.filter(p => p.accountId === selectedAccountId);
  }

  const userProgScope = user.programScope || 'All';
  if (!userProgScope || userProgScope === 'All' || userProgScope === 'all') {
    return list;
  }

  const targetLower = userProgScope.toLowerCase();
  return list.filter(
    p =>
      p.id.toLowerCase() === targetLower ||
      p.name.toLowerCase() === targetLower ||
      p.name.toLowerCase().includes(targetLower) ||
      targetLower.includes(p.name.toLowerCase())
  );
}

/**
 * Returns the projects visible to this user within their scope.
 */
export function getScopedProjects(
  projects: Project[],
  user: PortalUser | null,
  selectedProgramId?: string
): Project[] {
  if (!user) return [];

  let list = projects;
  if (selectedProgramId && selectedProgramId !== 'all') {
    list = list.filter(p => p.programId === selectedProgramId);
  }

  const userPrjScope = user.projectScope || 'All';
  if (!userPrjScope || userPrjScope === 'All' || userPrjScope === 'all') {
    return list;
  }

  const targetLower = userPrjScope.toLowerCase();
  return list.filter(
    p =>
      p.id.toLowerCase() === targetLower ||
      p.name.toLowerCase() === targetLower ||
      p.code.toLowerCase() === targetLower ||
      p.name.toLowerCase().includes(targetLower) ||
      targetLower.includes(p.name.toLowerCase())
  );
}

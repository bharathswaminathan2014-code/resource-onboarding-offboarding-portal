import React, { useState } from 'react';
import { X, UserPlus, Laptop, CreditCard, Building2, MapPin } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { HardwareDeliveryStatus, OnboardingStatus } from '../../types';

export const NewOnboardingModal: React.FC = () => {
  const { 
    isOnboardingModalOpen, 
    setIsOnboardingModalOpen, 
    accounts,
    locations,
    managers,
    deliveryMethods,
    hardwareModels,
    getProgramsForAccount,
    getProjectsForProgram,
    getAvailableItems,
    addOnboardingRecord,
    showToast 
  } = useApp();

  const activeAccounts = getAvailableItems(accounts);
  const activeManagers = getAvailableItems(managers);
  const activeLocations = getAvailableItems(locations);
  const activeDeliveryMethods = getAvailableItems(deliveryMethods);
  const activeHardwareModels = getAvailableItems(hardwareModels);

  const defaultAccount = activeAccounts[0]?.name || accounts[0]?.name || 'Apex Global Financial';
  const defaultPrograms = getProgramsForAccount(defaultAccount, true);
  const defaultProgram = defaultPrograms[0]?.name || 'Digital Banking Platform';
  const defaultProjects = getProjectsForProgram(defaultProgram, defaultAccount, true);
  const defaultProject = defaultProjects[0];

  const [formData, setFormData] = useState({
    associateId: `20${Math.floor(10000 + Math.random() * 90000)}`,
    associateName: '',
    role: 'Senior Software Engineer',
    phone: '+1 408-555-0100',
    cognizantEmail: '',
    clientEmail: '',
    address: '100 Silicon Way',
    city: 'Mountain View',
    state: 'CA',
    location: activeLocations[0]?.name || locations[0]?.name || 'Mountain View, CA',
    account: defaultAccount,
    program: defaultProgram,
    projectId: defaultProject?.code || defaultProject?.id || 'PRJ-AGF-042',
    projectName: defaultProject?.name || 'Core Ledger API',
    manager: defaultProject?.manager || activeManagers[0]?.name || managers[0]?.name || 'Robert Chen',
    effectiveDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    status: 'Submitted' as OnboardingStatus,
    currentLifecycleStep: 2,
    aribaRequestId: `ARB-${Math.floor(80000 + Math.random() * 10000)}`,
    amount: 14500,
    invoiceNumber: `INV-2024-${Math.floor(100 + Math.random() * 900)}`,
    assetModel: activeHardwareModels[0]?.name || hardwareModels[0]?.name || 'Apple MacBook Pro 16" (M3 Max)',
    assetSerialNumber: `C02K${Math.floor(1000 + Math.random() * 9000)}`,
    dispatchMethod: activeDeliveryMethods[0]?.name || deliveryMethods[0]?.name || 'FedEx Express Air',
    trackingNumber: `${Math.floor(700000000 + Math.random() * 200000000)}`,
    deliveryStatus: 'Pending Build' as HardwareDeliveryStatus,
    deliveryDate: new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
    receiptSignature: 'Pending Dispatch'
  });

  const availableAccounts = getAvailableItems(accounts, formData.account);
  const availablePrograms = getProgramsForAccount(formData.account, true, formData.program);
  const availableProjects = getProjectsForProgram(formData.program, formData.account, true, formData.projectName);
  const availableManagers = getAvailableItems(managers, formData.manager);
  const availableLocations = getAvailableItems(locations, formData.location);
  const availableDeliveryMethods = getAvailableItems(deliveryMethods, formData.dispatchMethod);
  const availableHardwareModels = getAvailableItems(hardwareModels, formData.assetModel);

  const handleAccountChange = (accountName: string) => {
    const progs = getProgramsForAccount(accountName, true);
    const firstProg = progs[0]?.name || '';
    const prjs = getProjectsForProgram(firstProg, accountName, true);
    const firstPrj = prjs[0];

    setFormData(prev => ({
      ...prev,
      account: accountName,
      program: firstProg,
      projectId: firstPrj?.code || firstPrj?.id || '',
      projectName: firstPrj?.name || '',
      manager: firstPrj?.manager || activeManagers[0]?.name || prev.manager,
      location: firstPrj?.location || activeLocations[0]?.name || prev.location
    }));
  };

  const handleProgramChange = (progName: string) => {
    const prjs = getProjectsForProgram(progName, formData.account, true);
    const firstPrj = prjs[0];

    setFormData(prev => ({
      ...prev,
      program: progName,
      projectId: firstPrj?.code || firstPrj?.id || '',
      projectName: firstPrj?.name || '',
      manager: firstPrj?.manager || activeManagers[0]?.name || prev.manager,
      location: firstPrj?.location || activeLocations[0]?.name || prev.location
    }));
  };

  const handleProjectChange = (projectName: string) => {
    const prjs = getProjectsForProgram(formData.program, formData.account, true);
    const chosenPrj = prjs.find(p => p.name === projectName || p.id === projectName || p.code === projectName);
    if (chosenPrj) {
      setFormData(prev => ({
        ...prev,
        projectId: chosenPrj.code || chosenPrj.id,
        projectName: chosenPrj.name,
        manager: chosenPrj.manager || prev.manager,
        location: chosenPrj.location || prev.location
      }));
    }
  };

  React.useEffect(() => {
    if (!isOnboardingModalOpen) return;
    const currentAccountActive = activeAccounts.some(a => a.name === formData.account);
    const targetAccount = currentAccountActive ? formData.account : (activeAccounts[0]?.name || '');
    
    const progs = getProgramsForAccount(targetAccount, true);
    const currentProgActive = progs.some(p => p.name === formData.program);
    const targetProg = currentProgActive ? formData.program : (progs[0]?.name || '');

    const prjs = getProjectsForProgram(targetProg, targetAccount, true);
    const currentPrjActive = prjs.some(p => p.name === formData.projectName);
    const targetPrj = currentPrjActive ? prjs.find(p => p.name === formData.projectName) : prjs[0];

    const currentMgrActive = activeManagers.some(m => m.name === formData.manager);
    const targetMgr = currentMgrActive ? formData.manager : (targetPrj?.manager || activeManagers[0]?.name || '');

    const currentLocActive = activeLocations.some(l => l.name === formData.location);
    const targetLoc = currentLocActive ? formData.location : (targetPrj?.location || activeLocations[0]?.name || '');

    const currentDmActive = activeDeliveryMethods.some(d => d.name === formData.dispatchMethod);
    const targetDm = currentDmActive ? formData.dispatchMethod : (activeDeliveryMethods[0]?.name || '');

    setFormData(prev => ({
      ...prev,
      account: targetAccount,
      program: targetProg,
      projectId: targetPrj?.code || targetPrj?.id || prev.projectId,
      projectName: targetPrj?.name || prev.projectName,
      manager: targetMgr,
      location: targetLoc,
      dispatchMethod: targetDm
    }));
  }, [isOnboardingModalOpen]);

  if (!isOnboardingModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.associateName.trim()) {
      showToast('Validation Error', 'Please enter the associate name.', 'error');
      return;
    }

    const emailPrefix = formData.associateName.toLowerCase().replace(/\s+/g, '.');
    const cognizantEmail = formData.cognizantEmail || `${emailPrefix}@cognizant.com`;
    const clientEmail = formData.clientEmail || `${emailPrefix}@clientcorp.com`;

    addOnboardingRecord({
      ...formData,
      cognizantEmail,
      clientEmail
    });

    setIsOnboardingModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-700">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Initiate New Resource Onboarding</h3>
              <p className="text-xs text-slate-500">Intake after HR candidate selection for PMO lifecycle governance</p>
            </div>
          </div>
          <button
            onClick={() => setIsOnboardingModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-xs flex-1">
          {/* Section 1: Resource Profile */}
          <div>
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <UserPlus className="w-3.5 h-3.5 text-blue-600" />
              <span>1. Resource Profile &amp; Contact</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Associate ID</label>
                <input
                  type="text"
                  required
                  value={formData.associateId}
                  onChange={e => setFormData({ ...formData, associateId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Associate Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alexander Mitchell"
                  value={formData.associateName}
                  onChange={e => setFormData({ ...formData, associateName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-900 font-semibold focus:bg-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Role / Job Title</label>
                <input
                  type="text"
                  required
                  value={formData.role}
                  onChange={e => setFormData({ ...formData, role: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Residential Shipping Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Location / Work Mode</label>
                <select
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableLocations.map(loc => (
                    <option key={loc.id} value={loc.name}>
                      {loc.name}{loc.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Hierarchy & Assignment */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>2. Account &amp; Project Assignment</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Account</label>
                <select
                  value={formData.account}
                  onChange={e => handleAccountChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableAccounts.map(a => (
                    <option key={a.id} value={a.name}>
                      {a.name}{a.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Program</label>
                <select
                  value={formData.program}
                  onChange={e => handleProgramChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availablePrograms.map(p => (
                    <option key={p.id} value={p.name}>
                      {p.name}{p.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Project Code &amp; Name</label>
                <select
                  value={formData.projectName}
                  onChange={e => handleProjectChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableProjects.map(prj => (
                    <option key={prj.id} value={prj.name}>
                      {prj.code} - {prj.name}{prj.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">PMO Manager</label>
                <select
                  value={formData.manager}
                  onChange={e => setFormData({ ...formData, manager: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableManagers.map(mgr => (
                    <option key={mgr.id} value={mgr.name}>
                      {mgr.name}{mgr.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Effective Start Date</label>
                <input
                  type="date"
                  required
                  value={formData.effectiveDate}
                  onChange={e => setFormData({ ...formData, effectiveDate: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Initial Status</label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as OnboardingStatus })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-semibold"
                >
                  <option value="Draft">Draft</option>
                  <option value="Submitted">Submitted (Review)</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Pending">Pending Action</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Commercials & Procurement */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <CreditCard className="w-3.5 h-3.5 text-blue-600" />
              <span>3. Commercials (Ariba Billing)</span>
            </h4>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Ariba Request ID</label>
                <input
                  type="text"
                  value={formData.aribaRequestId}
                  onChange={e => setFormData({ ...formData, aribaRequestId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Monthly Billing ($)</label>
                <input
                  type="number"
                  value={formData.amount}
                  onChange={e => setFormData({ ...formData, amount: Number(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Invoice Reference</label>
                <input
                  type="text"
                  value={formData.invoiceNumber}
                  onChange={e => setFormData({ ...formData, invoiceNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Hardware Asset Logistics */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <Laptop className="w-3.5 h-3.5 text-blue-600" />
              <span>4. Hardware Asset Logistics</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Hardware Model</label>
                <select
                  value={formData.assetModel}
                  onChange={e => setFormData({ ...formData, assetModel: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableHardwareModels.map(hm => (
                    <option key={hm.id} value={hm.name}>
                      {hm.name}{hm.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Serial Number</label>
                <input
                  type="text"
                  value={formData.assetSerialNumber}
                  onChange={e => setFormData({ ...formData, assetSerialNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Dispatch Method</label>
                <select
                  value={formData.dispatchMethod}
                  onChange={e => setFormData({ ...formData, dispatchMethod: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableDeliveryMethods.map(dm => (
                    <option key={dm.id} value={dm.name}>
                      {dm.name}{dm.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Tracking Number</label>
                <input
                  type="text"
                  value={formData.trackingNumber}
                  onChange={e => setFormData({ ...formData, trackingNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Delivery Status</label>
                <select
                  value={formData.deliveryStatus}
                  onChange={e => setFormData({ ...formData, deliveryStatus: e.target.value as HardwareDeliveryStatus })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  <option value="Pending Build">Pending Build</option>
                  <option value="Dispatched">Dispatched</option>
                  <option value="Configured">Configured</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsOnboardingModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold uppercase tracking-wider bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              Create Onboarding Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Laptop, 
  CreditCard, 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Truck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OnboardingStatus } from '../../types';

export const OnboardingDetailDrawer: React.FC = () => {
  const {
    selectedOnboardingId,
    setSelectedOnboardingId,
    onboardingRecords,
    updateOnboardingStatus,
    updateOnboardingRecord,
    checkCarrier,
    remindApprover,
    showToast
  } = useApp();

  const record = onboardingRecords.find(r => r.id === selectedOnboardingId);

  const [currentStatus, setCurrentStatus] = useState<OnboardingStatus>(record?.status || 'In Progress');

  if (!selectedOnboardingId || !record) return null;

  const steps = [
    { num: 1, label: 'Draft' },
    { num: 2, label: 'Submitted' },
    { num: 3, label: 'In Progress' },
    { num: 4, label: 'Pending Access' },
    { num: 5, label: 'Completed' }
  ];

  const handleStatusChange = (newStatus: OnboardingStatus) => {
    setCurrentStatus(newStatus);
    updateOnboardingStatus(record.id, newStatus);
  };

  const advanceStep = () => {
    const nextStep = Math.min(5, record.currentLifecycleStep + 1);
    let nextStatus: OnboardingStatus = 'In Progress';
    if (nextStep === 2) nextStatus = 'Submitted';
    if (nextStep === 3) nextStatus = 'In Progress';
    if (nextStep === 4) nextStatus = 'Pending';
    if (nextStep === 5) nextStatus = 'Completed';

    updateOnboardingRecord({
      ...record,
      currentLifecycleStep: nextStep,
      status: nextStatus
    });
    showToast('Lifecycle Step Advanced', `Advanced to Step ${nextStep}: ${steps[nextStep - 1].label}`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-250 border-l border-slate-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/80 sticky top-0 z-10">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[0.68rem] font-extrabold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  ACTIVE RECORD ID: {record.id}
                </span>
                <span className={`text-[0.68rem] font-bold uppercase px-2 py-0.5 rounded-full border ${
                  record.status === 'Delayed' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                  record.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                  record.status === 'In Progress' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                  'bg-amber-100 text-amber-700 border-amber-200'
                }`}>
                  {record.status}
                </span>
              </div>
              <h2 className="text-lg font-black text-slate-900 mt-1">
                {record.associateName}
              </h2>
              <p className="text-xs text-slate-600 font-medium">
                {record.role} • {record.program} ({record.projectName})
              </p>
            </div>
            <button
              onClick={() => setSelectedOnboardingId(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Progression */}
          <div className="mt-5 pt-3 border-t border-slate-200/80">
            <div className="flex items-center justify-between relative">
              <div className="absolute top-1/2 left-4 right-4 -translate-y-1/2 h-0.5 bg-slate-200 -z-0" />
              {steps.map(step => {
                const isCompleted = step.num < record.currentLifecycleStep || record.status === 'Completed';
                const isCurrent = step.num === record.currentLifecycleStep && record.status !== 'Completed';

                return (
                  <div key={step.num} className="relative z-10 flex flex-col items-center">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isCompleted 
                        ? 'bg-emerald-600 text-white shadow-xs' 
                        : isCurrent 
                        ? 'bg-blue-600 text-white ring-4 ring-blue-100' 
                        : 'bg-white border-2 border-slate-300 text-slate-400'
                    }`}>
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : step.num}
                    </div>
                    <span className={`text-[0.65rem] font-bold mt-1 text-center whitespace-nowrap ${
                      isCurrent ? 'text-blue-700' : isCompleted ? 'text-emerald-700' : 'text-slate-400'
                    }`}>
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Drawer Body Content */}
        <div className="p-5 space-y-6 text-xs">
          {/* Active Blocker Alert (if any) */}
          {record.blocker && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="font-bold text-rose-900 text-xs">High Governance Gating Bottleneck</div>
                  <p className="text-[0.72rem] text-rose-700 mt-0.5 leading-relaxed">{record.blocker}</p>
                </div>
              </div>
              {record.blockerAction && (
                <button
                  onClick={() => {
                    if (record.blockerAction === 'REMIND APPROVER') remindApprover(record.id);
                    else if (record.blockerAction === 'CHECK CARRIER') checkCarrier(record.trackingNumber);
                  }}
                  className="px-2.5 py-1 text-[0.65rem] font-bold uppercase bg-rose-600 text-white rounded hover:bg-rose-700 whitespace-nowrap cursor-pointer"
                >
                  {record.blockerAction}
                </button>
              )}
            </div>
          )}

          {/* Section 1: Resource Information */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5 mb-3">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>General Resource Information</span>
            </h4>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Associate ID</span>
                <span className="font-semibold text-slate-900">{record.associateId}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Full Legal Name</span>
                <span className="font-semibold text-slate-900">{record.associateName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Contact Phone</span>
                <span className="font-medium text-slate-700 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" />
                  {record.phone}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Cognizant Enterprise Email</span>
                <span className="font-medium text-blue-700 flex items-center gap-1 truncate">
                  <Mail className="w-3 h-3 text-slate-400" />
                  {record.cognizantEmail}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Client Portal Email</span>
                <span className="font-medium text-slate-700 truncate">{record.clientEmail}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Physical Deployment Location</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {record.location}
                </span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[0.65rem]">Residential Shipping Address</span>
                <span className="text-slate-700 font-medium">{record.address}</span>
              </div>
            </div>
          </div>

          {/* Section 2: Assignment & Project Governance */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5 mb-3">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Assignment &amp; Project Governance</span>
            </h4>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Account / Company</span>
                <span className="font-semibold text-slate-900">{record.account}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Program Stream</span>
                <span className="font-semibold text-slate-800">{record.program}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Project Code &amp; Name</span>
                <span className="font-semibold text-slate-900">{record.projectId} - {record.projectName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">PMO / Reporting Manager</span>
                <span className="font-semibold text-slate-800">{record.manager}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Effective Intake Date</span>
                <span className="font-bold text-blue-700">{record.effectiveDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Deployment City / State</span>
                <span className="font-medium text-slate-700">{record.city}, {record.state}</span>
              </div>
            </div>
          </div>

          {/* Section 3: Procurement & Commercials (Ariba) */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5 mb-3">
              <CreditCard className="w-3.5 h-3.5 text-blue-600" />
              <span>Procurement &amp; Commercials (Ariba)</span>
            </h4>
            <div className="grid grid-cols-3 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Ariba Request ID</span>
                <span className="font-bold text-slate-900 font-mono">{record.aribaRequestId}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Monthly Bill Rate</span>
                <span className="font-bold text-emerald-700">${record.amount.toLocaleString()} / mo</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Current Invoice Reference</span>
                <span className="font-medium text-slate-700 font-mono">{record.invoiceNumber}</span>
              </div>
            </div>
          </div>

          {/* Section 4: Asset Logistics & Provisioning */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Laptop className="w-3.5 h-3.5 text-blue-600" />
                <span>Asset Logistics &amp; Provisioning</span>
              </h4>
              <span className={`px-2 py-0.5 rounded-full text-[0.65rem] font-bold border ${
                record.deliveryStatus === 'Delivered' ? 'bg-emerald-100 text-emerald-800 border-emerald-200' :
                record.deliveryStatus === 'Dispatched' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                'bg-slate-100 text-slate-700 border-slate-200'
              }`}>
                {record.deliveryStatus}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Issued Hardware Model</span>
                <span className="font-semibold text-slate-900">{record.assetModel}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Serial Number</span>
                <span className="font-medium text-slate-700 font-mono">{record.assetSerialNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Dispatch Carrier &amp; Method</span>
                <span className="font-medium text-slate-700 flex items-center gap-1">
                  <Truck className="w-3 h-3 text-slate-400" />
                  {record.dispatchMethod}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Tracking Reference</span>
                <button
                  onClick={() => checkCarrier(record.trackingNumber)}
                  className="font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 font-mono cursor-pointer"
                >
                  <span>{record.trackingNumber}</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Target / Recorded Delivery</span>
                <span className="font-medium text-slate-800">{record.deliveryDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Associate Receipt Confirmation</span>
                <span className="font-medium text-slate-700">{record.receiptSignature}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-4 bg-slate-100/90 border-t border-slate-200 flex items-center justify-between gap-3 sticky bottom-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-600">Update Status:</span>
            <select
              value={currentStatus}
              onChange={e => handleStatusChange(e.target.value as OnboardingStatus)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer"
            >
              <option value="Draft">Draft</option>
              <option value="Submitted">Submitted</option>
              <option value="In Progress">In Progress</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
              <option value="Delayed">Delayed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            {record.currentLifecycleStep < 5 && (
              <button
                onClick={advanceStep}
                className="px-3.5 py-2 text-xs font-bold uppercase tracking-wider bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <span>Advance Step</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => setSelectedOnboardingId(null)}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { 
  UserPlus, 
  Search, 
  Filter, 
  RotateCcw, 
  ChevronRight, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Truck, 
  ShieldAlert, 
  Building2,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OnboardingStatus } from '../../types';
import { OnboardingDetailDrawer } from './OnboardingDetailDrawer';
import { NewOnboardingModal } from './NewOnboardingModal';

export const OnboardingScreen: React.FC = () => {
  const {
    onboardingRecords,
    onboardingKpis,
    selectedAccount,
    accounts,
    locations,
    getProgramsForAccount,
    selectedOnboardingId,
    setSelectedOnboardingId,
    setIsOnboardingModalOpen,
    canCreateOnboarding
  } = useApp();

  const availablePrograms = getProgramsForAccount(selectedAccount);

  const [activeTab, setActiveTab] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterProgram, setFilterProgram] = useState('All');
  const [filterLocation, setFilterLocation] = useState('All');
  const [filterDeliveryStatus, setFilterDeliveryStatus] = useState('All');

  // Filter records
  const filteredRecords = onboardingRecords.filter(record => {
    // Account filter
    if (selectedAccount !== 'all') {
      const acc = accounts.find(a => a.id === selectedAccount);
      if (acc && record.account.toLowerCase() !== acc.name.toLowerCase()) return false;
    }

    // Tab status filter
    if (activeTab !== 'All' && record.status !== activeTab) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = 
        record.associateName.toLowerCase().includes(q) ||
        record.associateId.toLowerCase().includes(q) ||
        record.aribaRequestId.toLowerCase().includes(q) ||
        record.projectName.toLowerCase().includes(q) ||
        record.program.toLowerCase().includes(q);
      if (!match) return false;
    }

    // Dropdown filters
    if (filterProgram !== 'All' && record.program !== filterProgram) return false;
    if (filterLocation !== 'All' && !record.location.includes(filterLocation)) return false;
    if (filterDeliveryStatus !== 'All' && record.deliveryStatus !== filterDeliveryStatus) return false;

    return true;
  });

  const resetAllFilters = () => {
    setActiveTab('All');
    setSearchQuery('');
    setFilterProgram('All');
    setFilterLocation('All');
    setFilterDeliveryStatus('All');
  };

  const tabs: { label: string; count: number }[] = [
    { label: 'All', count: onboardingRecords.length },
    { label: 'Draft', count: onboardingKpis.draft },
    { label: 'Submitted', count: onboardingKpis.submitted },
    { label: 'In Progress', count: onboardingKpis.inProgress },
    { label: 'Pending', count: onboardingKpis.pending },
    { label: 'Completed', count: onboardingKpis.completed },
    { label: 'Delayed', count: onboardingKpis.delayed },
    { label: 'Cancelled', count: onboardingKpis.cancelled }
  ];

  const getStatusBadge = (status: OnboardingStatus) => {
    switch (status) {
      case 'Delayed':
        return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'Completed':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Pending':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Submitted':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
              Onboarding Management
            </h2>
            <span className="px-2 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded-full border border-blue-200">
              Active Records: {onboardingKpis.totalActive} Onboarding
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage associate intake progression, hardware dispatch, client accounts, and PMO gating
          </p>
        </div>

        {canCreateOnboarding && (
          <button
            id="btn-new-onboarding-record"
            onClick={() => setIsOnboardingModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-xs cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ New Onboarding Record</span>
          </button>
        )}
      </div>

      {/* 6 KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* In Progress */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            In Progress
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-blue-700">{onboardingKpis.inProgress}</span>
            <span className="text-[0.65rem] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
              Active Flow
            </span>
          </div>
        </div>

        {/* Awaiting Access */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Awaiting Access
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-amber-700">{onboardingKpis.awaitingAccess}</span>
            <span className="text-[0.65rem] font-semibold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
              InfoSec Gate
            </span>
          </div>
        </div>

        {/* Hardware Transit */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Hardware Transit
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-indigo-700">{onboardingKpis.hardwareTransit}</span>
            <span className="text-[0.65rem] font-semibold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
              FedEx / UPS
            </span>
          </div>
        </div>

        {/* Delayed Gating */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Delayed Gating
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-rose-700">{onboardingKpis.delayed}</span>
            <span className="text-[0.65rem] font-semibold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
              Needs Action
            </span>
          </div>
        </div>

        {/* Submitted (New) */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Submitted (New)
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-purple-700">{onboardingKpis.submitted}</span>
            <span className="text-[0.65rem] font-semibold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">
              PMO Intake
            </span>
          </div>
        </div>

        {/* SLA Compliance */}
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            SLA Compliance
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-700">{onboardingKpis.slaComplianceRate}%</span>
            <span className="text-[0.65rem] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              Target &gt;95%
            </span>
          </div>
        </div>
      </div>

      {/* Status Pill Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-b border-slate-200">
        {tabs.map(tab => (
          <button
            key={tab.label}
            onClick={() => setActiveTab(tab.label)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === tab.label
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`px-1.5 py-0.2 text-[0.65rem] rounded-full font-bold ${
              activeTab === tab.label ? 'bg-blue-800 text-white' : 'bg-slate-200 text-slate-600'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Scoping Search & Quick Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Associate ID, Name, Ariba ID, Project..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-slate-800 focus:bg-white focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Program filter */}
          <div>
            <select
              value={filterProgram}
              onChange={e => setFilterProgram(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Programs</option>
              {availablePrograms.map(prog => (
                <option key={prog.id} value={prog.name}>{prog.name}</option>
              ))}
            </select>
          </div>

          {/* Location filter */}
          <div>
            <select
              value={filterLocation}
              onChange={e => setFilterLocation(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Locations</option>
              {locations.map(loc => (
                <option key={loc.id} value={loc.name}>{loc.name}</option>
              ))}
            </select>
          </div>

          {/* Delivery Status */}
          <div className="flex items-center gap-2">
            <select
              value={filterDeliveryStatus}
              onChange={e => setFilterDeliveryStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Delivery Statuses</option>
              <option value="Pending Build">Pending Build</option>
              <option value="Dispatched">Dispatched</option>
              <option value="Delivered">Delivered</option>
              <option value="Delayed">Delayed</option>
            </select>

            <button
              onClick={resetAllFilters}
              title="Reset Filters"
              className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[0.68rem] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4"># &amp; ID</th>
                <th className="py-3 px-4">Associate &amp; Role</th>
                <th className="py-3 px-4">Program &amp; Project</th>
                <th className="py-3 px-4">Location &amp; Contact</th>
                <th className="py-3 px-4">Effective Date</th>
                <th className="py-3 px-4">Ariba Commercials</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[0.75rem]">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No onboarding records match the current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record, index) => (
                  <tr
                    key={record.id}
                    onClick={() => setSelectedOnboardingId(record.id)}
                    className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">
                      <span className="text-slate-400 font-normal mr-1.5">{index + 1}.</span>
                      {record.associateId}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{record.associateName}</div>
                      <div className="text-[0.7rem] text-slate-500">{record.role}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{record.projectName}</div>
                      <div className="text-[0.7rem] text-slate-500">{record.program}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      <div>{record.location}</div>
                      <div className="text-[0.7rem] text-slate-400 font-mono">{record.phone}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap font-medium text-slate-800">
                      {record.effectiveDate}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-emerald-700 font-mono">
                        ${record.amount.toLocaleString()} / mo
                      </div>
                      <div className="text-[0.7rem] text-slate-500 font-mono">
                        {record.aribaRequestId}
                      </div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[0.68rem] font-bold border uppercase ${getStatusBadge(record.status)}`}>
                        {record.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedOnboardingId(record.id);
                        }}
                        className="px-2.5 py-1 text-[0.7rem] font-bold uppercase tracking-wider text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <span>Details</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table footer */}
        <div className="p-3 bg-slate-50/60 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Showing {filteredRecords.length} of {onboardingRecords.length} records</span>
          <span className="text-[0.7rem] text-slate-400">Click any row to open full lifecycle dossier &amp; edit controls</span>
        </div>
      </div>

      {/* Side Detail Drawer */}
      <OnboardingDetailDrawer />

      {/* New Onboarding Modal Form */}
      <NewOnboardingModal />
    </div>
  );
};

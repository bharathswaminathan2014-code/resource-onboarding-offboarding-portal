import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  RotateCcw, 
  Phone, 
  Mail, 
  MapPin, 
  Building2, 
  ShieldCheck, 
  Laptop, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ExternalLink,
  ChevronRight,
  UserMinus,
  UserPlus
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Resource, LifecycleStatus } from '../../types';

export const ResourcesScreen: React.FC = () => {
  const {
    resources,
    resourceKpis,
    selectedResourceId,
    setSelectedResourceId,
    selectedAccount,
    accounts,
    locations,
    getProgramsForAccount,
    setActiveScreen,
    setSelectedOnboardingId,
    setSelectedOffboardingId,
    setIsOffboardingModalOpen,
    showToast
  } = useApp();

  const availablePrograms = getProgramsForAccount(selectedAccount);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [programFilter, setProgramFilter] = useState<string>('All');
  const [locationFilter, setLocationFilter] = useState<string>('All');

  // Filtered resources
  const filteredResources = resources.filter(res => {
    // Account
    if (selectedAccount !== 'all') {
      const acc = accounts.find(a => a.id === selectedAccount);
      if (acc && res.accountName.toLowerCase() !== acc.name.toLowerCase()) return false;
    }

    // Status
    if (statusFilter !== 'All' && res.lifecycleStatus !== statusFilter) return false;

    // Program
    if (programFilter !== 'All' && res.programName !== programFilter) return false;

    // Location
    if (locationFilter !== 'All' && !res.location.includes(locationFilter)) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        res.name.toLowerCase().includes(q) ||
        res.id.toLowerCase().includes(q) ||
        res.title.toLowerCase().includes(q) ||
        res.projectName.toLowerCase().includes(q) ||
        res.cognizantEmail.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });

  const selectedResource = resources.find(r => r.id === selectedResourceId) || filteredResources[0] || resources[0];

  const getStatusBadge = (status: LifecycleStatus) => {
    switch (status) {
      case 'Active':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Onboarding':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Offboarding':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const handleQuickAction = (res: Resource) => {
    if (res.lifecycleStatus === 'Active') {
      setIsOffboardingModalOpen(true);
    } else if (res.lifecycleStatus === 'Onboarding') {
      setActiveScreen('onboarding');
      setSelectedOnboardingId(`ONB-${res.id.split('-')[0]}`);
    } else if (res.lifecycleStatus === 'Offboarding') {
      setActiveScreen('offboarding');
      setSelectedOffboardingId(`OFF-${res.id.split('-')[0]}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* 4 Top KPI Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Assigned */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Total Assigned
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">{resourceKpis.totalAssigned}</span>
            <span className="text-[0.65rem] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
              Active Enterprise Records
            </span>
          </div>
        </div>

        {/* Active Working */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Active Working
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-700">{resourceKpis.activeWorking}</span>
            <span className="text-[0.65rem] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              {resourceKpis.activePercentage}% of Portfolio
            </span>
          </div>
        </div>

        {/* Currently Onboarding */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Currently Onboarding
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-blue-700">{resourceKpis.currentlyOnboarding}</span>
            <span className="text-[0.65rem] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
              In Intake Pipeline
            </span>
          </div>
        </div>

        {/* Currently Offboarding */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Currently Offboarding
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-purple-700">{resourceKpis.currentlyOffboarding}</span>
            <span className="text-[0.65rem] font-semibold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
              In Roll-off Phase
            </span>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Associate ID, Name, Project code, Email..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-slate-800 focus:bg-white focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Program filter */}
          <div>
            <select
              value={programFilter}
              onChange={e => setProgramFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Programs</option>
              {availablePrograms.map(p => (
                <option key={p.id} value={p.name}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Status filter */}
          <div>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="Active">Active Working</option>
              <option value="Onboarding">Onboarding</option>
              <option value="Offboarding">Offboarding</option>
            </select>
          </div>

          {/* Location filter */}
          <div>
            <select
              value={locationFilter}
              onChange={e => setLocationFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Locations</option>
              {locations.map(loc => (
                <option key={loc.id} value={loc.name}>{loc.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Active view chips */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 text-[0.68rem] text-slate-500 flex-wrap">
          <span className="font-semibold uppercase tracking-wider text-slate-400">Active Filters:</span>
          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
            ACCOUNT: {selectedAccount === 'all' ? 'GLOBAL PORTFOLIO' : accounts.find(a => a.id === selectedAccount)?.name}
          </span>
          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
            PROGRAM: {programFilter}
          </span>
          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
            STATUS: {statusFilter}
          </span>
          {(searchQuery || statusFilter !== 'All' || programFilter !== 'All' || locationFilter !== 'All') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('All');
                setProgramFilter('All');
                setLocationFilter('All');
              }}
              className="text-blue-600 hover:text-blue-800 font-semibold ml-auto cursor-pointer"
            >
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Two-Column Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Resource Table (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-3.5 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Enterprise Resource Directory ({filteredResources.length})
            </h3>
            <span className="text-[0.7rem] text-slate-500">Click to load dossier</span>
          </div>

          <div className="overflow-x-auto max-h-[680px] overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/80 text-slate-600 font-semibold uppercase text-[0.65rem] tracking-wider sticky top-0 z-10 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Associate ID</th>
                  <th className="py-2.5 px-3">Name &amp; Title</th>
                  <th className="py-2.5 px-3">Email Accounts</th>
                  <th className="py-2.5 px-3">Project Allocation</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[0.72rem]">
                {filteredResources.map(res => {
                  const isSelected = selectedResource?.id === res.id;
                  return (
                    <tr
                      key={res.id}
                      onClick={() => setSelectedResourceId(res.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected 
                          ? 'bg-blue-50/80 font-medium' 
                          : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3 px-3 font-mono font-bold text-slate-800 whitespace-nowrap">
                        {res.id.split('-')[0]}
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{res.name}</div>
                        <div className="text-[0.68rem] text-slate-500">{res.title}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-600">
                        <div className="text-blue-700 font-medium truncate max-w-[150px]">{res.cognizantEmail}</div>
                        <div className="text-slate-400 text-[0.65rem] truncate max-w-[150px]">{res.clientEmail}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700">
                        <div className="font-medium truncate max-w-[140px]">{res.projectName}</div>
                        <div className="text-[0.65rem] text-slate-400 truncate max-w-[140px]">{res.location}</div>
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded-full text-[0.65rem] font-bold border uppercase ${getStatusBadge(res.lifecycleStatus)}`}>
                          {res.lifecycleStatus}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Operational Dossier (5 Cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs sticky top-24">
          {selectedResource ? (
            <div>
              {/* Dossier Header */}
              <div className="p-4 bg-slate-900 text-white flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[0.65rem] font-mono font-bold text-blue-300 uppercase tracking-wider bg-blue-950 px-1.5 py-0.5 rounded border border-blue-800">
                      ID: {selectedResource.id}
                    </span>
                    <span className={`px-2 py-0.2 rounded-full text-[0.62rem] font-extrabold uppercase border ${
                      selectedResource.lifecycleStatus === 'Active' 
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-800' 
                        : 'bg-purple-950 text-purple-300 border-purple-800'
                    }`}>
                      {selectedResource.lifecycleStatus}
                    </span>
                  </div>
                  <h3 className="text-base font-black text-white mt-1.5">{selectedResource.name}</h3>
                  <p className="text-xs text-slate-300">{selectedResource.title}</p>
                </div>

                <div className="w-9 h-9 rounded-full bg-blue-700/60 text-white font-bold text-xs flex items-center justify-center border border-blue-400/40">
                  {selectedResource.name.split(' ').map(n => n[0]).join('')}
                </div>
              </div>

              {/* Dossier Body */}
              <div className="p-4 space-y-4 text-xs">
                {/* Contact & Location */}
                <div className="bg-slate-50 rounded-lg p-3 border border-slate-100 space-y-1.5 text-[0.72rem]">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{selectedResource.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-blue-700 font-medium truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span>{selectedResource.cognizantEmail}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{selectedResource.location}</span>
                  </div>
                </div>

                {/* Account Hierarchy */}
                <div className="border border-slate-200/80 rounded-lg p-3 space-y-2">
                  <div className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-blue-600" />
                    <span>Current Account Hierarchy</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[0.7rem]">
                    <div>
                      <span className="text-slate-400 block text-[0.62rem]">Master Account</span>
                      <span className="font-bold text-slate-900">{selectedResource.accountName}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[0.62rem]">Program Stream</span>
                      <span className="font-semibold text-slate-800">{selectedResource.programName}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-400 block text-[0.62rem]">Project Allocation</span>
                      <span className="font-semibold text-slate-800">{selectedResource.projectName}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-400 block text-[0.62rem]">Assigned PMO / Manager</span>
                      <span className="font-medium text-slate-700">{selectedResource.manager}</span>
                    </div>
                  </div>
                </div>

                {/* Lifecycle Milestone Log */}
                <div className="border border-slate-200/80 rounded-lg p-3">
                  <div className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1 mb-2">
                    <Clock className="w-3 h-3 text-blue-600" />
                    <span>Lifecycle Milestone Log</span>
                  </div>
                  <div className="space-y-2.5 relative pl-4 border-l-2 border-slate-200 text-[0.7rem]">
                    {selectedResource.milestones.map(m => (
                      <div key={m.id} className="relative">
                        <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full border-2 border-white ${
                          m.status === 'completed' ? 'bg-emerald-600' :
                          m.status === 'delayed' ? 'bg-rose-600' : 'bg-blue-600'
                        }`} />
                        <div className="font-bold text-slate-800">{m.title}</div>
                        <div className="text-[0.65rem] text-slate-400">{m.date}</div>
                        <div className="text-[0.68rem] text-slate-600 leading-snug mt-0.5">{m.details}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Assigned Assets & Compliance */}
                <div className="border border-slate-200/80 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1">
                      <Laptop className="w-3 h-3 text-blue-600" />
                      <span>Assigned Hardware &amp; Compliance</span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[0.62rem] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <ShieldCheck className="w-2.5 h-2.5" />
                      <span>SOC-2 Verified</span>
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[0.7rem]">
                    <div>
                      <span className="text-slate-400 block text-[0.62rem]">Asset Model</span>
                      <span className="font-semibold text-slate-900">{selectedResource.assetModel}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[0.62rem]">Asset Tag &amp; Serial</span>
                      <span className="font-mono font-bold text-slate-800">{selectedResource.assetTag}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-slate-400 block text-[0.62rem]">Handover Log</span>
                      <span className="text-slate-600">{selectedResource.assetHandoverDate}</span>
                    </div>
                  </div>
                </div>

                {/* Quick Action Button */}
                <div className="pt-2">
                  <button
                    onClick={() => handleQuickAction(selectedResource)}
                    className={`w-full py-2.5 px-4 rounded-lg text-xs font-bold uppercase tracking-wider text-white transition-colors shadow-xs flex items-center justify-center gap-2 cursor-pointer ${
                      selectedResource.lifecycleStatus === 'Active' 
                        ? 'bg-purple-600 hover:bg-purple-700' 
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {selectedResource.lifecycleStatus === 'Active' && (
                      <>
                        <UserMinus className="w-4 h-4" />
                        <span>Initiate Roll-off / Offboarding</span>
                      </>
                    )}
                    {selectedResource.lifecycleStatus === 'Onboarding' && (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>View Active Onboarding Record</span>
                      </>
                    )}
                    {selectedResource.lifecycleStatus === 'Offboarding' && (
                      <>
                        <Laptop className="w-4 h-4" />
                        <span>View Offboarding Return Record</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-400 text-xs">
              Select a resource from the directory to inspect their operational dossier.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

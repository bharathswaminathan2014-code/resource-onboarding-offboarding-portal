import React, { useState, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Search, 
  Filter, 
  RotateCcw, 
  ArrowUpDown, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar,
  Building2,
  Table as TableIcon
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

type ReportType = 'onboarding' | 'offboarding' | 'lifecycle';

export const ReportsScreen: React.FC = () => {
  const {
    onboardingRecords,
    offboardingRecords,
    resources,
    accounts,
    getProgramsForAccount,
    selectedAccount,
    showToast
  } = useApp();

  const [activeReport, setActiveReport] = useState<ReportType>('onboarding');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAccount, setFilterAccount] = useState('All');
  const [filterProgram, setFilterProgram] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [sortField, setSortField] = useState<string>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const targetAccountId = filterAccount !== 'All' 
    ? (accounts.find(a => a.name === filterAccount)?.id || 'all')
    : 'all';
  const availablePrograms = getProgramsForAccount(targetAccountId);

  // Derive reports data
  const reportData = useMemo(() => {
    if (activeReport === 'onboarding') {
      return onboardingRecords.map(r => ({
        id: r.id,
        associateId: r.associateId,
        name: r.associateName,
        role: r.role,
        account: r.account,
        program: r.program,
        project: r.projectName,
        manager: r.manager,
        location: r.location,
        date: r.effectiveDate,
        commercials: `$${r.amount.toLocaleString()}`,
        status: r.status,
        hardwareStatus: r.deliveryStatus,
        aribaId: r.aribaRequestId
      }));
    } else if (activeReport === 'offboarding') {
      return offboardingRecords.map(r => ({
        id: r.id,
        associateId: r.associateId,
        name: r.associateName,
        role: r.role,
        account: r.account,
        program: r.program,
        project: r.projectName,
        manager: r.manager,
        location: r.location,
        date: r.lastWorkingDate,
        commercials: r.carrier,
        status: r.status,
        hardwareStatus: r.assetStatus,
        aribaId: r.trackingNumber
      }));
    } else {
      return resources.map(r => ({
        id: r.id,
        associateId: r.id,
        name: r.name,
        role: r.title,
        account: r.accountName,
        program: r.programName,
        project: r.projectName,
        manager: r.manager,
        location: r.location,
        date: r.effectiveDate,
        commercials: r.soc2Compliant ? 'SOC-2 Cleared' : 'Pending',
        status: r.lifecycleStatus,
        hardwareStatus: r.assetModel,
        aribaId: r.assetTag
      }));
    }
  }, [activeReport, onboardingRecords, offboardingRecords, resources]);

  // Filter and sort
  const filteredData = useMemo(() => {
    let result = [...reportData];

    if (filterAccount !== 'All') {
      result = result.filter(item => item.account === filterAccount);
    }
    if (filterProgram !== 'All') {
      result = result.filter(item => item.program === filterProgram);
    }
    if (filterStatus !== 'All') {
      result = result.filter(item => item.status === filterStatus);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(item => 
        item.name.toLowerCase().includes(q) ||
        item.associateId.toLowerCase().includes(q) ||
        item.project.toLowerCase().includes(q)
      );
    }

    result.sort((a: any, b: any) => {
      const valA = a[sortField] || '';
      const valB = b[sortField] || '';
      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [reportData, filterAccount, filterProgram, filterStatus, searchQuery, sortField, sortDirection]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Export handlers
  const exportToCSV = () => {
    if (filteredData.length === 0) {
      showToast('Export Error', 'No data available to export.', 'warning');
      return;
    }

    const headers = ['Associate ID', 'Associate Name', 'Role', 'Account', 'Program', 'Project', 'Manager', 'Location', 'Date', 'Status', 'Asset Detail'];
    const rows = filteredData.map(item => [
      `"${item.associateId}"`,
      `"${item.name}"`,
      `"${item.role}"`,
      `"${item.account}"`,
      `"${item.program}"`,
      `"${item.project}"`,
      `"${item.manager}"`,
      `"${item.location}"`,
      `"${item.date}"`,
      `"${item.status}"`,
      `"${item.hardwareStatus}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Cognizant_PMO_${activeReport}_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('Export Complete', `Generated ${activeReport} report in CSV format.`);
  };

  const exportToExcel = () => {
    if (filteredData.length === 0) {
      showToast('Export Error', 'No data available to export.', 'warning');
      return;
    }

    const headers = ['Associate ID', 'Associate Name', 'Role', 'Account', 'Program', 'Project', 'Manager', 'Location', 'Effective/LWD Date', 'Status', 'Asset / Commercial Ref'];
    const rows = filteredData.map(item => [
      item.associateId,
      item.name,
      item.role,
      item.account,
      item.program,
      item.project,
      item.manager,
      item.location,
      item.date,
      item.status,
      item.hardwareStatus
    ]);

    let html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${activeReport.toUpperCase()}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>
      <body>
        <h2>COGNIZANT PMO PORTAL — ${activeReport.toUpperCase()} REPORT</h2>
        <p>Generated: ${new Date().toLocaleString()}</p>
        <table border="1">
          <thead><tr>${headers.map(h => `<th style="background:#003882;color:white;">${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Cognizant_PMO_${activeReport}_Report_${new Date().toISOString().split('T')[0]}.xls`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('Excel Export Ready', `Downloaded spreadsheet report for ${activeReport}.`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
              PMO Governance &amp; Lifecycle Reports
            </h2>
            <span className="px-2 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded-full border border-blue-200">
              Audit-Ready Export
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit logs, turnover telemetry, turnaround SLAs, and billing reconciliation exports
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportToCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={exportToExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* Report Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveReport('onboarding')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeReport === 'onboarding'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TableIcon className="w-4 h-4" />
          <span>1. Onboarding Pipeline Report</span>
        </button>

        <button
          onClick={() => setActiveReport('offboarding')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeReport === 'offboarding'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TableIcon className="w-4 h-4" />
          <span>2. Offboarding &amp; Asset Return Report</span>
        </button>

        <button
          onClick={() => setActiveReport('lifecycle')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeReport === 'lifecycle'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TableIcon className="w-4 h-4" />
          <span>3. Comprehensive Resource Lifecycle Report</span>
        </button>
      </div>

      {/* Summary KPI Cards for Active Report */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Total Records Filtered
          </span>
          <span className="text-2xl font-black text-slate-900">{filteredData.length}</span>
          <span className="text-[0.68rem] text-slate-400 block mt-0.5">Under current query</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Average Cycle Time
          </span>
          <span className="text-2xl font-black text-blue-700">6.4 Days</span>
          <span className="text-[0.68rem] text-emerald-600 block mt-0.5 font-medium">Within 7d SLA Target</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            SLA Governance Met
          </span>
          <span className="text-2xl font-black text-emerald-700">96.4%</span>
          <span className="text-[0.68rem] text-slate-400 block mt-0.5">PMO Gating Compliance</span>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Exception / Delayed Rate
          </span>
          <span className="text-2xl font-black text-rose-700">3.6%</span>
          <span className="text-[0.68rem] text-slate-400 block mt-0.5">Requires Intervention</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Associate Name, ID, Project..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-slate-800 focus:bg-white focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Account */}
          <div>
            <select
              value={filterAccount}
              onChange={e => {
                setFilterAccount(e.target.value);
                setFilterProgram('All');
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Accounts</option>
              {accounts.map(a => (
                <option key={a.id} value={a.name}>{a.name}</option>
              ))}
            </select>
          </div>

          {/* Program */}
          <div>
            <select
              value={filterProgram}
              onChange={e => setFilterProgram(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Programs</option>
              {availablePrograms.map(p => (
                <option key={p.id} value={p.name}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Status & Reset */}
          <div className="flex items-center gap-2">
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Statuses</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
              <option value="Delayed">Delayed</option>
              <option value="Pending">Pending</option>
              <option value="Active">Active</option>
            </select>

            <button
              onClick={() => {
                setSearchQuery('');
                setFilterAccount('All');
                setFilterProgram('All');
                setFilterStatus('All');
              }}
              title="Reset Filters"
              className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Reports Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[0.68rem] tracking-wider border-b border-slate-200">
              <tr>
                <th onClick={() => handleSort('associateId')} className="py-3 px-4 cursor-pointer hover:bg-slate-100">
                  <div className="flex items-center gap-1">
                    <span>Associate ID</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th onClick={() => handleSort('name')} className="py-3 px-4 cursor-pointer hover:bg-slate-100">
                  <div className="flex items-center gap-1">
                    <span>Resource &amp; Title</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">Program &amp; Project</th>
                <th className="py-3 px-4">Account &amp; Location</th>
                <th onClick={() => handleSort('date')} className="py-3 px-4 cursor-pointer hover:bg-slate-100">
                  <div className="flex items-center gap-1">
                    <span>{activeReport === 'offboarding' ? 'LWD' : 'Effective Date'}</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-4">{activeReport === 'onboarding' ? 'Commercials' : activeReport === 'offboarding' ? 'Carrier / Tracking' : 'Compliance'}</th>
                <th className="py-3 px-4">{activeReport === 'onboarding' ? 'Delivery' : activeReport === 'offboarding' ? 'Return Status' : 'Hardware Model'}</th>
                <th onClick={() => handleSort('status')} className="py-3 px-4 cursor-pointer hover:bg-slate-100">
                  <div className="flex items-center gap-1">
                    <span>Status</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[0.75rem]">
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No data matching query.
                  </td>
                </tr>
              ) : (
                filteredData.map((row, idx) => (
                  <tr key={`${row.id}-${idx}`} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-700 whitespace-nowrap">
                      {row.associateId}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{row.name}</div>
                      <div className="text-[0.68rem] text-slate-500">{row.role}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{row.project}</div>
                      <div className="text-[0.68rem] text-slate-500">{row.program}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      <div>{row.account}</div>
                      <div className="text-[0.68rem] text-slate-400">{row.location}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap font-medium text-slate-800">
                      {row.date}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono font-medium text-slate-700">{row.commercials}</div>
                      <div className="text-[0.68rem] text-slate-400 font-mono">{row.aribaId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[0.7rem] text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {row.hardwareStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[0.68rem] font-bold border uppercase ${
                        row.status === 'Delayed' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                        row.status === 'Completed' || row.status === 'Active' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                        row.status === 'In Progress' || row.status === 'Onboarding' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                        'bg-amber-100 text-amber-700 border-amber-200'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Displaying {filteredData.length} audit records</span>
          <span className="text-[0.7rem] text-slate-400">Data synchronized from live PMO operational stores</span>
        </div>
      </div>
    </div>
  );
};

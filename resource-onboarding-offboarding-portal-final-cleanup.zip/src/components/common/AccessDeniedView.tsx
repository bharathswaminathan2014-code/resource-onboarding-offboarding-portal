import React from 'react';
import { ShieldAlert, ArrowLeft, Lock } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ScreenType } from '../../types';

interface AccessDeniedViewProps {
  screenName?: string;
  requiredRole?: string;
}

export const AccessDeniedView: React.FC<AccessDeniedViewProps> = ({ 
  screenName, 
  requiredRole 
}) => {
  const { currentUser, setActiveScreen } = useApp();

  return (
    <div className="min-h-[500px] flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-white rounded-2xl border border-slate-200 shadow-xl p-8 text-center">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4 border border-rose-100">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold uppercase tracking-wider mb-2 border border-rose-200">
          <Lock className="w-3.5 h-3.5" />
          <span>Access Restricted</span>
        </div>

        <h2 className="text-xl font-black text-slate-900 mb-2">
          Unauthorized Module Access
        </h2>

        <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
          Your active persona (<strong className="text-slate-900">{currentUser?.name}</strong>) with role <strong className="text-blue-700">{currentUser?.role}</strong> does not have authorization to access the <span className="font-semibold text-slate-900">{screenName || 'requested'}</span> screen.
          {requiredRole && ` This screen requires '${requiredRole}' privileges.`}
        </p>

        <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 mb-6 text-left text-xs space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-500">Active User:</span>
            <span className="font-semibold text-slate-800">{currentUser?.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Role:</span>
            <span className="font-semibold text-blue-700">{currentUser?.role}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Account Scope:</span>
            <span className="font-semibold text-slate-800">{currentUser?.accountScope}</span>
          </div>
        </div>

        <button
          onClick={() => setActiveScreen('dashboard')}
          className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Permitted Dashboard</span>
        </button>
      </div>
    </div>
  );
};

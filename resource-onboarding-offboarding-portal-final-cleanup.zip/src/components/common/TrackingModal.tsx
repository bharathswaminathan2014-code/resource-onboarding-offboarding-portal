import React from 'react';
import { X, Truck, CheckCircle2, Clock, MapPin, ExternalLink } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const TrackingModal: React.FC = () => {
  const { trackingModalData, closeTrackingModal } = useApp();

  if (!trackingModalData?.isOpen) return null;

  const carrier = trackingModalData.carrier || 'FedEx';
  const trackingNumber = trackingModalData.trackingNumber || 'FDX992014';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-700">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  {carrier} Live Shipment Telemetry
                </h3>
                <span className="px-2 py-0.2 text-[0.62rem] font-extrabold uppercase bg-emerald-100 text-emerald-800 rounded-full border border-emerald-200">
                  Active Transit
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono">
                Tracking #: {trackingNumber}
              </p>
            </div>
          </div>
          <button
            onClick={closeTrackingModal}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5 text-xs">
          {/* Status highlight */}
          <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-[0.68rem] font-bold uppercase tracking-wider text-blue-700 block">
                Current Status
              </span>
              <span className="text-sm font-black text-slate-900 mt-0.5 block">
                In Transit — On Schedule for Hub Delivery
              </span>
              <span className="text-[0.7rem] text-slate-600">
                Estimated Delivery: Tomorrow by 10:30 AM
              </span>
            </div>
            <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
          </div>

          {/* Timeline Checkpoints */}
          <div>
            <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-3">
              Shipment Activity &amp; Checkpoints
            </span>
            <div className="space-y-4 relative pl-5 border-l-2 border-slate-200 text-[0.72rem]">
              <div className="relative">
                <div className="absolute -left-[25px] top-0.5 w-3 h-3 rounded-full bg-blue-600 border-2 border-white ring-2 ring-blue-100" />
                <div className="font-bold text-slate-900">Arrived at Regional Sort Facility</div>
                <div className="text-[0.65rem] text-slate-400">Dallas/Fort Worth Hub, TX • Today, 04:15 AM</div>
                <div className="text-slate-600 mt-0.5">Scanned into automated sorting system. Next stop: Local delivery terminal.</div>
              </div>

              <div className="relative">
                <div className="absolute -left-[25px] top-0.5 w-3 h-3 rounded-full bg-emerald-600 border-2 border-white" />
                <div className="font-bold text-slate-900">Departed Origin Facility</div>
                <div className="text-[0.65rem] text-slate-400">San Diego Carrier Center, CA • Yesterday, 19:40 PM</div>
                <div className="text-slate-600 mt-0.5">Package forwarded to air transit hub.</div>
              </div>

              <div className="relative">
                <div className="absolute -left-[25px] top-0.5 w-3 h-3 rounded-full bg-emerald-600 border-2 border-white" />
                <div className="font-bold text-slate-900">Picked Up / Return Kit Handed to Driver</div>
                <div className="text-[0.65rem] text-slate-400">Associate Residence • Yesterday, 14:15 PM</div>
                <div className="text-slate-600 mt-0.5">Electronic signature captured by driver.</div>
              </div>
            </div>
          </div>

          {/* Destination */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/80 flex items-start gap-2.5 text-[0.72rem]">
            <MapPin className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-bold text-slate-800 block">Destination Delivery Address</span>
              <span className="text-slate-600">
                Cognizant Central Technology Recovery Depot, 2100 Lakeside Blvd, Richardson, TX 75082
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[0.68rem] text-slate-400">Carrier API v3 Telemetry Stream</span>
          <button
            onClick={closeTrackingModal}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

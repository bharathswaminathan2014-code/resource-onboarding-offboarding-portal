import React from 'react';
import { 
  LayoutDashboard, 
  UserPlus, 
  UserMinus, 
  Users, 
  FileSpreadsheet, 
  Settings,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ScreenType } from '../../types';

interface NavItem {
  id: ScreenType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeKey?: 'onboarding' | 'offboarding' | 'resources';
}

export const Sidebar: React.FC = () => {
  const { 
    activeScreen, 
    setActiveScreen, 
    onboardingKpis, 
    offboardingKpis,
    resourceKpis,
    canAccessScreen,
    currentUser
  } = useApp();

  const allNavItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'onboarding', label: 'Onboarding', icon: UserPlus, badgeKey: 'onboarding' },
    { id: 'offboarding', label: 'Offboarding', icon: UserMinus, badgeKey: 'offboarding' },
    { id: 'resources', label: 'Resources', icon: Users, badgeKey: 'resources' },
    { id: 'reports', label: 'Reports', icon: FileSpreadsheet },
    { id: 'administration', label: 'Administration', icon: Settings },
  ];

  const visibleNavItems = allNavItems.filter(item => canAccessScreen(item.id));

  const getBadge = (key?: 'onboarding' | 'offboarding' | 'resources') => {
    if (key === 'onboarding') return onboardingKpis.totalActive;
    if (key === 'offboarding') return offboardingKpis.totalActive;
    if (key === 'resources') return resourceKpis.totalAssigned;
    return null;
  };

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col justify-between flex-shrink-0 min-h-[calc(100vh-84px)] border-r border-slate-800">
      {/* Navigation List */}
      <div className="py-4 px-3">
        <div className="px-3 mb-2 flex items-center justify-between">
          <span className="text-[0.65rem] font-bold uppercase tracking-wider text-slate-400">
            Authorized Modules
          </span>
          <span className="text-[0.6rem] font-semibold text-blue-400 bg-blue-950 px-1.5 py-0.5 rounded border border-blue-900/60">
            {currentUser?.role || 'PMO'}
          </span>
        </div>
        <nav className="space-y-1">
          {visibleNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            const badgeValue = getBadge(item.badgeKey);

            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => setActiveScreen(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all group cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'
                  }`} />
                  <span className="tracking-wide">{item.label}</span>
                </div>

                {badgeValue !== null && (
                  <span className={`px-2 py-0.5 text-[0.68rem] font-bold rounded-full ${
                    isActive 
                      ? 'bg-blue-800/80 text-white' 
                      : 'bg-slate-800 text-slate-400 group-hover:text-slate-200'
                  }`}>
                    {badgeValue}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom: Governance Mode & Status */}
      <div className="p-4 border-t border-slate-800/80">
        <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[0.68rem] font-bold text-slate-300 uppercase tracking-wider">
                Governance Mode
              </span>
            </div>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </div>
          
          <div className="text-[0.72rem] font-bold text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>SLA &amp; GATING ACTIVE</span>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[0.65rem] text-slate-400">
            <span>SLA Compliance</span>
            <span className="font-semibold text-slate-200">{onboardingKpis.slaComplianceRate}%</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

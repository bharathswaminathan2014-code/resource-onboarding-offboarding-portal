import React from 'react';
import cognizantLogoAsset from '../../assets/images.png';

interface CognizantLogoProps {
  className?: string;
  showSubtitle?: boolean;
}

export const CognizantLogo: React.FC<CognizantLogoProps> = ({ 
  className = '',
  showSubtitle = true 
}) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Attached Cognizant Logo Asset */}
      <img
        src={cognizantLogoAsset}
        onError={(e) => {
          if (e.currentTarget.src !== '/images.png') {
            e.currentTarget.src = '/images.png';
          }
        }}
        alt="Cognizant"
        className="h-7 w-auto object-contain flex-shrink-0"
        referrerPolicy="no-referrer"
      />

      {showSubtitle && (
        <>
          <div className="h-5 w-[1.5px] bg-slate-300 flex-shrink-0" />
          <span className="text-[0.88rem] font-bold tracking-tight text-slate-900 whitespace-nowrap">
            Resource Onboarding &amp; Offboarding Portal
          </span>
        </>
      )}
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { 
  Bell, 
  ChevronDown, 
  RefreshCw, 
  Building2, 
  Check, 
  ExternalLink,
  ShieldCheck,
  Clock,
  LogOut,
  User,
  Lock
} from 'lucide-react';
import { CognizantLogo } from './CognizantLogo';
import { useApp } from '../../context/AppContext';

export const Header: React.FC = () => {
  const {
    currentUser,
    logout,
    selectedAccount,
    setSelectedAccount,
    accounts,
    userAccessibleAccounts,
    notifications,
    unreadNotificationCount,
    markNotificationRead,
    markAllNotificationsRead,
    setActiveScreen,
    setSelectedOnboardingId,
    setSelectedOffboardingId,
    onboardingKpis,
    offboardingKpis,
    showToast
  } = useApp();

  const [isNotifMenuOpen, setIsNotifMenuOpen] = useState(false);
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const notifMenuRef = useRef<HTMLDivElement>(null);
  const accountMenuRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifMenuRef.current && !notifMenuRef.current.contains(event.target as Node)) {
        setIsNotifMenuOpen(false);
      }
      if (accountMenuRef.current && !accountMenuRef.current.contains(event.target as Node)) {
        setIsAccountMenuOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      showToast('Data Synchronized', 'PMO portal data refreshed against operational data feeds.');
    }, 600);
  };

  const handleNotificationClick = (notif: typeof notifications[0]) => {
    markNotificationRead(notif.id);
    if (notif.targetScreen) {
      setActiveScreen(notif.targetScreen);
      if (notif.targetScreen === 'onboarding' && notif.targetId) {
        setSelectedOnboardingId(notif.targetId);
      } else if (notif.targetScreen === 'offboarding' && notif.targetId) {
        setSelectedOffboardingId(notif.targetId);
      }
    }
    setIsNotifMenuOpen(false);
  };

  const isScopeLocked = Boolean(currentUser?.accountScope && currentUser.accountScope !== 'All');

  const currentAccountName = selectedAccount === 'all' 
    ? 'All Accounts (Global Portfolio)' 
    : accounts.find(a => a.id === selectedAccount)?.name || 'Enterprise Portfolio';

  const userInitials = currentUser?.name
    ? currentUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : 'U';

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Primary Top Bar */}
      <div className="flex items-center justify-between px-5 py-2.5">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-6">
          <CognizantLogo />
        </div>

        {/* Center/Right: Account, Role Badge, Notifications & User Info */}
        <div className="flex items-center gap-3.5">
          {/* Account Scope Dropdown Pill */}
          <div className="relative" ref={accountMenuRef}>
            {isScopeLocked ? (
              <div 
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-xs text-slate-700 font-medium cursor-default"
                title={`Scope restricted to ${currentUser?.accountScope} by your portal role assignment.`}
              >
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-900 uppercase tracking-tight">
                    ACCOUNT: {currentUser?.accountScope}
                  </span>
                  {currentUser?.programScope && currentUser.programScope !== 'All' && (
                    <>
                      <span className="text-slate-400">/</span>
                      <span className="text-blue-700 font-semibold">{currentUser.programScope}</span>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <>
                <button
                  id="header-account-selector-btn"
                  onClick={() => setIsAccountMenuOpen(!isAccountMenuOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100/80 transition-colors text-xs text-slate-700 font-medium"
                >
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900 uppercase tracking-tight">
                      {selectedAccount === 'all' ? 'ACCOUNT: ALL' : `ACCOUNT: ${accounts.find(a => a.id === selectedAccount)?.code || 'SELECTED'}`}
                    </span>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-600 max-w-[200px] truncate hidden md:inline">
                      {currentAccountName}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
                </button>

                {isAccountMenuOpen && (
                  <div className="absolute left-0 mt-1.5 w-64 bg-white rounded-lg shadow-lg border border-slate-200 py-1.5 z-50 text-xs">
                    <div className="px-3 py-1.5 text-[0.68rem] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                      Select Account Scope
                    </div>
                    <button
                      onClick={() => {
                        setSelectedAccount('all');
                        setIsAccountMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${
                        selectedAccount === 'all' ? 'text-blue-600 font-semibold bg-blue-50/50' : 'text-slate-700'
                      }`}
                    >
                      <span>All Accounts (Global Portfolio)</span>
                      {selectedAccount === 'all' && <Check className="w-3.5 h-3.5 text-blue-600" />}
                    </button>
                    {userAccessibleAccounts.map(acc => (
                      <button
                        key={acc.id}
                        onClick={() => {
                          setSelectedAccount(acc.id);
                          setIsAccountMenuOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${
                          selectedAccount === acc.id ? 'text-blue-600 font-semibold bg-blue-50/50' : 'text-slate-700'
                        }`}
                      >
                        <span className={acc.status === 'Inactive' ? 'text-slate-400 italic' : ''}>
                          {acc.name} ({acc.code}){acc.status === 'Inactive' ? ' (Inactive)' : ''}
                        </span>
                        {selectedAccount === acc.id && <Check className="w-3.5 h-3.5 text-blue-600" />}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>

          {/* Role & Scope Indicator Badge (Derived from authenticated user) */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-blue-200 bg-blue-50 text-xs text-blue-900 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Role: {currentUser?.role || 'PMO'}</span>
          </div>

          {/* Notification Bell */}
          <div className="relative" ref={notifMenuRef}>
            <button
              id="header-notifications-btn"
              onClick={() => setIsNotifMenuOpen(!isNotifMenuOpen)}
              aria-label="Notifications"
              className="relative p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex items-center justify-center min-w-[17px] h-[17px] px-1 text-[0.65rem] font-bold text-white bg-rose-600 rounded-full ring-2 ring-white">
                  {unreadNotificationCount}
                </span>
              )}
            </button>

            {isNotifMenuOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50">
                <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900">Portal Notifications</span>
                    <span className="px-1.5 py-0.5 text-[0.65rem] font-bold bg-rose-50 text-rose-600 rounded-full border border-rose-200">
                      {unreadNotificationCount} New
                    </span>
                  </div>
                  {unreadNotificationCount > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                    >
                      Mark all as read
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                  {notifications.map(n => (
                    <div
                      key={n.id}
                      onClick={() => handleNotificationClick(n)}
                      className={`p-3.5 hover:bg-slate-50 cursor-pointer transition-colors flex items-start gap-3 ${
                        !n.read ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                        !n.read ? 'bg-blue-600' : 'bg-transparent'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1 mb-0.5">
                          <p className="text-xs font-semibold text-slate-800 truncate">{n.title}</p>
                          <span className="text-[0.65rem] text-slate-400 flex-shrink-0 flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5" />
                            {n.timestamp}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 leading-snug line-clamp-2">{n.description}</p>
                        {n.targetScreen && (
                          <div className="mt-1 flex items-center gap-1 text-[0.68rem] text-blue-600 font-medium">
                            <span>Go to {n.targetScreen}</span>
                            <ExternalLink className="w-2.5 h-2.5" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile & Session Dropdown */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-2.5 pl-2 border-l border-slate-200 hover:opacity-90 transition-opacity cursor-pointer"
            >
              <div className="flex flex-col text-right leading-none hidden sm:flex">
                <span className="text-xs font-bold text-slate-900">{currentUser?.name || 'Portal User'}</span>
                <span className="text-[0.68rem] font-semibold text-blue-700 tracking-wider uppercase mt-0.5">
                  {currentUser?.role || 'PMO'}
                </span>
              </div>
              <div className="w-8 h-8 rounded-full bg-[#003882] text-white font-bold text-xs flex items-center justify-center ring-2 ring-blue-100">
                {userInitials}
              </div>
              <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:block" />
            </button>

            {isUserMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs">
                <div className="px-4 py-3 border-b border-slate-100">
                  <p className="font-bold text-slate-900 text-sm">{currentUser?.name}</p>
                  <p className="text-slate-500 text-xs mt-0.5">{currentUser?.email}</p>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-bold rounded text-[0.65rem] border border-blue-200">
                      {currentUser?.role}
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold rounded text-[0.65rem] border border-emerald-200">
                      Active
                    </span>
                  </div>
                </div>

                <div className="px-4 py-2.5 bg-slate-50/70 border-b border-slate-100 space-y-1 text-[0.7rem]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Account Scope:</span>
                    <span className="font-semibold text-slate-700">{currentUser?.accountScope || 'All'}</span>
                  </div>
                  {currentUser?.programScope && currentUser.programScope !== 'All' && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Program Scope:</span>
                      <span className="font-semibold text-slate-700">{currentUser.programScope}</span>
                    </div>
                  )}
                  {currentUser?.projectScope && currentUser.projectScope !== 'All' && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Project Scope:</span>
                      <span className="font-semibold text-slate-700">{currentUser.projectScope}</span>
                    </div>
                  )}
                </div>

                <div className="p-1.5">
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-lg font-bold transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Header Breadcrumb & Status Indicator Bar */}
      <div className="flex items-center justify-between px-5 py-2 bg-slate-50/90 border-t border-slate-200/80 text-xs">
        <div className="flex items-center gap-2 text-slate-600 flex-wrap">
          <span className="text-slate-400">PMO Portal</span>
          <span className="text-slate-300">/</span>
          <span className="font-semibold text-blue-700">
            {selectedAccount === 'all' ? 'Enterprise Resource Operations' : `${currentAccountName} Operations`}
          </span>
          <span className="text-slate-300">|</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-500" />
            <span className="text-slate-700 font-medium">
              Account: <strong className="font-bold text-slate-900">{selectedAccount === 'all' ? 'Global Portfolio' : currentAccountName}</strong>
            </span>
          </div>
          <span className="text-slate-300">|</span>
          <span className="text-slate-700 font-medium">
            Active Records: <strong className="text-blue-700">{onboardingKpis.totalActive} Onboarding</strong>, <strong className="text-slate-800">{offboardingKpis.totalActive} Offboarding</strong>
          </span>
        </div>

        <div className="flex items-center gap-3 text-slate-500">
          <button
            onClick={handleSync}
            disabled={isSyncing}
            className="flex items-center gap-1 text-[0.72rem] hover:text-blue-600 transition-colors cursor-pointer"
            title="Refresh portal sync"
          >
            <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin text-blue-600' : ''}`} />
            <span>Last synced: Today, 09:30 AM</span>
          </button>
        </div>
      </div>
    </header>
  );
};

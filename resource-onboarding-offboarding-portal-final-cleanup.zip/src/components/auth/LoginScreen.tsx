import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Mail, 
  AlertCircle, 
  ArrowRight, 
  Users, 
  CheckCircle2, 
  XCircle,
  Building,
  KeyRound
} from 'lucide-react';
import { CognizantLogo } from '../common/CognizantLogo';
import { useApp } from '../../context/AppContext';
import { PortalUser } from '../../types';

export const LoginScreen: React.FC = () => {
  const { users, login } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('demo123');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim()) {
      setErrorMessage('Please enter your Cognizant enterprise email or user ID.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const result = login(email.trim(), password);
      setIsSubmitting(false);
      if (!result.success) {
        setErrorMessage(result.error || 'Invalid credentials or user access restriction.');
      }
    }, 250);
  };

  const handleQuickSelect = (user: PortalUser) => {
    setEmail(user.email);
    setPassword('demo123');
    setErrorMessage(null);

    // Auto-attempt login
    setIsSubmitting(true);
    setTimeout(() => {
      const result = login(user.email, 'demo123');
      setIsSubmitting(false);
      if (!result.success) {
        setErrorMessage(result.error || 'Invalid credentials or user access restriction.');
      }
    }, 200);
  };

  return (
    <div className="min-h-screen w-screen bg-slate-900 flex flex-col justify-between p-4 sm:p-6 lg:p-8 selection:bg-blue-600 selection:text-white">
      {/* Top Brand Header */}
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between pb-6 border-b border-slate-800">
        <CognizantLogo className="brightness-125" showSubtitle={false} />
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="hidden sm:inline">Role-Based Access Control &amp; Data Scoping</span>
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[0.68rem] border border-slate-700">
            ENTERPRISE v2.4
          </span>
        </div>
      </div>

      {/* Main Authentication Grid */}
      <div className="w-full max-w-6xl mx-auto my-auto py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Sign-in Form */}
        <div className="lg:col-span-5 bg-white rounded-2xl shadow-2xl border border-slate-200/80 p-6 sm:p-8">
          <div className="mb-6">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 text-[0.72rem] font-bold tracking-wide uppercase mb-3 border border-blue-100">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Portal Authentication</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Sign In to Your Workspace
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Access the Resource Onboarding &amp; Offboarding PMO platform with your assigned role and organizational scope.
            </p>
          </div>

          {errorMessage && (
            <div 
              id="login-error-banner"
              className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-3 text-xs text-rose-800 animate-in fade-in duration-200"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1 leading-snug">
                <p className="font-bold">Authentication Failed</p>
                <p className="mt-0.5 text-rose-700">{errorMessage}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-email" className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Enterprise Email / User ID
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="login-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name.lead@cognizant.com"
                  required
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="login-password" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Password / Passkey
                </label>
                <span className="text-[0.68rem] text-slate-400 font-medium">Demo passkey enabled</span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="login-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            <button
              id="login-submit-btn"
              type="submit"
              disabled={isSubmitting}
              className="w-full mt-2 py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <span>Verifying credentials &amp; permissions...</span>
              ) : (
                <>
                  <span>Sign In to Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between text-[0.72rem] text-slate-500">
            <span>Client &amp; Associate Privacy Safeguards</span>
            <span className="font-semibold text-slate-700">SOC 2 Type II</span>
          </div>
        </div>

        {/* Right Column: Seeded Demo Users Directory for instant role testing */}
        <div className="lg:col-span-7 bg-slate-800/80 backdrop-blur-sm rounded-2xl border border-slate-700/80 p-6 sm:p-8 text-slate-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-700 mb-5">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm sm:text-base font-bold text-white">
                Seeded Demo Directory (Select Any Role)
              </h2>
            </div>
            <span className="text-xs font-semibold text-slate-400">
              One-Click Persona Sign In
            </span>
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            Click any profile below to immediately authenticate and verify its exact permitted screens, action boundaries, and organizational scope enforcement:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[460px] overflow-y-auto pr-1">
            {users.map((u) => {
              const isInactive = u.status === 'Inactive';
              return (
                <button
                  key={u.id}
                  type="button"
                  id={`quick-login-${u.role.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => handleQuickSelect(u)}
                  className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer group flex flex-col justify-between ${
                    isInactive
                      ? 'bg-slate-900/40 border-rose-900/40 hover:border-rose-500/60 opacity-80'
                      : 'bg-slate-900/80 border-slate-700/70 hover:border-blue-500 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-white group-hover:text-blue-400 transition-colors">
                          {u.name}
                        </span>
                        {isInactive ? (
                          <span className="px-1.5 py-0.2 rounded text-[0.62rem] font-bold bg-rose-950 text-rose-400 border border-rose-800 flex items-center gap-0.5">
                            <XCircle className="w-2.5 h-2.5" />
                            Inactive
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.2 rounded text-[0.62rem] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-[0.68rem] text-slate-400 truncate max-w-[190px]">{u.email}</p>
                    </div>

                    <span className={`px-2 py-0.5 text-[0.65rem] font-bold rounded uppercase tracking-wider ${
                      u.role === 'Admin' 
                        ? 'bg-purple-900/60 text-purple-300 border border-purple-700' 
                        : u.role === 'PMO'
                        ? 'bg-blue-900/60 text-blue-300 border border-blue-700'
                        : u.role === 'Executive'
                        ? 'bg-amber-900/60 text-amber-300 border border-amber-700'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}>
                      {u.role}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 text-[0.68rem] text-slate-400 flex items-center justify-between">
                    <div className="flex items-center gap-1 truncate max-w-[180px]">
                      <Building className="w-3 h-3 text-slate-500 flex-shrink-0" />
                      <span className="truncate">
                        {u.accountScope}
                        {u.programScope && u.programScope !== 'All' ? ` → ${u.programScope}` : ''}
                        {u.projectScope && u.projectScope !== 'All' ? ` → ${u.projectScope}` : ''}
                      </span>
                    </div>
                    <span className="text-[0.65rem] text-blue-400 font-semibold group-hover:translate-x-0.5 transition-transform flex-shrink-0">
                      {isInactive ? 'Test Reject →' : 'Sign in →'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-4 p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-[0.72rem] text-slate-400 flex items-center justify-between">
            <span>Testing Inactive Restriction:</span>
            <span className="text-slate-300">
              Clicking <strong>David Rodriguez</strong> confirms that inactive accounts cannot log in.
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="w-full max-w-6xl mx-auto pt-6 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500">
        <span>&copy; {new Date().getFullYear()} Cognizant Technology Solutions. All rights reserved.</span>
        <div className="flex items-center gap-4">
          <span>Enterprise Confidential</span>
          <span>Security &amp; Compliance Active</span>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { 
  AlertCircle, 
  ArrowRight, 
  Clock, 
  Truck, 
  UserCheck, 
  Laptop, 
  Send, 
  ChevronRight,
  Filter,
  RotateCcw
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OnboardingRecord, OffboardingRecord } from '../../types';

export const DashboardScreen: React.FC = () => {
  const {
    filters,
    setFilter,
    resetFilters,
    selectedAccount,
    setSelectedAccount,
    accounts,
    locations,
    managers,
    getProgramsForAccount,
    getProjectsForProgram,
    onboardingRecords,
    offboardingRecords,
    onboardingKpis,
    offboardingKpis,
    setActiveScreen,
    setSelectedOnboardingId,
    setSelectedOffboardingId,
  } = useApp();

  const availablePrograms = getProgramsForAccount(selectedAccount);
  const availableProjects = getProjectsForProgram(filters.program, selectedAccount);

  // Filtered lists for scoping
  const filterByScope = <T extends { account: string; program?: string; project?: string; location?: string; manager?: string; status?: string }>(items: T[]): T[] => {
    return items.filter(item => {
      if (selectedAccount !== 'all') {
        const acc = accounts.find(a => a.id === selectedAccount);
        if (acc && item.account.toLowerCase() !== acc.name.toLowerCase()) return false;
      }
      if (filters.program !== 'all' && item.program && item.program !== filters.program) return false;
      if (filters.project !== 'all' && item.project && item.project !== filters.project) return false;
      if (filters.location !== 'all' && item.location && !item.location.toLowerCase().includes(filters.location.toLowerCase())) return false;
      if (filters.manager !== 'all' && item.manager && !item.manager.toLowerCase().includes(filters.manager.toLowerCase())) return false;
      if (filters.status !== 'all' && item.status && item.status !== filters.status) return false;
      return true;
    });
  };

  const scopedOnboardings = filterByScope<OnboardingRecord>(onboardingRecords);
  const scopedOffboardings = filterByScope<OffboardingRecord>(offboardingRecords);

  const isWithinDashboardDateRange = (dateValue: string) => {
    if (filters.dateRange === 'all') return true;
    const date = new Date(dateValue);
    if (Number.isNaN(date.getTime())) return true;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const end = new Date(today);
    if (filters.dateRange === 'next_30_days') end.setDate(end.getDate() + 30);
    else if (filters.dateRange === 'next_90_days') end.setDate(end.getDate() + 90);
    else {
      end.setMonth(end.getMonth() + 1, 0);
    }
    return date >= today && date <= end;
  };

  const dashboardOnboardings = scopedOnboardings.filter(r => isWithinDashboardDateRange(r.effectiveDate));
  const dashboardOffboardings = scopedOffboardings.filter(r => isWithinDashboardDateRange(r.lastWorkingDate));

  // Items requiring attention are derived from the currently scoped lifecycle records.
  const attentionItems = [
    ...dashboardOnboardings
      .filter(r => r.status === 'Delayed' || r.status === 'Pending' || !!r.blocker)
      .map(r => ({ id: r.id, type: 'Onboarding', associateName: r.associateName, associateId: r.associateId, program: r.program, project: r.projectName, status: r.status, detail: r.blocker || `${r.status} onboarding requires follow-up.`, targetScreen: 'onboarding' as const })),
    ...dashboardOffboardings
      .filter(r => r.status === 'Delayed' || r.status === 'Pending' || !!r.blocker)
      .map(r => ({ id: r.id, type: 'Offboarding', associateName: r.associateName, associateId: r.associateId, program: r.program, project: r.projectName, status: r.status, detail: r.blocker || `${r.status} offboarding requires follow-up.`, targetScreen: 'offboarding' as const }))
  ].slice(0, 8);

  // Upcoming onboarding (next 14 days)
  const upcomingOnboardings = dashboardOnboardings.slice(0, 5);
  // Upcoming offboarding (next 14 days)
  const upcomingOffboardings = dashboardOffboardings.slice(0, 5);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Delayed':
        return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Pending':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Completed':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getHardwareStatusBadge = (status: string) => {
    switch (status) {
      case 'Delivered':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Dispatched':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Pending Build':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Delayed':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Operational Scoping Bar */}
      <section className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Operational Scoping Filters
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 rounded-full border border-blue-200">
              Active Target: {selectedAccount === 'all' ? 'Global Portfolio' : accounts.find(a => a.id === selectedAccount)?.name}
            </span>
            <button
              onClick={resetFilters}
              className="flex items-center gap-1 text-[0.7rem] text-slate-500 hover:text-slate-800 transition-colors cursor-pointer px-2 py-1 rounded hover:bg-slate-100"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 text-xs">
          {/* Account */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Company / Account</label>
            <select
              value={selectedAccount}
              onChange={e => setSelectedAccount(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Accounts (Global)</option>
              {accounts.map(acc => (
                <option key={acc.id} value={acc.id}>{acc.name}</option>
              ))}
            </select>
          </div>

          {/* Program */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Program</label>
            <select
              value={filters.program}
              onChange={e => setFilter('program', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Programs</option>
              {availablePrograms.map(prog => (
                <option key={prog.id} value={prog.name}>{prog.name}</option>
              ))}
            </select>
          </div>

          {/* Project */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Project</label>
            <select
              value={filters.project}
              onChange={e => setFilter('project', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Projects</option>
              {availableProjects.map(prj => (
                <option key={prj.id} value={prj.name}>{prj.name}</option>
              ))}
            </select>
          </div>

          {/* Location */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Location</label>
            <select
              value={filters.location}
              onChange={e => setFilter('location', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Locations</option>
              {locations.map(loc => (
                <option key={loc.id} value={loc.name}>{loc.name}</option>
              ))}
            </select>
          </div>

          {/* Manager */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Manager</label>
            <select
              value={filters.manager}
              onChange={e => setFilter('manager', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Managers</option>
              {managers.map(mgr => (
                <option key={mgr.id} value={mgr.name}>{mgr.name}</option>
              ))}
            </select>
          </div>

          {/* Status */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Status</label>
            <select
              value={filters.status}
              onChange={e => setFilter('status', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="In Progress">In Progress</option>
              <option value="Delayed">Delayed</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          {/* Date Range */}
          <div>
            <label className="block text-[0.68rem] font-semibold text-slate-500 mb-1">Date Range</label>
            <select
              value={filters.dateRange}
              onChange={e => setFilter('dateRange', e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-blue-500 focus:bg-white"
            >
              <option value="current_month">Current Month</option>
              <option value="next_30_days">Next 30 Days</option>
              <option value="next_90_days">Next 90 Days</option>
              <option value="all">All Dates</option>
            </select>
          </div>
        </div>
      </section>

      {/* Two KPI Summary Cards: Onboarding Overview & Offboarding Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Onboarding Overview */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  <span>Onboarding Overview</span>
                </h3>
                <p className="text-[0.72rem] text-slate-500">Active records in deployment pipeline</p>
              </div>
              <div className="text-right">
                <span className="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider block">Total Active</span>
                <span className="text-2xl font-black text-slate-900 leading-none">
                  {onboardingKpis.totalActive}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-5 gap-2 mt-4 text-center">
              <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-100">
                <span className="text-[0.68rem] font-medium text-slate-500 block mb-1">Upcoming</span>
                <span className="text-lg font-bold text-slate-800">{onboardingKpis.upcoming}</span>
              </div>
              <div className="bg-blue-50/60 rounded-lg p-2.5 border border-blue-100">
                <span className="text-[0.68rem] font-medium text-blue-700 block mb-1">In Progress</span>
                <span className="text-lg font-bold text-blue-700">{onboardingKpis.inProgress}</span>
              </div>
              <div className="bg-amber-50/60 rounded-lg p-2.5 border border-amber-100">
                <span className="text-[0.68rem] font-medium text-amber-700 block mb-1">Pending Action</span>
                <span className="text-lg font-bold text-amber-700">{onboardingKpis.pending}</span>
              </div>
              <div className="bg-emerald-50/60 rounded-lg p-2.5 border border-emerald-100">
                <span className="text-[0.68rem] font-medium text-emerald-700 block mb-1">Completed</span>
                <span className="text-lg font-bold text-emerald-700">{onboardingKpis.completed}</span>
              </div>
              <div className="bg-rose-50/60 rounded-lg p-2.5 border border-rose-100">
                <span className="text-[0.68rem] font-medium text-rose-700 block mb-1">Delayed</span>
                <span className="text-lg font-bold text-rose-700">{onboardingKpis.delayed}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500 text-[0.72rem]">
              Active lifecycle records: <strong className="text-slate-700 font-bold">{onboardingKpis.totalActive + onboardingKpis.completed}</strong>
            </span>
            <button
              onClick={() => setActiveScreen('onboarding')}
              className="text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer text-[0.75rem]"
            >
              <span>Manage Onboardings</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Offboarding Overview */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-purple-600" />
                  <span>Offboarding Overview</span>
                </h3>
                <p className="text-[0.72rem] text-slate-500">Resource roll-off &amp; asset de-provisioning</p>
              </div>
              <div className="text-right">
                <span className="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider block">Total Active</span>
                <span className="text-2xl font-black text-slate-900 leading-none">
                  {offboardingKpis.totalActive}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-5 gap-2 mt-4 text-center">
              <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-100">
                <span className="text-[0.68rem] font-medium text-slate-500 block mb-1">Upcoming</span>
                <span className="text-lg font-bold text-slate-800">{offboardingKpis.upcoming}</span>
              </div>
              <div className="bg-blue-50/60 rounded-lg p-2.5 border border-blue-100">
                <span className="text-[0.68rem] font-medium text-blue-700 block mb-1">In Progress</span>
                <span className="text-lg font-bold text-blue-700">{offboardingKpis.inProgress}</span>
              </div>
              <div className="bg-amber-50/60 rounded-lg p-2.5 border border-amber-100">
                <span className="text-[0.68rem] font-medium text-amber-700 block mb-1">Pending Action</span>
                <span className="text-lg font-bold text-amber-700">{offboardingKpis.pending}</span>
              </div>
              <div className="bg-emerald-50/60 rounded-lg p-2.5 border border-emerald-100">
                <span className="text-[0.68rem] font-medium text-emerald-700 block mb-1">Completed</span>
                <span className="text-lg font-bold text-emerald-700">{offboardingKpis.completed}</span>
              </div>
              <div className="bg-rose-50/60 rounded-lg p-2.5 border border-rose-100">
                <span className="text-[0.68rem] font-medium text-rose-700 block mb-1">Delayed</span>
                <span className="text-lg font-bold text-rose-700">{offboardingKpis.delayed}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500 text-[0.72rem]">
              Lifecycle records: <strong className="text-slate-700 font-bold">{offboardingKpis.totalActive + offboardingKpis.completed}</strong>
            </span>
            <button
              onClick={() => setActiveScreen('offboarding')}
              className="text-purple-600 hover:text-purple-800 font-semibold flex items-center gap-1 cursor-pointer text-[0.75rem]"
            >
              <span>Manage Offboardings</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Requires Attention */}
      <section className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50/60 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Requires Attention</h3>
              <span className="px-2 py-0.5 text-[0.65rem] font-extrabold uppercase tracking-wider bg-rose-100 text-rose-800 rounded-full border border-rose-200">{attentionItems.length}</span>
            </div>
            <p className="text-[0.72rem] text-slate-500 mt-0.5">Pending or delayed onboarding and offboarding items that need follow-up.</p>
          </div>
        </div>
        {attentionItems.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500">No onboarding or offboarding items currently require attention.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/80 text-slate-600 font-semibold uppercase text-[0.68rem] tracking-wider border-b border-slate-200"><tr><th className="py-2.5 px-4">Associate</th><th className="py-2.5 px-4">Type</th><th className="py-2.5 px-4">Program &amp; Project</th><th className="py-2.5 px-4">Reason</th><th className="py-2.5 px-4">Status</th><th className="py-2.5 px-4 text-right">Action</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {attentionItems.map(item => (
                  <tr key={`${item.type}-${item.id}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4"><div className="font-bold text-slate-900">{item.associateName}</div><div className="text-[0.7rem] text-slate-500">ID: {item.associateId}</div></td>
                    <td className="py-3 px-4 font-medium text-slate-700">{item.type}</td>
                    <td className="py-3 px-4"><div className="font-medium text-slate-800">{item.program}</div><div className="text-[0.7rem] text-slate-500">{item.project}</div></td>
                    <td className="py-3 px-4 max-w-md text-slate-700 text-[0.72rem]">{item.detail}</td>
                    <td className="py-3 px-4 whitespace-nowrap"><span className={`px-2 py-0.5 rounded-full text-[0.68rem] font-bold border uppercase ${getStatusBadge(item.status)}`}>{item.status}</span></td>
                    <td className="py-3 px-4 text-right"><button onClick={() => { setActiveScreen(item.targetScreen); if (item.targetScreen === 'onboarding') setSelectedOnboardingId(item.id); else setSelectedOffboardingId(item.id); }} className="px-3 py-1.5 rounded-lg text-[0.72rem] font-bold bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-xs cursor-pointer">View</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Bottom 2-Column Split: Upcoming Onboarding & Upcoming Offboarding */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Onboarding (Next 14 Days) */}
        <section className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between">
          <div>
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Upcoming Onboarding (Next 14 Days)</span>
                </h4>
                <p className="text-[0.68rem] text-slate-500">Pipeline scheduled for operational intake</p>
              </div>
              <span className="text-[0.68rem] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                {upcomingOnboardings.length} Active
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase text-[0.65rem] tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="py-2 px-3.5">Resource</th>
                    <th className="py-2 px-3.5">Program / Project</th>
                    <th className="py-2 px-3.5">Location</th>
                    <th className="py-2 px-3.5">Start Date</th>
                    <th className="py-2 px-3.5">Hardware</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[0.72rem]">
                  {upcomingOnboardings.map(rec => (
                    <tr 
                      key={rec.id} 
                      onClick={() => {
                        setActiveScreen('onboarding');
                        setSelectedOnboardingId(rec.id);
                      }}
                      className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-3.5 font-semibold text-slate-900">
                        {rec.associateName}
                        <span className="text-slate-400 block text-[0.65rem]">ID: {rec.associateId}</span>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-700">
                        <div className="truncate max-w-[130px] font-medium">{rec.projectName}</div>
                        <div className="text-[0.65rem] text-slate-400 truncate max-w-[130px]">{rec.program}</div>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 whitespace-nowrap">
                        {rec.city || 'Mountain View'}, {rec.state || 'CA'}
                      </td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap font-medium text-slate-800">
                        {rec.effectiveDate}
                      </td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded-full text-[0.65rem] font-bold border ${getHardwareStatusBadge(rec.deliveryStatus)}`}>
                          {rec.deliveryStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-3 bg-slate-50/60 border-t border-slate-100 text-center">
            <button
              onClick={() => setActiveScreen('onboarding')}
              className="text-blue-600 hover:text-blue-800 font-bold text-xs uppercase tracking-wider inline-flex items-center gap-1.5 cursor-pointer"
            >
              <span>View All Onboarding Pipeline Records</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </section>

        {/* Upcoming Offboarding (Next 14 Days) */}
        <section className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between">
          <div>
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-purple-600" />
                  <span>Upcoming Offboarding (Next 14 Days)</span>
                </h4>
                <p className="text-[0.68rem] text-slate-500">Active roll-offs requiring return governance</p>
              </div>
              <span className="text-[0.68rem] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                {upcomingOffboardings.length} Active
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase text-[0.65rem] tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="py-2 px-3.5">Resource</th>
                    <th className="py-2 px-3.5">Program / Project</th>
                    <th className="py-2 px-3.5">Location</th>
                    <th className="py-2 px-3.5">Last Working Day</th>
                    <th className="py-2 px-3.5">Return Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-[0.72rem]">
                  {upcomingOffboardings.map(rec => (
                    <tr 
                      key={rec.id} 
                      onClick={() => {
                        setActiveScreen('offboarding');
                        setSelectedOffboardingId(rec.id);
                      }}
                      className="hover:bg-purple-50/40 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-3.5 font-semibold text-slate-900">
                        {rec.associateName}
                        <span className="text-slate-400 block text-[0.65rem]">ID: {rec.associateId}</span>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-700">
                        <div className="truncate max-w-[130px] font-medium">{rec.projectName}</div>
                        <div className="text-[0.65rem] text-slate-400 truncate max-w-[130px]">{rec.program}</div>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 whitespace-nowrap">
                        {rec.location}
                      </td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap font-medium text-slate-800">
                        {rec.lastWorkingDate}
                        {rec.daysOverdue && (
                          <span className="ml-1 text-[0.65rem] font-bold text-rose-600">
                            (+{rec.daysOverdue}d)
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full text-[0.62rem] font-bold bg-slate-100 text-slate-700 border border-slate-200 uppercase">
                          {rec.assetStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-3 bg-slate-50/60 border-t border-slate-100 text-center">
            <button
              onClick={() => setActiveScreen('offboarding')}
              className="text-purple-600 hover:text-purple-800 font-bold text-xs uppercase tracking-wider inline-flex items-center gap-1.5 cursor-pointer"
            >
              <span>View All Offboarding Active Records</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

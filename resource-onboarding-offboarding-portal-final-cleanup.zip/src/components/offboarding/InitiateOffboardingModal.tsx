import React, { useState } from 'react';
import { X, UserMinus, Laptop, Calendar, Building2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AssetReturnStatus, OffboardingStatus } from '../../types';

export const InitiateOffboardingModal: React.FC = () => {
  const { 
    isOffboardingModalOpen, 
    setIsOffboardingModalOpen, 
    resources,
    accounts,
    returnCarriers,
    getAvailableItems,
    addOffboardingRecord,
    showToast 
  } = useApp();

  const activeResources = resources.filter(r => r.lifecycleStatus === 'Active');
  const activeReturnCarriers = getAvailableItems(returnCarriers);

  const [selectedResId, setSelectedResId] = useState(activeResources[0]?.id || '');
  const [formData, setFormData] = useState({
    associateId: activeResources[0]?.id || '1984210',
    associateName: activeResources[0]?.name || 'Priya Sunder',
    role: activeResources[0]?.title || 'Lead QE Engineer',
    phone: activeResources[0]?.phone || '+1 858-555-0419',
    email: activeResources[0]?.cognizantEmail || 'priya.sunder@cognizant.com',
    account: activeResources[0]?.accountName || 'Apex Global Financial',
    program: activeResources[0]?.programName || 'Digital Banking Platform',
    projectId: activeResources[0]?.projectId || 'prj-pay',
    projectName: activeResources[0]?.projectName || 'Instant Payment Rails',
    manager: activeResources[0]?.manager || 'Sarah Jenkins',
    location: activeResources[0]?.location || 'San Diego, CA',
    lastWorkingDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    status: 'Submitted' as OffboardingStatus,
    completionDate: null,
    assetStatus: 'BOX DISPATCH PENDING' as AssetReturnStatus,
    carrier: (activeReturnCarriers[0]?.name || returnCarriers[0]?.name || 'UPS') as any,
    trackingNumber: `1Z${Math.floor(1000000000 + Math.random() * 9000000000)}`,
    receivedDate: null,
    systemRevocation: 'Scheduled: 18:00 PST on Last Working Day',
    riskLevel: 'Low' as const
  });

  const availableReturnCarriers = getAvailableItems(returnCarriers, formData.carrier);

  if (!isOffboardingModalOpen) return null;

  const handleResourceChange = (resId: string) => {
    setSelectedResId(resId);
    const res = resources.find(r => r.id === resId);
    if (res) {
      setFormData(prev => ({
        ...prev,
        associateId: res.id,
        associateName: res.name,
        role: res.title,
        phone: res.phone,
        email: res.cognizantEmail,
        account: res.accountName,
        program: res.programName,
        projectId: res.projectId,
        projectName: res.projectName,
        manager: res.manager,
        location: res.location
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.associateName.trim()) {
      showToast('Validation Error', 'Please select or enter an associate name.', 'error');
      return;
    }

    addOffboardingRecord(formData);
    setIsOffboardingModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-purple-100 rounded-lg text-purple-700">
              <UserMinus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Initiate Resource Offboarding</h3>
              <p className="text-xs text-slate-500">
                Scheduled project roll-off, identity de-provisioning &amp; asset return tracking
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsOffboardingModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-xs flex-1">
          {/* Section 1: Resource Selection */}
          <div>
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <UserMinus className="w-3.5 h-3.5 text-purple-600" />
              <span>1. Select Active Resource to Roll Off</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">
                  Active Resource
                </label>
                <select
                  value={selectedResId}
                  onChange={e => handleResourceChange(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-slate-800 font-semibold focus:bg-white"
                >
                  {activeResources.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.name} ({r.id}) — {r.title} [{r.projectName}]
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Associate ID</label>
                <input
                  type="text"
                  readOnly
                  value={formData.associateId}
                  className="w-full bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 font-mono text-slate-700"
                />
              </div>

              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Associate Name</label>
                <input
                  type="text"
                  readOnly
                  value={formData.associateName}
                  className="w-full bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 font-semibold text-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Last Working Date & Status */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <Calendar className="w-3.5 h-3.5 text-purple-600" />
              <span>2. Timeline &amp; Roll-Off Schedule</span>
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">
                  Last Working Date (LWD) *
                </label>
                <input
                  type="date"
                  required
                  value={formData.lastWorkingDate}
                  onChange={e => setFormData({ ...formData, lastWorkingDate: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-900 font-bold focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">
                  Initial Status
                </label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as OffboardingStatus })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold focus:bg-white"
                >
                  <option value="Draft">Draft</option>
                  <option value="Submitted">Submitted (Review)</option>
                  <option value="In Progress">In Progress</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Hardware Asset Return Supporting Info */}
          <div className="pt-4 border-t border-slate-200">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <Laptop className="w-3.5 h-3.5 text-purple-600" />
              <span>3. Supporting Information: Laptop &amp; Asset Return</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Asset Status</label>
                <select
                  value={formData.assetStatus}
                  onChange={e => setFormData({ ...formData, assetStatus: e.target.value as AssetReturnStatus })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium focus:bg-white"
                >
                  <option value="BOX DISPATCH PENDING">BOX DISPATCH PENDING</option>
                  <option value="RETURN KIT IN TRANSIT">RETURN KIT IN TRANSIT</option>
                  <option value="LAPTOP PICKUP SCHEDULED">LAPTOP PICKUP SCHEDULED</option>
                  <option value="PENDING BOX DELIVERY">PENDING BOX DELIVERY</option>
                </select>
              </div>

              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Return Carrier</label>
                <select
                  value={formData.carrier}
                  onChange={e => setFormData({ ...formData, carrier: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white"
                >
                  {availableReturnCarriers.map(rc => (
                    <option key={rc.id} value={rc.name}>
                      {rc.name}{rc.status === 'Inactive' ? ' (Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Tracking Number</label>
                <input
                  type="text"
                  value={formData.trackingNumber}
                  onChange={e => setFormData({ ...formData, trackingNumber: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono text-slate-800 focus:bg-white"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsOffboardingModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold uppercase tracking-wider bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors shadow-sm cursor-pointer"
            >
              Initiate Offboarding
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

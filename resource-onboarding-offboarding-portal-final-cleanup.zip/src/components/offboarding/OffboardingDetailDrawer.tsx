import React, { useState } from 'react';
import { 
  X, 
  AlertTriangle, 
  Laptop, 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  ExternalLink,
  ShieldAlert,
  Calendar,
  Truck,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OffboardingStatus } from '../../types';

export const OffboardingDetailDrawer: React.FC = () => {
  const {
    selectedOffboardingId,
    setSelectedOffboardingId,
    offboardingRecords,
    updateOffboardingStatus,
    updateOffboardingRecord,
    triggerPickup,
    showToast
  } = useApp();

  const record = offboardingRecords.find(r => r.id === selectedOffboardingId);

  const [currentStatus, setCurrentStatus] = useState<OffboardingStatus>(record?.status || 'In Progress');

  if (!selectedOffboardingId || !record) return null;

  const handleStatusChange = (newStatus: OffboardingStatus) => {
    setCurrentStatus(newStatus);
    updateOffboardingStatus(record.id, newStatus);
  };

  const handleMarkReturned = () => {
    updateOffboardingRecord({
      ...record,
      assetStatus: 'LAPTOP RETURNED',
      receivedDate: `${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} (Received Hub - Wiped & Certified)`,
      status: 'Completed',
      blocker: null,
      blockerAction: null,
      daysOverdue: 0
    });
    showToast('Asset Received & Certified', `Hardware marked as returned for ${record.associateName}. Audit closed.`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-250 border-l border-slate-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/80 sticky top-0 z-10">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[0.68rem] font-extrabold uppercase tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                  OFFBOARDING RECORD: {record.id}
                </span>
                <span className={`text-[0.68rem] font-bold uppercase px-2 py-0.5 rounded-full border ${
                  record.status === 'Delayed' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                  record.status === 'Completed' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                  'bg-blue-100 text-blue-700 border-blue-200'
                }`}>
                  {record.status}
                </span>
              </div>
              <h2 className="text-lg font-black text-slate-900 mt-1">
                {record.associateName}
              </h2>
              <p className="text-xs text-slate-600 font-medium">
                {record.role} • {record.program} ({record.projectName})
              </p>
            </div>
            <button
              onClick={() => setSelectedOffboardingId(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Drawer Body Content */}
        <div className="p-5 space-y-6 text-xs">
          {/* Overdue Warning */}
          {record.daysOverdue && record.daysOverdue > 0 ? (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="font-bold text-rose-900 text-xs">
                    Governance SLA Breach: {record.daysOverdue} Days Post-LWD Overdue
                  </div>
                  <p className="text-[0.72rem] text-rose-700 mt-0.5 leading-relaxed">
                    {record.blocker || 'Laptop return kit has not been processed. Equipment return past allowed grace period.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => triggerPickup(record.id)}
                className="px-2.5 py-1 text-[0.65rem] font-bold uppercase bg-rose-600 text-white rounded hover:bg-rose-700 whitespace-nowrap cursor-pointer"
              >
                TRIGGER PICKUP
              </button>
            </div>
          ) : null}

          {/* Section 1: Resource Profile */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5 mb-3">
              <Building2 className="w-3.5 h-3.5 text-purple-600" />
              <span>Resource &amp; Assignment Context</span>
            </h4>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Associate ID</span>
                <span className="font-semibold text-slate-900 font-mono">{record.associateId}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Account / Client</span>
                <span className="font-semibold text-slate-900">{record.account}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Program Stream</span>
                <span className="font-semibold text-slate-800">{record.program}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Project Code &amp; Name</span>
                <span className="font-semibold text-slate-800">{record.projectId} - {record.projectName}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Reporting Manager</span>
                <span className="font-semibold text-slate-800">{record.manager}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Deployment Location</span>
                <span className="font-medium text-slate-700 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  {record.location}
                </span>
              </div>
            </div>
          </div>

          {/* Section 2: Offboarding Dates & De-provisioning */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5 mb-3">
              <Calendar className="w-3.5 h-3.5 text-purple-600" />
              <span>Offboarding Schedule &amp; System Revocation</span>
            </h4>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Last Working Date (LWD)</span>
                <span className="font-bold text-slate-900">{record.lastWorkingDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Completion / Roll-off Date</span>
                <span className="font-medium text-slate-700">{record.completionDate || 'In Progress'}</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[0.65rem]">System / Identity Revocation Status</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <Lock className="w-3 h-3 text-slate-400" />
                  <span className="font-semibold text-slate-800">{record.systemRevocation}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Supporting Information - Laptop & Asset Return */}
          <div className="bg-slate-50/60 rounded-xl border border-slate-200/80 p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-[0.72rem] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Laptop className="w-3.5 h-3.5 text-purple-600" />
                <span>Supporting Information: Hardware Return</span>
              </h4>
              <span className="px-2 py-0.5 rounded-full text-[0.62rem] font-bold bg-purple-100 text-purple-800 border border-purple-200 uppercase">
                {record.assetStatus}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-[0.72rem]">
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Return Courier Carrier</span>
                <span className="font-semibold text-slate-800 flex items-center gap-1">
                  <Truck className="w-3 h-3 text-slate-400" />
                  {record.carrier}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[0.65rem]">Return Tracking Number</span>
                <span className="font-bold font-mono text-blue-700 flex items-center gap-1">
                  {record.trackingNumber}
                  <ExternalLink className="w-3 h-3" />
                </span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[0.65rem]">Physical Receipt &amp; Wipe Verification</span>
                <span className="font-medium text-slate-700">
                  {record.receivedDate || 'Pending Hub Receipt & Verification'}
                </span>
              </div>
            </div>

            {record.assetStatus !== 'LAPTOP RETURNED' && (
              <div className="mt-3 pt-3 border-t border-slate-200/80 flex items-center justify-end">
                <button
                  onClick={handleMarkReturned}
                  className="px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Confirm Asset Received &amp; Certified Wiped</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-4 bg-slate-100/90 border-t border-slate-200 flex items-center justify-between gap-3 sticky bottom-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-600">Update Status:</span>
            <select
              value={currentStatus}
              onChange={e => handleStatusChange(e.target.value as OffboardingStatus)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer"
            >
              <option value="Draft">Draft</option>
              <option value="Submitted">Submitted</option>
              <option value="In Progress">In Progress</option>
              <option value="Pending">Pending</option>
              <option value="Completed">Completed</option>
              <option value="Delayed">Delayed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedOffboardingId(null)}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

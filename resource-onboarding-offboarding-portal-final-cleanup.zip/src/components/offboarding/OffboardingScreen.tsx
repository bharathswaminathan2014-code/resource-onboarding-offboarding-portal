import React, { useState } from 'react';
import { 
  UserMinus, 
  Search, 
  Filter, 
  RotateCcw, 
  ChevronRight, 
  AlertTriangle, 
  ShieldAlert, 
  Laptop, 
  CheckCircle2, 
  Lock, 
  Truck, 
  Clock, 
  ExternalLink 
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OffboardingStatus } from '../../types';
import { OffboardingDetailDrawer } from './OffboardingDetailDrawer';
import { InitiateOffboardingModal } from './InitiateOffboardingModal';

export const OffboardingScreen: React.FC = () => {
  const {
    offboardingRecords,
    offboardingKpis,
    selectedAccount,
    accounts,
    locations,
    getProgramsForAccount,
    selectedOffboardingId,
    setSelectedOffboardingId,
    setIsOffboardingModalOpen,
    checkCarrier,
    canCreateOffboarding
  } = useApp();

  const availablePrograms = getProgramsForAccount(selectedAccount);

  const [activeTab, setActiveTab] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterProgram, setFilterProgram] = useState('All');
  const [filterLocation, setFilterLocation] = useState('All');

  // Filter records
  const filteredRecords = offboardingRecords.filter(record => {
    // Account filter
    if (selectedAccount !== 'all') {
      const acc = accounts.find(a => a.id === selectedAccount);
      if (acc && record.account.toLowerCase() !== acc.name.toLowerCase()) return false;
    }

    // Tab status filter
    if (activeTab !== 'All' && record.status !== activeTab) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match = 
        record.associateName.toLowerCase().includes(q) ||
        record.associateId.toLowerCase().includes(q) ||
        record.trackingNumber.toLowerCase().includes(q) ||
        record.projectName.toLowerCase().includes(q) ||
        record.program.toLowerCase().includes(q);
      if (!match) return false;
    }

    // Dropdowns
    if (filterProgram !== 'All' && record.program !== filterProgram) return false;
    if (filterLocation !== 'All' && !record.location.includes(filterLocation)) return false;

    return true;
  });

  const resetAllFilters = () => {
    setActiveTab('All');
    setSearchQuery('');
    setFilterProgram('All');
    setFilterLocation('All');
  };

  const tabs: { label: string; count: number }[] = [
    { label: 'All', count: offboardingRecords.length },
    { label: 'Draft', count: offboardingKpis.draft },
    { label: 'Submitted', count: offboardingKpis.submitted },
    { label: 'In Progress', count: offboardingKpis.inProgress },
    { label: 'Pending', count: offboardingKpis.pending },
    { label: 'Completed', count: offboardingKpis.completed },
    { label: 'Delayed', count: offboardingKpis.delayed },
    { label: 'Cancelled', count: offboardingKpis.cancelled }
  ];

  const getStatusBadge = (status: OffboardingStatus) => {
    switch (status) {
      case 'Delayed':
        return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'Completed':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Pending':
        return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Submitted':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Critical SLA Governance Alert Banner */}
      <div className="bg-rose-700 text-white px-4 py-3 rounded-xl shadow-xs flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-rose-800 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-white animate-pulse" />
          </div>
          <div>
            <span className="font-extrabold uppercase tracking-wider text-xs mr-2">
              CRITICAL GOVERNANCE SLA ALERT:
            </span>
            <span className="text-xs text-rose-100">
              2 Hardware assets overdue (&gt;3 days post-LWD). Regulatory non-compliance risk escalated to PMO Lead.
            </span>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('Delayed')}
          className="px-3 py-1 bg-white text-rose-800 hover:bg-rose-50 text-[0.7rem] font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
        >
          View Escalations
        </button>
      </div>

      {/* Top Action Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-extrabold text-slate-900 tracking-tight">
              Offboarding Operations
            </h2>
            <span className="px-2 py-0.5 text-[0.68rem] font-bold uppercase tracking-wider bg-purple-50 text-purple-700 rounded-full border border-purple-200">
              Active Records: {offboardingKpis.totalActive} Offboarding
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Resource roll-off tracking, identity and access revocation, and hardware return governance
          </p>
        </div>

        {canCreateOffboarding && (
          <button
            id="btn-initiate-offboarding"
            onClick={() => setIsOffboardingModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-xs cursor-pointer"
          >
            <UserMinus className="w-4 h-4" />
            <span>+ Initiate Offboarding</span>
          </button>
        )}
      </div>

      {/* 4 KPI Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Hardware Recovery */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Hardware Recovery
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">
              0{offboardingKpis.hardwareRecoveryAwaiting}
            </span>
            <span className="text-[0.65rem] font-semibold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
              Laptops Awaiting Return
            </span>
          </div>
        </div>

        {/* Logistics Courier */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Logistics Courier
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-blue-700">
              0{offboardingKpis.logisticsInTransit}
            </span>
            <span className="text-[0.65rem] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
              Return Kits In Transit
            </span>
          </div>
        </div>

        {/* Audit Closure */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Audit Closure
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-700">
              {offboardingKpis.auditClosed}
            </span>
            <span className="text-[0.65rem] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              Returned &amp; Verified MTD
            </span>
          </div>
        </div>

        {/* Compliance Breach */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Compliance Breach
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-rose-700">
              0{offboardingKpis.complianceBreachOverdue}
            </span>
            <span className="text-[0.65rem] font-semibold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded">
              &gt;3 Days Post-LWD Overdue
            </span>
          </div>
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-b border-slate-200">
        {tabs.map(tab => (
          <button
            key={tab.label}
            onClick={() => setActiveTab(tab.label)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === tab.label
                ? 'bg-purple-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
            }`}
          >
            <span>{tab.label}</span>
            <span className={`px-1.5 py-0.2 text-[0.65rem] rounded-full font-bold ${
              activeTab === tab.label ? 'bg-purple-800 text-white' : 'bg-slate-200 text-slate-600'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Scoping Search & Quick Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search Associate Name, ID, Tracking #, Project..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-slate-800 focus:bg-white focus:ring-1 focus:ring-purple-500"
            />
          </div>

          {/* Program filter */}
          <div>
            <select
              value={filterProgram}
              onChange={e => setFilterProgram(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Programs</option>
              {availablePrograms.map(p => (
                <option key={p.id} value={p.name}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Location & Reset */}
          <div className="flex items-center gap-2">
            <select
              value={filterLocation}
              onChange={e => setFilterLocation(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-800 focus:bg-white font-medium"
            >
              <option value="All">All Locations</option>
              {locations.map(loc => (
                <option key={loc.id} value={loc.name}>{loc.name}</option>
              ))}
            </select>

            <button
              onClick={resetAllFilters}
              title="Reset Filters"
              className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[0.68rem] tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4"># &amp; S.NO</th>
                <th className="py-3 px-4">Associate &amp; Role</th>
                <th className="py-3 px-4">Program &amp; Project</th>
                <th className="py-3 px-4">Manager &amp; Location</th>
                <th className="py-3 px-4">Last Working Date</th>
                <th className="py-3 px-4">Asset Status &amp; Tracking</th>
                <th className="py-3 px-4">Received Date</th>
                <th className="py-3 px-4">System Revocation</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[0.75rem]">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400">
                    No offboarding records match the current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record, index) => (
                  <tr
                    key={record.id}
                    onClick={() => setSelectedOffboardingId(record.id)}
                    className="hover:bg-purple-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">
                      <span className="text-slate-400 font-normal mr-1.5">{index + 1}.</span>
                      {record.associateId}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{record.associateName}</div>
                      <div className="text-[0.7rem] text-slate-500">{record.role}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{record.projectName}</div>
                      <div className="text-[0.7rem] text-slate-500">{record.program}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      <div>{record.location}</div>
                      <div className="text-[0.7rem] text-slate-400">{record.manager}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-bold text-slate-900">{record.lastWorkingDate}</div>
                      {record.daysOverdue && record.daysOverdue > 0 ? (
                        <span className="inline-block mt-0.5 text-[0.62rem] font-extrabold uppercase px-1.5 py-0.2 bg-rose-100 text-rose-700 rounded border border-rose-200">
                          +{record.daysOverdue} Days Overdue
                        </span>
                      ) : null}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 text-[0.65rem] font-bold rounded-full bg-slate-100 text-slate-800 border border-slate-200 uppercase block mb-1 w-fit">
                        {record.assetStatus}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          checkCarrier(record.trackingNumber);
                        }}
                        className="text-[0.68rem] font-mono text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                      >
                        <span>{record.carrier} #{record.trackingNumber}</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </button>
                    </td>
                    <td className="py-3 px-4 text-slate-600 text-[0.7rem]">
                      {record.receivedDate || 'Pending Hub'}
                    </td>
                    <td className="py-3 px-4 text-slate-700 text-[0.7rem] max-w-[150px] truncate">
                      {record.systemRevocation}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-[0.68rem] font-bold border uppercase ${getStatusBadge(record.status)}`}>
                        {record.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedOffboardingId(record.id);
                        }}
                        className="px-2.5 py-1 text-[0.7rem] font-bold uppercase tracking-wider text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded transition-colors cursor-pointer inline-flex items-center gap-1"
                      >
                        <span>Details</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table footer */}
        <div className="p-3 bg-slate-50/60 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Showing {filteredRecords.length} of {offboardingRecords.length} records</span>
          <span className="text-[0.7rem] text-slate-400">Click any row to manage return tracking &amp; audit sign-off</span>
        </div>
      </div>

      {/* Offboarding Detail Drawer */}
      <OffboardingDetailDrawer />

      {/* Initiate Offboarding Modal */}
      <InitiateOffboardingModal />
    </div>
  );
};

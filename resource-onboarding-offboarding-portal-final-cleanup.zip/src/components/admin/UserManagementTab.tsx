import React, { useState, useMemo } from 'react';
import { 
  Users, 
  UserPlus, 
  ShieldCheck, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Edit3, 
  Power, 
  Building, 
  Layers, 
  Briefcase, 
  X,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PortalUser, UserRole } from '../../types';

export const UserManagementTab: React.FC = () => {
  const {
    users,
    addUser,
    updateUser,
    toggleUserStatus,
    deleteUser,
    accounts,
    currentUser,
    showToast
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modal State for Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    name: string;
    email: string;
    role: UserRole;
    accountScope: string;
    programScope: string;
    projectScope: string;
    status: 'Active' | 'Inactive';
  }>({
    name: '',
    email: '',
    role: 'Operational User',
    accountScope: 'All',
    programScope: 'All',
    projectScope: 'All',
    status: 'Active'
  });

  const allRoles: UserRole[] = [
    'Executive',
    'Senior Leader',
    'Senior Manager',
    'Manager',
    'PMO',
    'Operational User',
    'Admin'
  ];

  // Cascading Scope Calculations based on form's selected Account and Program
  const selectedAccountObj = useMemo(() => {
    if (!formData.accountScope || formData.accountScope === 'All') return null;
    return accounts.find(
      a =>
        a.id === formData.accountScope ||
        a.name.toLowerCase() === formData.accountScope.toLowerCase()
    ) || null;
  }, [formData.accountScope, accounts]);

  const availableProgramsForAccount = useMemo(() => {
    if (!selectedAccountObj) return [];
    return selectedAccountObj.programs;
  }, [selectedAccountObj]);

  const selectedProgramObj = useMemo(() => {
    if (!formData.programScope || formData.programScope === 'All') return null;
    return (
      availableProgramsForAccount.find(
        p =>
          p.id === formData.programScope ||
          p.name.toLowerCase() === formData.programScope.toLowerCase()
      ) || null
    );
  }, [formData.programScope, availableProgramsForAccount]);

  const availableProjectsForProgram = useMemo(() => {
    if (!selectedProgramObj) return [];
    return selectedProgramObj.projects;
  }, [selectedProgramObj]);

  // Open Modal for Add
  const handleOpenAdd = () => {
    setEditingUserId(null);
    setFormData({
      name: '',
      email: '',
      role: 'Operational User',
      accountScope: 'All',
      programScope: 'All',
      projectScope: 'All',
      status: 'Active'
    });
    setIsModalOpen(true);
  };

  // Open Modal for Edit
  const handleOpenEdit = (user: PortalUser) => {
    setEditingUserId(user.id);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      accountScope: user.accountScope || 'All',
      programScope: user.programScope || 'All',
      projectScope: user.projectScope || 'All',
      status: user.status
    });
    setIsModalOpen(true);
  };

  // Cascading scope updates
  const handleAccountScopeChange = (newAccScope: string) => {
    setFormData(prev => ({
      ...prev,
      accountScope: newAccScope,
      // When account changes, child scopes must revalidate
      programScope: 'All',
      projectScope: 'All'
    }));
  };

  const handleProgramScopeChange = (newProgScope: string) => {
    setFormData(prev => ({
      ...prev,
      programScope: newProgScope,
      // When program changes, project scope must revalidate
      projectScope: 'All'
    }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim()) {
      showToast('Validation Error', 'Display name and email are mandatory.', 'error');
      return;
    }

    // Check duplicate email
    const duplicate = users.find(
      u => u.email.toLowerCase() === formData.email.trim().toLowerCase() && u.id !== editingUserId
    );
    if (duplicate) {
      showToast('Duplicate Email', 'A portal user with this email address already exists.', 'error');
      return;
    }

    if (editingUserId) {
      // Update
      updateUser(editingUserId, {
        name: formData.name.trim(),
        email: formData.email.trim(),
        role: formData.role,
        accountScope: formData.accountScope,
        programScope: formData.programScope,
        projectScope: formData.projectScope,
        status: formData.status
      });
      showToast('User Updated', `Updated credentials and scopes for ${formData.name}.`);
    } else {
      // Add
      addUser({
        name: formData.name.trim(),
        email: formData.email.trim(),
        role: formData.role,
        accountScope: formData.accountScope,
        programScope: formData.programScope,
        projectScope: formData.projectScope,
        status: formData.status
      });
      showToast('User Created', `Added new user ${formData.name} as ${formData.role}.`);
    }

    setIsModalOpen(false);
  };

  // Filtered users list
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        user.name.toLowerCase().includes(q) ||
        user.email.toLowerCase().includes(q) ||
        user.role.toLowerCase().includes(q) ||
        (user.accountScope || '').toLowerCase().includes(q) ||
        (user.programScope || '').toLowerCase().includes(q) ||
        (user.projectScope || '').toLowerCase().includes(q);

      const matchesRole = roleFilter === 'all' || user.role === roleFilter;
      const matchesStatus = statusFilter === 'all' || user.status === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchQuery, roleFilter, statusFilter]);

  const activeCount = users.filter(u => u.status === 'Active').length;
  const inactiveCount = users.filter(u => u.status === 'Inactive').length;

  return (
    <div className="space-y-6">
      {/* Top Stats Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Total Portal Users</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">{users.length}</div>
          <p className="text-[0.68rem] text-slate-400 mt-1">Configured enterprise personas</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Active Directory</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-600">{activeCount}</div>
          <p className="text-[0.68rem] text-slate-400 mt-1">Permitted to authenticate</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Deactivated</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-600">{inactiveCount}</div>
          <p className="text-[0.68rem] text-slate-400 mt-1">Login strictly rejected</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>RBAC Roles Defined</span>
            <ShieldCheck className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-purple-700">{allRoles.length}</div>
          <p className="text-[0.68rem] text-slate-400 mt-1">From Executive to Admin</p>
        </div>
      </div>

      {/* Filter and Action Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3 w-full md:w-auto flex-1">
          {/* Search Input */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name, email, scope..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
            />
          </div>

          {/* Role Filter */}
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-700"
          >
            <option value="all">All Roles</option>
            {allRoles.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="py-1.5 px-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-700"
          >
            <option value="all">All Statuses</option>
            <option value="Active">Active Only</option>
            <option value="Inactive">Inactive Only</option>
          </select>
        </div>

        {/* Add User Button */}
        <button
          id="admin-add-user-btn"
          onClick={handleOpenAdd}
          className="w-full md:w-auto py-2 px-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Add New User</span>
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[0.68rem] uppercase tracking-wider text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">User &amp; Identity</th>
                <th className="py-3 px-4">Portal Role</th>
                <th className="py-3 px-4">Account Scope</th>
                <th className="py-3 px-4">Program Scope</th>
                <th className="py-3 px-4">Project Scope</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    No portal users matched your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredUsers.map(user => {
                  const isCurrent = currentUser?.id === user.id;
                  return (
                    <tr 
                      key={user.id} 
                      className={`hover:bg-slate-50/70 transition-colors ${
                        user.status === 'Inactive' ? 'bg-slate-50/40 text-slate-400' : ''
                      }`}
                    >
                      {/* Name & Email */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[0.65rem] font-black text-white ${
                            user.role === 'Admin' ? 'bg-purple-700' :
                            user.role === 'PMO' ? 'bg-blue-700' :
                            user.role === 'Executive' ? 'bg-amber-600' : 'bg-slate-700'
                          }`}>
                            {user.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 flex items-center gap-1.5">
                              <span>{user.name}</span>
                              {isCurrent && (
                                <span className="px-1.5 py-0.2 bg-blue-100 text-blue-700 rounded text-[0.62rem] font-bold">
                                  You
                                </span>
                              )}
                            </div>
                            <div className="text-[0.68rem] text-slate-400">{user.email}</div>
                          </div>
                        </div>
                      </td>

                      {/* Role Badge */}
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[0.68rem] font-bold ${
                          user.role === 'Admin' ? 'bg-purple-100 text-purple-800 border border-purple-200' :
                          user.role === 'PMO' ? 'bg-blue-100 text-blue-800 border border-blue-200' :
                          user.role === 'Executive' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                          user.role === 'Senior Leader' ? 'bg-indigo-100 text-indigo-800 border border-indigo-200' :
                          user.role === 'Senior Manager' ? 'bg-teal-100 text-teal-800 border border-teal-200' :
                          user.role === 'Manager' ? 'bg-sky-100 text-sky-800 border border-sky-200' :
                          'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}>
                          {user.role}
                        </span>
                      </td>

                      {/* Account Scope */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1 font-medium text-slate-800">
                          <Building className="w-3 h-3 text-slate-400 flex-shrink-0" />
                          <span className="truncate max-w-[150px]">
                            {user.accountScope || 'All'}
                          </span>
                        </div>
                      </td>

                      {/* Program Scope */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1 text-slate-600">
                          <Layers className="w-3 h-3 text-slate-400 flex-shrink-0" />
                          <span className="truncate max-w-[150px]">
                            {user.programScope || 'All'}
                          </span>
                        </div>
                      </td>

                      {/* Project Scope */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1 text-slate-600">
                          <Briefcase className="w-3 h-3 text-slate-400 flex-shrink-0" />
                          <span className="truncate max-w-[150px]">
                            {user.projectScope || 'All'}
                          </span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        {user.status === 'Active' ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[0.65rem] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Active</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[0.65rem] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <XCircle className="w-2.5 h-2.5" />
                            <span>Inactive</span>
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            id={`edit-user-${user.id}`}
                            onClick={() => handleOpenEdit(user)}
                            className="p-1.5 rounded text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Edit user details and scopes"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            id={`delete-user-${user.id}`}
                            onClick={() => {
                              const result = deleteUser(user.id);
                              if (!result.success) {
                                showToast('User Not Deleted', result.message, 'warning');
                              }
                            }}
                            disabled={currentUser?.id === user.id}
                            className="p-1.5 rounded text-slate-500 hover:text-rose-600 hover:bg-rose-50 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                            title={currentUser?.id === user.id ? 'You cannot delete your own account' : 'Delete user'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            id={`toggle-status-user-${user.id}`}
                            onClick={() => toggleUserStatus(user.id)}
                            className={`p-1.5 rounded transition-colors ${
                              user.status === 'Active'
                                ? 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                                : 'text-slate-500 hover:text-emerald-600 hover:bg-emerald-50'
                            }`}
                            title={user.status === 'Active' ? 'Deactivate user' : 'Activate user'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit User Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/70">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  {editingUserId ? 'Edit Portal User &amp; Role Scope' : 'Add New Portal User'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 text-xs">
              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Display Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Jonathan Smith"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-blue-600 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Email / User ID *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="jonathan.smith@cognizant.com"
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              {/* Role */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">Assigned Portal Role *</label>
                <select
                  value={formData.role}
                  onChange={e => setFormData({ ...formData, role: e.target.value as UserRole })}
                  className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-1 focus:ring-blue-600 focus:bg-white text-slate-800"
                >
                  {allRoles.map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <p className="text-[0.65rem] text-slate-400 mt-1">
                  Role governs screen access and operational gating (e.g. creation/editing permissions).
                </p>
              </div>

              {/* Scope Hierarchy Card with Cascading Rules */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold">
                  <Building className="w-3.5 h-3.5 text-blue-600" />
                  <span>Organizational Scope Hierarchy (Cascading)</span>
                </div>

                {/* Account Scope */}
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Account Scope</label>
                  <select
                    value={formData.accountScope}
                    onChange={e => handleAccountScopeChange(e.target.value)}
                    className="w-full py-1.5 px-2.5 bg-white border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="All">All Accounts (Global Portfolio)</option>
                    {accounts.map(acc => (
                      <option key={acc.id} value={acc.name}>
                        {acc.name} ({acc.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Program Scope */}
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">
                    Program Scope {formData.accountScope === 'All' ? '(Global Scope Active)' : ''}
                  </label>
                  <select
                    disabled={formData.accountScope === 'All'}
                    value={formData.programScope}
                    onChange={e => handleProgramScopeChange(e.target.value)}
                    className="w-full py-1.5 px-2.5 bg-white border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-blue-600 disabled:bg-slate-100 disabled:text-slate-400"
                  >
                    <option value="All">All Programs in Account Scope</option>
                    {availableProgramsForAccount.map(prog => (
                      <option key={prog.id} value={prog.name}>
                        {prog.name} ({prog.code})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Project Scope */}
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">
                    Project Scope {formData.programScope === 'All' ? '(All Programs Active)' : ''}
                  </label>
                  <select
                    disabled={formData.accountScope === 'All' || formData.programScope === 'All'}
                    value={formData.projectScope}
                    onChange={e => setFormData({ ...formData, projectScope: e.target.value })}
                    className="w-full py-1.5 px-2.5 bg-white border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-blue-600 disabled:bg-slate-100 disabled:text-slate-400"
                  >
                    <option value="All">All Projects in Program Scope</option>
                    {availableProjectsForProgram.map(prj => (
                      <option key={prj.id} value={prj.name}>
                        {prj.name} ({prj.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="text-[0.65rem] text-blue-700 bg-blue-50/60 p-2 rounded border border-blue-100 flex items-start gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.2" />
                  <span>
                    Changing Account revalidates Program &amp; Project scopes automatically to prevent orphaned scope assignments.
                  </span>
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">User Status</label>
                <div className="flex items-center gap-4 pt-1">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="Active"
                      checked={formData.status === 'Active'}
                      onChange={() => setFormData({ ...formData, status: 'Active' })}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Active (Can authenticate)
                    </span>
                  </label>

                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="Inactive"
                      checked={formData.status === 'Inactive'}
                      onChange={() => setFormData({ ...formData, status: 'Inactive' })}
                      className="text-rose-600 focus:ring-rose-500"
                    />
                    <span className="font-semibold text-rose-700 flex items-center gap-1">
                      <XCircle className="w-3.5 h-3.5" />
                      Inactive (Login denied)
                    </span>
                  </label>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="admin-save-user-btn"
                  className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
                >
                  {editingUserId ? 'Save User Changes' : 'Create User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

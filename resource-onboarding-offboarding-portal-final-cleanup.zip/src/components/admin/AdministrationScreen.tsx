import React, { useState } from 'react';
import { 
  Building2, 
  Layers, 
  Briefcase, 
  Users, 
  MapPin, 
  Truck, 
  Laptop,
  Plus, 
  CheckCircle2, 
  X, 
  Edit3, 
  Save, 
  Search, 
  Power,
  RotateCcw,
  Trash2,
  ShieldCheck
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserManagementTab } from './UserManagementTab';
import { AccessDeniedView } from '../common/AccessDeniedView';

export const AdministrationScreen: React.FC = () => {
  const {
    currentUser,
    accounts,
    selectedAccount,
    setSelectedAccount,
    managers,
    locations,
    deliveryMethods,
    returnCarriers,
    hardwareModels,
    addAccount,
    updateAccount,
    toggleAccountStatus,
    deleteAccount,
    addProgram,
    updateProgram,
    toggleProgramStatus,
    deleteProgram,
    addProject,
    updateProject,
    toggleProjectStatus,
    deleteProject,
    addManager,
    updateManager,
    toggleManagerStatus,
    deleteManager,
    addLocation,
    updateLocation,
    toggleLocationStatus,
    deleteLocation,
    addReferenceItem,
    updateReferenceItem,
    toggleReferenceItemStatus,
    deleteReferenceItem,
    checkItemInUse,
    getAvailableItems,
    resetMasterData,
    showToast
  } = useApp();

  const [activeAdminTab, setActiveAdminTab] = useState<'hierarchy' | 'managers' | 'locations' | 'logistics' | 'users'>('hierarchy');

  if (currentUser?.role !== 'Admin') {
    return <AccessDeniedView screenName="Portal Administration" requiredRole="Admin" />;
  }

  // Add Account Modal / State
  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);
  const [newAccountData, setNewAccountData] = useState({ name: '', code: '', description: '' });

  // Add Program State
  const [addingProgramForAccountId, setAddingProgramForAccountId] = useState<string | null>(null);
  const [newProgramData, setNewProgramData] = useState({ name: '', code: '' });

  // Add Project State
  const [addingProjectForProgramId, setAddingProjectForProgramId] = useState<string | null>(null);
  const [newProjectData, setNewProjectData] = useState({ name: '', code: '', manager: '', location: '' });

  // Add Manager State
  const [isAddManagerOpen, setIsAddManagerOpen] = useState(false);
  const [newManagerData, setNewManagerData] = useState({ name: '', email: '' });
  const [managerSearch, setManagerSearch] = useState('');

  // Add Location State
  const [isAddLocationOpen, setIsAddLocationOpen] = useState(false);
  const [newLocationData, setNewLocationData] = useState({ name: '', city: '', state: '', country: 'USA' });
  const [locationSearch, setLocationSearch] = useState('');

  // Add Reference Item State
  const [newMethodName, setNewMethodName] = useState('');
  const [newCarrierName, setNewCarrierName] = useState('');
  const [newHardwareName, setNewHardwareName] = useState('');
  const [newHardwareDesc, setNewHardwareDesc] = useState('');

  type EditEntity =
    | { type: 'account'; id: string; name: string; code: string; description: string; status: 'Active' | 'Inactive' }
    | { type: 'program'; id: string; name: string; code: string; status: 'Active' | 'Inactive' }
    | { type: 'project'; id: string; name: string; code: string; manager: string; location: string; status: 'Active' | 'Inactive' }
    | { type: 'manager'; id: string; name: string; email: string; status: 'Active' | 'Inactive' }
    | { type: 'location'; id: string; name: string; city: string; state: string; country: string; status: 'Active' | 'Inactive' }
    | { type: 'reference'; id: string; name: string; description: string; status: 'Active' | 'Inactive'; category: 'delivery_method' | 'return_carrier' | 'hardware_model' };
  const [editingEntity, setEditingEntity] = useState<EditEntity | null>(null);

  const saveEditedEntity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEntity) return;
    if (editingEntity.type === 'account') updateAccount(editingEntity.id, { name: editingEntity.name.trim(), code: editingEntity.code.trim().toUpperCase(), description: editingEntity.description.trim() });
    if (editingEntity.type === 'program') updateProgram(editingEntity.id, { name: editingEntity.name.trim(), code: editingEntity.code.trim().toUpperCase() });
    if (editingEntity.type === 'project') updateProject(editingEntity.id, { name: editingEntity.name.trim(), code: editingEntity.code.trim().toUpperCase(), manager: editingEntity.manager, location: editingEntity.location });
    if (editingEntity.type === 'manager') updateManager(editingEntity.id, { name: editingEntity.name.trim(), email: editingEntity.email.trim() });
    if (editingEntity.type === 'location') updateLocation(editingEntity.id, { name: editingEntity.name.trim(), city: editingEntity.city.trim(), state: editingEntity.state.trim(), country: editingEntity.country.trim() });
    if (editingEntity.type === 'reference') updateReferenceItem(editingEntity.id, { name: editingEntity.name.trim(), description: editingEntity.description.trim() || undefined });
    setEditingEntity(null);
  };


  // Calculate totals
  const totalAccounts = accounts.length;
  const totalPrograms = accounts.reduce((sum, a) => sum + a.programs.length, 0);
  const totalProjects = accounts.reduce((sum, a) => sum + a.programs.reduce((ps, p) => ps + p.projects.length, 0), 0);
  const totalConfigEntities = managers.length + locations.length;

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccountData.name.trim() || !newAccountData.code.trim()) {
      showToast('Validation Error', 'Account name and code are required.', 'error');
      return;
    }
    addAccount({
      name: newAccountData.name.trim(),
      code: newAccountData.code.trim().toUpperCase(),
      description: newAccountData.description.trim() || `${newAccountData.name.trim()} Client Portfolio`
    });
    setNewAccountData({ name: '', code: '', description: '' });
    setIsAddAccountOpen(false);
  };

  const handleCreateProgram = (accountId: string, e: React.FormEvent) => {
    e.preventDefault();
    if (!newProgramData.name.trim() || !newProgramData.code.trim()) {
      showToast('Validation Error', 'Program name and code are required.', 'error');
      return;
    }
    addProgram({
      accountId,
      name: newProgramData.name.trim(),
      code: newProgramData.code.trim().toUpperCase()
    });
    setNewProgramData({ name: '', code: '' });
    setAddingProgramForAccountId(null);
  };

  const handleCreateProject = (programId: string, e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectData.name.trim() || !newProjectData.code.trim()) {
      showToast('Validation Error', 'Project name and code are required.', 'error');
      return;
    }
    addProject({
      programId,
      name: newProjectData.name.trim(),
      code: newProjectData.code.trim().toUpperCase(),
      manager: newProjectData.manager.trim() || (managers[0]?.name || 'Sarah Jenkins'),
      location: newProjectData.location.trim() || (locations[0]?.name || 'San Diego, CA')
    });
    setNewProjectData({ name: '', code: '', manager: '', location: '' });
    setAddingProjectForProgramId(null);
  };

  const handleCreateManager = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newManagerData.name.trim() || !newManagerData.email.trim()) {
      showToast('Validation Error', 'Manager name and email are required.', 'error');
      return;
    }
    addManager({
      name: newManagerData.name.trim(),
      email: newManagerData.email.trim()
    });
    setNewManagerData({ name: '', email: '' });
    setIsAddManagerOpen(false);
  };

  const handleCreateLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocationData.name.trim() || !newLocationData.city.trim() || !newLocationData.state.trim()) {
      showToast('Validation Error', 'Location name, city, and state are required.', 'error');
      return;
    }
    addLocation({
      name: newLocationData.name.trim(),
      city: newLocationData.city.trim(),
      state: newLocationData.state.trim(),
      country: newLocationData.country.trim() || 'USA'
    });
    setNewLocationData({ name: '', city: '', state: '', country: 'USA' });
    setIsAddLocationOpen(false);
  };

  const handleAddDeliveryMethod = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMethodName.trim()) return;
    addReferenceItem({
      name: newMethodName.trim(),
      category: 'delivery_method'
    });
    setNewMethodName('');
  };

  const handleAddReturnCarrier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCarrierName.trim()) return;
    addReferenceItem({
      name: newCarrierName.trim(),
      category: 'return_carrier'
    });
    setNewCarrierName('');
  };

  const handleAddHardwareModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHardwareName.trim()) return;
    addReferenceItem({
      name: newHardwareName.trim(),
      category: 'hardware_model',
      description: newHardwareDesc.trim() || undefined
    });
    setNewHardwareName('');
    setNewHardwareDesc('');
  };

  const filteredManagers = managers.filter(m => 
    m.name.toLowerCase().includes(managerSearch.toLowerCase()) || 
    m.email.toLowerCase().includes(managerSearch.toLowerCase())
  );

  const filteredLocations = locations.filter(l => 
    l.name.toLowerCase().includes(locationSearch.toLowerCase()) || 
    l.city.toLowerCase().includes(locationSearch.toLowerCase()) ||
    l.state.toLowerCase().includes(locationSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[0.68rem] font-extrabold uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              CENTRALIZED MASTER DATA
            </span>
            <span className="text-xs text-slate-400">•</span>
            <span className="text-xs font-semibold text-slate-600">Enterprise Administration</span>
          </div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight mt-1">
            Portal Administration &amp; Master Data Configuration
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure Account &gt; Program &gt; Project hierarchies, Project Managers, Locations, and Logistics reference data
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              if (window.confirm('Reset all master data and records back to the initial standard seed state? This will clear customized local cache.')) {
                resetMasterData();
              }
            }}
            title="Reset to Initial Seed Dataset"
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Demo Data</span>
          </button>

          {activeAdminTab === 'hierarchy' && (
            <button
              onClick={() => setIsAddAccountOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Account</span>
            </button>
          )}
        </div>
      </div>

      {/* 4 Top KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Active Accounts
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">{totalAccounts}</span>
            <span className="text-[0.65rem] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
              Client Portfolios
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Managed Programs
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-blue-700">{totalPrograms}</span>
            <span className="text-[0.65rem] font-semibold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
              Delivery Streams
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Active SOW Projects
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-700">{totalProjects}</span>
            <span className="text-[0.65rem] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
              Live Work Orders
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Managers &amp; Facilities
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-purple-700">{totalConfigEntities}</span>
            <span className="text-[0.65rem] font-semibold text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded">
              Configured Nodes
            </span>
          </div>
        </div>
      </div>

      {/* Admin Tab Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveAdminTab('hierarchy')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeAdminTab === 'hierarchy'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>1. Account Hierarchy &amp; Scoping</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('managers')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeAdminTab === 'managers'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>2. Project Managers &amp; Leads</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('locations')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeAdminTab === 'locations'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>3. Locations &amp; Facilities</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('logistics')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeAdminTab === 'logistics'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Laptop className="w-4 h-4" />
          <span>4. Hardware &amp; Logistics Master Data</span>
        </button>

        <button
          onClick={() => setActiveAdminTab('users')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeAdminTab === 'users'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>5. Portal Users &amp; RBAC</span>
        </button>
      </div>

      {/* Tab 1: Account Hierarchy */}
      {activeAdminTab === 'hierarchy' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Master Enterprise Hierarchy Tree
                </h3>
                <p className="text-xs text-slate-500">
                  Account &rarr; Program Stream &rarr; Project Work Orders (Strict Single Source of Truth)
                </p>
              </div>
              <span className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-200">
                Single Source of Truth Active
              </span>
            </div>

            {/* Account Creation Modal */}
            {isAddAccountOpen && (
              <div className="mb-6 p-4 rounded-xl border-2 border-blue-300 bg-blue-50/50">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    <span>Create New Enterprise Account</span>
                  </h4>
                  <button 
                    onClick={() => setIsAddAccountOpen(false)}
                    className="text-slate-400 hover:text-slate-600 p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <form onSubmit={handleCreateAccount} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Account Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Acme Corporation"
                      value={newAccountData.name}
                      onChange={e => setNewAccountData({ ...newAccountData, name: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Account Code *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. ACM"
                      value={newAccountData.code}
                      onChange={e => setNewAccountData({ ...newAccountData, code: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono uppercase text-slate-800 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Portfolio Description</label>
                    <input
                      type="text"
                      placeholder="e.g. Strategic Global Account"
                      value={newAccountData.description}
                      onChange={e => setNewAccountData({ ...newAccountData, description: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800"
                    />
                  </div>
                  <div className="sm:col-span-3 flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsAddAccountOpen(false)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold"
                    >
                      Save Account
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {accounts.map(acc => (
                <div 
                  key={acc.id}
                  className={`p-4 rounded-xl border transition-all ${
                    selectedAccount === acc.id || (selectedAccount === 'all' && acc.id === 'acc-apex')
                      ? 'border-blue-500 bg-blue-50/40 ring-2 ring-blue-100'
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[0.68rem] font-bold uppercase tracking-wider text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded">
                      {acc.code}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => toggleAccountStatus(acc.id)}
                        className={`text-[0.65rem] font-bold px-1.5 py-0.5 rounded border transition-colors cursor-pointer ${
                          acc.status === 'Active' 
                            ? 'text-emerald-700 bg-emerald-50 border-emerald-200 hover:bg-emerald-100' 
                            : 'text-slate-600 bg-slate-100 border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {acc.status}
                      </button>
                      <button
                        onClick={() => setEditingEntity({ type: 'account', id: acc.id, name: acc.name, code: acc.code, description: acc.description || '', status: acc.status })}
                        title="Edit Account"
                        className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteAccount(acc.id)}
                        title="Delete Account (only if unused)"
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <h4 className="font-black text-slate-900 text-sm mb-1">{acc.name}</h4>
                  <p className="text-xs text-slate-500 mb-3">{acc.description}</p>

                  {/* Add Program Form if toggled */}
                  {addingProgramForAccountId === acc.id && (
                    <form 
                      onSubmit={(e) => handleCreateProgram(acc.id, e)} 
                      className="mb-3 p-3 bg-white border border-blue-200 rounded-lg text-xs space-y-2"
                    >
                      <div className="font-bold text-[0.68rem] uppercase text-blue-800">New Program Stream</div>
                      <input
                        type="text"
                        required
                        placeholder="Program Name"
                        value={newProgramData.name}
                        onChange={e => setNewProgramData({ ...newProgramData, name: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-300 rounded px-2 py-1 text-slate-800"
                      />
                      <input
                        type="text"
                        required
                        placeholder="Program Code (e.g. DBP)"
                        value={newProgramData.code}
                        onChange={e => setNewProgramData({ ...newProgramData, code: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-300 rounded px-2 py-1 uppercase font-mono text-slate-800"
                      />
                      <div className="flex justify-end gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => setAddingProgramForAccountId(null)}
                          className="px-2 py-0.5 text-slate-500 hover:text-slate-800 text-[0.65rem]"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-2.5 py-1 bg-blue-600 text-white rounded text-[0.65rem] font-bold"
                        >
                          Add Program
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="border-t border-slate-200/80 pt-2.5 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="text-[0.68rem] font-bold uppercase tracking-wider text-slate-400">
                        Programs &amp; Projects
                      </div>
                      <button
                        onClick={() => {
                          setAddingProgramForAccountId(addingProgramForAccountId === acc.id ? null : acc.id);
                          setNewProgramData({ name: '', code: '' });
                        }}
                        className="text-[0.65rem] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Program</span>
                      </button>
                    </div>

                    {acc.programs.map(prog => (
                      <div key={prog.id} className="bg-white p-2.5 rounded-lg border border-slate-200/80">
                        <div className="font-bold text-slate-800 text-[0.72rem] flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span>{prog.name}</span>
                            <button
                              onClick={() => toggleProgramStatus(prog.id)}
                              className={`text-[0.6rem] font-semibold px-1.5 py-0.2 rounded border transition-colors cursor-pointer ${
                                prog.status === 'Active' 
                                  ? 'text-emerald-700 bg-emerald-50 border-emerald-200 hover:bg-emerald-100' 
                                  : 'text-slate-500 bg-slate-100 border-slate-200 hover:bg-slate-200'
                              }`}
                            >
                              {prog.status}
                            </button>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => {
                                setAddingProjectForProgramId(addingProjectForProgramId === prog.id ? null : prog.id);
                                setNewProjectData({ name: '', code: '', manager: managers[0]?.name || '', location: locations[0]?.name || '' });
                              }}
                              className="text-[0.62rem] text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
                            >
                              + Project
                            </button>
                            <span className="text-slate-400 text-[0.65rem]">{prog.projects.length} Prj</span>
                            <button
                              onClick={() => setEditingEntity({ type: 'program', id: prog.id, name: prog.name, code: prog.code, status: prog.status })}
                              title="Edit Program"
                              className="p-0.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => deleteProgram(prog.id)}
                              title="Delete Program (only if unused)"
                              className="p-0.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>

                        {/* Add Project Form if toggled */}
                        {addingProjectForProgramId === prog.id && (
                          <form 
                            onSubmit={(e) => handleCreateProject(prog.id, e)} 
                            className="mt-2 p-2 bg-blue-50/70 border border-blue-200 rounded text-[0.68rem] space-y-1.5"
                          >
                            <div className="font-bold text-blue-900">New Project Work Order</div>
                            <input
                              type="text"
                              required
                              placeholder="Project Name"
                              value={newProjectData.name}
                              onChange={e => setNewProjectData({ ...newProjectData, name: e.target.value })}
                              className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
                            />
                            <div className="grid grid-cols-2 gap-1.5">
                              <input
                                type="text"
                                required
                                placeholder="Code (e.g. PRJ-01)"
                                value={newProjectData.code}
                                onChange={e => setNewProjectData({ ...newProjectData, code: e.target.value })}
                                className="w-full bg-white border border-slate-300 rounded px-2 py-1 uppercase font-mono text-slate-800"
                              />
                              <select
                                value={newProjectData.manager}
                                onChange={e => setNewProjectData({ ...newProjectData, manager: e.target.value })}
                                className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
                              >
                                {getAvailableItems(managers, newProjectData.manager).map(m => (
                                  <option key={m.id} value={m.name}>
                                    {m.name}{m.status === 'Inactive' ? ' (Inactive)' : ''}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <select
                              value={newProjectData.location}
                              onChange={e => setNewProjectData({ ...newProjectData, location: e.target.value })}
                              className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-slate-800"
                            >
                              {getAvailableItems(locations, newProjectData.location).map(loc => (
                                <option key={loc.id} value={loc.name}>
                                  {loc.name}{loc.status === 'Inactive' ? ' (Inactive)' : ''}
                                </option>
                              ))}
                            </select>
                            <div className="flex justify-end gap-1 pt-1">
                              <button
                                type="button"
                                onClick={() => setAddingProjectForProgramId(null)}
                                className="px-2 py-0.5 text-slate-500 hover:text-slate-800 text-[0.62rem]"
                              >
                                Cancel
                              </button>
                              <button
                                type="submit"
                                className="px-2 py-0.5 bg-blue-600 text-white rounded text-[0.62rem] font-bold"
                              >
                                Save Project
                              </button>
                            </div>
                          </form>
                        )}

                        <div className="mt-1.5 space-y-1">
                          {prog.projects.map(prj => (
                            <div key={prj.id} className="flex items-center justify-between text-[0.68rem] text-slate-600 pl-2 border-l border-slate-200 py-0.5 hover:bg-slate-50 rounded-r">
                              <div className="truncate mr-2">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-medium text-slate-800">{prj.name}</span>
                                  <button
                                    onClick={() => toggleProjectStatus(acc.id, prog.id, prj.id)}
                                    className={`text-[0.58rem] font-semibold px-1 py-0 rounded border transition-colors cursor-pointer ${
                                      prj.status === 'Active' 
                                        ? 'text-emerald-700 bg-emerald-50 border-emerald-200 hover:bg-emerald-100' 
                                        : 'text-slate-500 bg-slate-100 border-slate-200 hover:bg-slate-200'
                                    }`}
                                  >
                                    {prj.status}
                                  </button>
                                </div>
                                <span className="text-[0.62rem] text-slate-400 block">{prj.manager} • {prj.location}</span>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <span className="font-mono text-slate-400 text-[0.62rem]">{prj.code}</span>
                                <button
                                  onClick={() => setEditingEntity({ type: 'project', id: prj.id, name: prj.name, code: prj.code, manager: prj.manager, location: prj.location || '', status: prj.status })}
                                  title="Edit Project"
                                  className="p-0.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                                >
                                  <Edit3 className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={() => deleteProject(acc.id, prog.id, prj.id)}
                                  title="Delete Project (only if unused)"
                                  className="p-0.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Project Managers & Leads */}
      {activeAdminTab === 'managers' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Authorized Project Managers &amp; PMO Leads
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Centralized registry of delivery managers eligible for project and resource assignments
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search managers..."
                  value={managerSearch}
                  onChange={e => setManagerSearch(e.target.value)}
                  className="bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800"
                />
              </div>
              <button
                onClick={() => setIsAddManagerOpen(!isAddManagerOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Manager</span>
              </button>
            </div>
          </div>

          {/* Add Manager Form */}
          {isAddManagerOpen && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-blue-900 uppercase">Register New Project Manager</span>
                <button onClick={() => setIsAddManagerOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <form onSubmit={handleCreateManager} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. David Vance"
                    value={newManagerData.name}
                    onChange={e => setNewManagerData({ ...newManagerData, name: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Cognizant Email *</label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. david.vance@cognizant.com"
                    value={newManagerData.email}
                    onChange={e => setNewManagerData({ ...newManagerData, email: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium"
                  />
                </div>
                <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddManagerOpen(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg"
                  >
                    Save Manager
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Managers Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase text-[0.68rem] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Manager Name</th>
                  <th className="py-3 px-4">Cognizant Email</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredManagers.map(m => (
                  <tr key={m.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4 font-bold text-slate-900">{m.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{m.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[0.65rem] font-bold border ${
                        m.status === 'Active' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}>
                        {m.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setEditingEntity({ type: 'manager', id: m.id, name: m.name, email: m.email, status: m.status })}
                          title="Edit Manager"
                          className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => toggleManagerStatus(m.id)}
                          className="text-[0.68rem] font-semibold text-blue-600 hover:text-blue-800 cursor-pointer"
                        >
                          {m.status === 'Active' ? 'Deactivate' : 'Activate'}
                        </button>
                        <button
                          onClick={() => deleteManager(m.id)}
                          title="Delete Manager (only if unused)"
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Locations & Facilities */}
      {activeAdminTab === 'locations' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Global Facilities &amp; Delivery Locations
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Centralized registry of client offices, development centers, and hardware depots
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search locations..."
                  value={locationSearch}
                  onChange={e => setLocationSearch(e.target.value)}
                  className="bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800"
                />
              </div>
              <button
                onClick={() => setIsAddLocationOpen(!isAddLocationOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Location</span>
              </button>
            </div>
          </div>

          {/* Add Location Form */}
          {isAddLocationOpen && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-blue-900 uppercase">Register New Delivery Location</span>
                <button onClick={() => setIsAddLocationOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <form onSubmit={handleCreateLocation} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="sm:col-span-2">
                  <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">Display Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Austin Tech Center, TX"
                    value={newLocationData.name}
                    onChange={e => setNewLocationData({ ...newLocationData, name: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Austin"
                    value={newLocationData.city}
                    onChange={e => setNewLocationData({ ...newLocationData, city: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-[0.68rem] font-semibold text-slate-600 mb-1">State / Province *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. TX"
                    value={newLocationData.state}
                    onChange={e => setNewLocationData({ ...newLocationData, state: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-800 font-medium"
                  />
                </div>
                <div className="sm:col-span-4 flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddLocationOpen(false)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg"
                  >
                    Save Location
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Locations Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {filteredLocations.map(loc => (
              <div key={loc.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start justify-between">
                <div className="flex items-start gap-2.5">
                  <div className="p-2 rounded-lg bg-blue-50 text-blue-700 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">{loc.name}</div>
                    <div className="text-[0.7rem] text-slate-500 mt-0.5">{loc.city}, {loc.state} • {loc.country}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setEditingEntity({ type: 'location', id: loc.id, name: loc.name, city: loc.city, state: loc.state, country: loc.country, status: loc.status })}
                    title="Edit Location"
                    className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => toggleLocationStatus(loc.id)}
                    className={`text-[0.65rem] font-bold px-2 py-0.5 rounded-full border transition-colors cursor-pointer ${
                      loc.status === 'Active'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {loc.status}
                  </button>
                  <button
                    onClick={() => deleteLocation(loc.id)}
                    title="Delete Location (only if unused)"
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Dispatch, Return Logistics & Hardware Models */}
      {activeAdminTab === 'logistics' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Hardware Models */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5 text-blue-600" />
                  <span>Hardware Models Catalog</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Standard laptops &amp; workstation configurations
                </p>
              </div>
              <span className="text-xs text-slate-400 font-semibold">{hardwareModels.length} Models</span>
            </div>

            <form onSubmit={handleAddHardwareModel} className="space-y-2 text-xs">
              <input
                type="text"
                required
                placeholder="e.g. Apple MacBook Air 15 (M3)"
                value={newHardwareName}
                onChange={e => setNewHardwareName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-800"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Specs/notes (e.g. 24GB Unified, 1TB SSD)"
                  value={newHardwareDesc}
                  onChange={e => setNewHardwareDesc(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-800"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add</span>
                </button>
              </div>
            </form>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {hardwareModels.map(item => (
                <div key={item.id} className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-slate-800 truncate">{item.name}</div>
                    {item.description && (
                      <div className="text-[0.68rem] text-slate-500 truncate">{item.description}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => toggleReferenceItemStatus(item.id)}
                      className={`px-2 py-0.5 rounded text-[0.65rem] font-bold border transition-colors cursor-pointer ${
                        item.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {item.status}
                    </button>
                    <button
                      onClick={() => setEditingEntity({ type: 'reference', id: item.id, name: item.name, description: item.description || '', status: item.status, category: item.category })}
                      title="Edit Reference Item"
                      className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteReferenceItem(item.id)}
                      title="Delete Hardware Model"
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Methods */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-blue-600" />
                  <span>Onboarding Dispatch Tiers</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Pre-configured hardware dispatch carriers
                </p>
              </div>
              <span className="text-xs text-slate-400 font-semibold">{deliveryMethods.length} Tiers</span>
            </div>

            <form onSubmit={handleAddDeliveryMethod} className="flex gap-2 text-xs">
              <input
                type="text"
                required
                placeholder="e.g. Priority Overnight Courier"
                value={newMethodName}
                onChange={e => setNewMethodName(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-800"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </form>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {deliveryMethods.map(item => (
                <div key={item.id} className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Truck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span className="font-semibold text-slate-800 truncate">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => toggleReferenceItemStatus(item.id)}
                      className={`px-2 py-0.5 rounded text-[0.65rem] font-bold border transition-colors cursor-pointer ${
                        item.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {item.status}
                    </button>
                    <button
                      onClick={() => setEditingEntity({ type: 'reference', id: item.id, name: item.name, description: item.description || '', status: item.status, category: item.category })}
                      title="Edit Reference Item"
                      className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteReferenceItem(item.id)}
                      title="Delete Delivery Method"
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Return Carriers */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-purple-600" />
                  <span>Offboarding Return Carriers</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Approved return box logistics partners
                </p>
              </div>
              <span className="text-xs text-slate-400 font-semibold">{returnCarriers.length} Carriers</span>
            </div>

            <form onSubmit={handleAddReturnCarrier} className="flex gap-2 text-xs">
              <input
                type="text"
                required
                placeholder="e.g. Secure Courier Service"
                value={newCarrierName}
                onChange={e => setNewCarrierName(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-slate-800"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </form>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {returnCarriers.map(item => (
                <div key={item.id} className="p-3 rounded-lg border border-slate-200 bg-slate-50/50 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Truck className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span className="font-semibold text-slate-800 truncate">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => toggleReferenceItemStatus(item.id)}
                      className={`px-2 py-0.5 rounded text-[0.65rem] font-bold border transition-colors cursor-pointer ${
                        item.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {item.status}
                    </button>
                    <button
                      onClick={() => setEditingEntity({ type: 'reference', id: item.id, name: item.name, description: item.description || '', status: item.status, category: item.category })}
                      title="Edit Reference Item"
                      className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteReferenceItem(item.id)}
                      title="Delete Return Carrier"
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Portal Users & RBAC */}

      {activeAdminTab === 'users' && <UserManagementTab />}

      {editingEntity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4" role="dialog" aria-modal="true">
          <form onSubmit={saveEditedEntity} className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[0.68rem] font-bold uppercase tracking-wider text-blue-700">Edit Master Data</div>
                <h3 className="text-lg font-black text-slate-900 mt-1">Edit {editingEntity.type === 'reference' ? 'Reference Item' : editingEntity.type}</h3>
              </div>
              <button type="button" onClick={() => setEditingEntity(null)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2"><label className="block font-semibold text-slate-600 mb-1">Name</label><input required value={editingEntity.name} onChange={e => setEditingEntity({ ...editingEntity, name: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>
              {'code' in editingEntity && <div><label className="block font-semibold text-slate-600 mb-1">Code</label><input required value={editingEntity.code} onChange={e => setEditingEntity({ ...editingEntity, code: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 font-mono uppercase text-slate-800" /></div>}
              {editingEntity.type === 'account' && <div className="sm:col-span-2"><label className="block font-semibold text-slate-600 mb-1">Description</label><input value={editingEntity.description} onChange={e => setEditingEntity({ ...editingEntity, description: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>}
              {editingEntity.type === 'manager' && <div><label className="block font-semibold text-slate-600 mb-1">Email</label><input required type="email" value={editingEntity.email} onChange={e => setEditingEntity({ ...editingEntity, email: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>}
              {editingEntity.type === 'location' && <>
                <div><label className="block font-semibold text-slate-600 mb-1">City</label><input required value={editingEntity.city} onChange={e => setEditingEntity({ ...editingEntity, city: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>
                <div><label className="block font-semibold text-slate-600 mb-1">State</label><input required value={editingEntity.state} onChange={e => setEditingEntity({ ...editingEntity, state: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>
                <div><label className="block font-semibold text-slate-600 mb-1">Country</label><input required value={editingEntity.country} onChange={e => setEditingEntity({ ...editingEntity, country: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>
              </>}
              {editingEntity.type === 'project' && <>
                <div><label className="block font-semibold text-slate-600 mb-1">Manager</label><select value={editingEntity.manager} onChange={e => setEditingEntity({ ...editingEntity, manager: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800">{managers.map(m => <option key={m.id} value={m.name}>{m.name}</option>)}</select></div>
                <div><label className="block font-semibold text-slate-600 mb-1">Location</label><select value={editingEntity.location} onChange={e => setEditingEntity({ ...editingEntity, location: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800">{locations.map(l => <option key={l.id} value={l.name}>{l.name}</option>)}</select></div>
              </>}
              {editingEntity.type === 'reference' && <div className="sm:col-span-2"><label className="block font-semibold text-slate-600 mb-1">Description</label><input value={editingEntity.description} onChange={e => setEditingEntity({ ...editingEntity, description: e.target.value } as EditEntity)} className="w-full border border-slate-300 rounded-lg px-3 py-2 text-slate-800" /></div>}
            </div>
            <div className="flex justify-end gap-2 pt-2"><button type="button" onClick={() => setEditingEntity(null)} className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold text-xs">Cancel</button><button type="submit" className="px-4 py-2 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center gap-1.5"><Save className="w-3.5 h-3.5" />Save Changes</button></div>
          </form>
        </div>
      )}
    </div>
  );
};
